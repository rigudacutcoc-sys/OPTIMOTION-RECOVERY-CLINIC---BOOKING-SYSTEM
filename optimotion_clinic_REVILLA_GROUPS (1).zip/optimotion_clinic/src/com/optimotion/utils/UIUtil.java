package com.optimotion.utils;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.Window;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.JTableHeader;


public class UIUtil {

    // ---- Brand (kept from original design) ----
    public static final Color PRIMARY = new Color(0, 150, 136);   // teal
    public static final Color PRIMARY_DARK = new Color(0, 121, 107);
    public static final Color PRIMARY_HOVER = new Color(0, 137, 123);
    public static final Color PRIMARY_SOFT = new Color(224, 242, 241);
    public static final Color ACCENT = new Color(38, 50, 56);      // dark slate (sidebar)
    public static final Color ACCENT_LIGHT = new Color(55, 71, 79);
    public static final Color BG = new Color(243, 246, 249);
    public static final Color SURFACE = Color.WHITE;
    public static final Color DANGER = new Color(211, 47, 47);
    public static final Color DANGER_HOVER = new Color(183, 28, 28);
    public static final Color SUCCESS = new Color(22, 163, 74);
    public static final Color WARNING = new Color(245, 158, 11);
    public static final Color INFO = new Color(2, 132, 199);

    // ---- Neutrals ----
    public static final Color BORDER = new Color(226, 232, 240);
    public static final Color BORDER_DARK = new Color(203, 213, 225);
    public static final Color TEXT_MAIN = new Color(30, 41, 59);
    public static final Color TEXT_MUTED = new Color(100, 116, 139);
    public static final Color STRIPE = new Color(248, 250, 252);
    public static final Color SELECTION = new Color(204, 251, 241);

    public static final int RADIUS_CARD = 14;
    public static final int RADIUS_BUTTON = 10;
    public static final int RADIUS_INPUT = 10;

    public static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font HEADER_FONT = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font NORMAL_FONT = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font SMALL_FONT = new Font("Segoe UI", Font.PLAIN, 12);
    public static final Font SMALL_BOLD = new Font("Segoe UI", Font.BOLD, 12);

    /** Logo filename inside src/resources (supports spaces). */
    public static final String LOGO_FILE = "optimotion_clinic logo.png";

    // ------------------------------------------------------------------
    // Global defaults - call once from Main
    // ------------------------------------------------------------------

    /** Soft modern defaults: fonts, focus, table grid, scroll speed. */
    public static void applyModernDefaults() {
        try {
            javax.swing.UIManager.put("Button.focus", new Color(0, 0, 0, 0));
            javax.swing.UIManager.put("Component.focusWidth", 1);
            javax.swing.UIManager.put("Table.showVerticalLines", false);
            javax.swing.UIManager.put("Table.showHorizontalLines", true);
            javax.swing.UIManager.put("Table.intercellSpacing", new java.awt.Dimension(0, 1));
            javax.swing.UIManager.put("ScrollBar.width", 12);
            javax.swing.UIManager.put("ToolTip.background", Color.WHITE);
            javax.swing.UIManager.put("ToolTip.foreground", TEXT_MAIN);
            javax.swing.UIManager.put("OptionPane.messageFont", NORMAL_FONT);
            javax.swing.UIManager.put("OptionPane.buttonFont", SMALL_BOLD);
        } catch (Exception ignored) {}
    }

    
    public static ImageIcon loadLogo(int w, int h) {
        Image img = null;
        // 1) classpath (works after run.bat copies resources to bin/)
        String[] cpPaths = {"/resources/" + LOGO_FILE, "/" + LOGO_FILE};
        for (String p : cpPaths) {
            try {
                java.net.URL url = UIUtil.class.getResource(p);
                if (url != null) {
                    img = new ImageIcon(url).getImage();
                    break;
                }
            } catch (Exception ignored) {}
        }
        // 2) file system fallbacks (works when running from project folder)
        if (img == null) {
            String[] filePaths = {
                "src/resources/" + LOGO_FILE,
                "bin/resources/" + LOGO_FILE,
                "resources/" + LOGO_FILE
            };
            for (String p : filePaths) {
                try {
                    File f = new File(p);
                    if (f.exists()) {
                        img = new ImageIcon(f.getAbsolutePath()).getImage();
                        break;
                    }
                } catch (Exception ignored) {}
            }
        }
        if (img == null) return null;
        // Keep aspect ratio: fit inside w x h (your logo is wide, so width limits it)
        int iw = img.getWidth(null);
        int ih = img.getHeight(null);
        if (iw > 0 && ih > 0) {
            double scale = Math.min((double) w / iw, (double) h / ih);
            w = Math.max(1, (int) (iw * scale));
            h = Math.max(1, (int) (ih * scale));
        }
        Image scaled = img.getScaledInstance(w, h, Image.SCALE_SMOOTH);
        return new ImageIcon(scaled);
    }

    /** Sets the window/taskbar icon to the clinic logo (if found). */
    public static void setWindowIcon(Window w) {
        try {
            ImageIcon icon = loadLogo(64, 64);
            if (icon != null) w.setIconImage(icon.getImage());
        } catch (Exception ignored) {}
    }

    // ------------------------------------------------------------------
    // Rounded border
    // ------------------------------------------------------------------

    /** Simple rounded line border with padding. */
    public static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int radius;
        private final int thickness;
        private final Insets padding;

        public RoundedBorder(Color color, int radius) {
            this(color, radius, 1, new Insets(0, 0, 0, 0));
        }

        public RoundedBorder(Color color, int radius, int thickness, Insets padding) {
            this.color = color;
            this.radius = radius;
            this.thickness = thickness;
            this.padding = padding;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            for (int i = 0; i < thickness; i++) {
                g2.drawRoundRect(x + i, y + i, w - 1 - i * 2, h - 1 - i * 2, radius, radius);
            }
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(6 + padding.top, 12 + padding.left, 6 + padding.bottom, 12 + padding.right);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.top = 6 + padding.top;
            insets.left = 12 + padding.left;
            insets.bottom = 6 + padding.bottom;
            insets.right = 12 + padding.right;
            return insets;
        }
    }

    private static void addHover(final JButton b, final Color base, final Color hover) {
        // Remove previously attached hover listeners is overkill; just add one.
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                if (b.isEnabled()) b.setBackground(hover);
            }
            @Override public void mouseExited(MouseEvent e) {
                if (b.isEnabled()) b.setBackground(base);
            }
            @Override public void mousePressed(MouseEvent e) {
                if (b.isEnabled()) b.setBackground(base.darker());
            }
            @Override public void mouseReleased(MouseEvent e) {
                if (b.isEnabled()) {
                    b.setBackground(b.getBounds().contains(e.getPoint()) ? hover : base);
                }
            }
        });
    }

    private static void baseButton(JButton b, Color bg, Color hover) {
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setBorder(new RoundedBorder(bg.darker(), RADIUS_BUTTON));
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        // Paint rounded background manually so Nimbus / Windows LAFs don't square it off.
        b.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                JButton btn = (JButton) c;
                g2.setColor(btn.isEnabled() ? btn.getBackground()
                        : new Color(203, 213, 225));
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), RADIUS_BUTTON * 2, RADIUS_BUTTON * 2);
                g2.dispose();
                super.paint(g, c);
            }
        });
        addHover(b, bg, hover);
    }

    // ------------------------------------------------------------------
    // Buttons (same signatures as before, now rounded + hover)
    // ------------------------------------------------------------------

    public static void styleButton(JButton b) {
        baseButton(b, PRIMARY, PRIMARY_HOVER);
    }

    public static void styleDangerButton(JButton b) {
        baseButton(b, DANGER, DANGER_HOVER);
    }

    /** Solid pill button used in management footers. Keeps caller colour. */
    public static JButton solidButton(String text, Color bg) {
        JButton b = new JButton(text);
        Color hover = bg.darker();
        baseButton(b, bg, hover);
        b.setPreferredSize(new java.awt.Dimension(135, 36));
        return b;
    }

    /** White ghost button used on coloured headers (search / refresh). */
    public static JButton ghostButton(String text, Color tint) {
        JButton b = new JButton(text);
        b.setBackground(Color.WHITE);
        b.setForeground(tint);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new RoundedBorder(BORDER, RADIUS_BUTTON));
        b.setOpaque(true);
        final Color hoverBg = new Color(248, 250, 252);
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(hoverBg); }
            @Override public void mouseExited(MouseEvent e) { b.setBackground(Color.WHITE); }
        });
        b.setPreferredSize(new java.awt.Dimension(110, 34));
        return b;
    }

    /** Sidebar navigation button with rounded active look. */
    public static JButton sidebarButton(String text, boolean active) {
        JButton b = new JButton("    " + text);
        b.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        b.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
        b.setFont(new Font("Segoe UI", active ? Font.BOLD : Font.PLAIN, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        if (active) {
            b.setBackground(new Color(0, 105, 92));
            b.setForeground(Color.WHITE);
        } else {
            b.setBackground(ACCENT);
            b.setForeground(new Color(207, 216, 220));
        }
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) {
                if (!b.getBackground().equals(new Color(0, 105, 92))) {
                    b.setBackground(ACCENT_LIGHT);
                    b.setForeground(Color.WHITE);
                }
            }
            @Override public void mouseExited(MouseEvent e) {
                // Active state is managed by DashboardFrame; default back to idle.
                if (!b.getFont().isBold()) {
                    b.setBackground(ACCENT);
                    b.setForeground(new Color(207, 216, 220));
                }
            }
        });
        return b;
    }

    // ------------------------------------------------------------------
    // Cards / headers / inputs
    // ------------------------------------------------------------------

    /** Modern white card with soft rounded border. */
    public static JPanel card() {
        JPanel p = new JPanel(new java.awt.BorderLayout());
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER, RADIUS_CARD),
                new EmptyBorder(12, 14, 12, 14)));
        return p;
    }

    /** Card wrapper with a centred title on top (for charts / tables). */
    public static JPanel cardWrapper(String title) {
        JPanel p = card();
        p.setLayout(new java.awt.BorderLayout(5, 8));
        if (title != null && !title.isEmpty()) {
            javax.swing.JLabel l = new javax.swing.JLabel(title, javax.swing.SwingConstants.CENTER);
            l.setFont(HEADER_FONT);
            l.setForeground(TEXT_MAIN);
            p.add(l, java.awt.BorderLayout.NORTH);
        }
        return p;
    }

    /** Modern stat card: white, rounded, coloured top accent (no icon row). */
    public static JPanel statCard(String label, String value, Color accent) {
        JPanel p = new JPanel(new java.awt.BorderLayout());
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 0, 0, BORDER),
                        new RoundedBorder(BORDER, RADIUS_CARD)),
                new EmptyBorder(14, 12, 14, 12)));
        // Top accent bar (rounded look via a thin panel)
        JPanel accentBar = new JPanel();
        accentBar.setBackground(accent);
        accentBar.setPreferredSize(new java.awt.Dimension(0, 4));
        p.add(accentBar, java.awt.BorderLayout.NORTH);

        javax.swing.JLabel v = new javax.swing.JLabel(value, javax.swing.SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 22));
        v.setForeground(TEXT_MAIN);
        javax.swing.JLabel l = new javax.swing.JLabel(label, javax.swing.SwingConstants.CENTER);
        l.setFont(SMALL_FONT);
        l.setForeground(TEXT_MUTED);
        JPanel c = new JPanel(new java.awt.GridLayout(2, 1, 0, 2));
        c.setBackground(SURFACE);
        c.setBorder(new EmptyBorder(8, 0, 0, 0));
        c.add(v); c.add(l);
        p.add(c, java.awt.BorderLayout.CENTER);
        return p;
    }

    /** Modern stat card: white, rounded, coloured top accent. */
    public static JPanel statCard(String label, String value, Color accent, String icon) {
        JPanel p = new JPanel(new java.awt.BorderLayout());
        p.setBackground(SURFACE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 0, 0, BORDER),
                        new RoundedBorder(BORDER, RADIUS_CARD)),
                new EmptyBorder(14, 12, 14, 12)));
        // Top accent bar (rounded look via a thin panel)
        JPanel accentBar = new JPanel();
        accentBar.setBackground(accent);
        accentBar.setPreferredSize(new java.awt.Dimension(0, 4));
        p.add(accentBar, java.awt.BorderLayout.NORTH);

        javax.swing.JLabel ic = new javax.swing.JLabel(icon, javax.swing.SwingConstants.CENTER);
        ic.setFont(new Font("Segoe UI", Font.BOLD, 20));
        ic.setForeground(accent);
        javax.swing.JLabel v = new javax.swing.JLabel(value, javax.swing.SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 20));
        v.setForeground(TEXT_MAIN);
        javax.swing.JLabel l = new javax.swing.JLabel(label, javax.swing.SwingConstants.CENTER);
        l.setFont(SMALL_FONT);
        l.setForeground(TEXT_MUTED);
        JPanel c = new JPanel(new java.awt.GridLayout(3, 1, 0, 2));
        c.setBackground(SURFACE);
        c.setBorder(new EmptyBorder(8, 0, 0, 0));
        c.add(ic); c.add(v); c.add(l);
        p.add(c, java.awt.BorderLayout.CENTER);
        return p;
    }

    /** Rounded search field with soft border + focus highlight. */
    public static void styleSearchField(JTextField f) {
        f.setFont(NORMAL_FONT);
        f.setBackground(Color.WHITE);
        f.setForeground(TEXT_MAIN);
        f.setCaretColor(PRIMARY_DARK);
        f.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER_DARK, RADIUS_INPUT),
                new EmptyBorder(2, 6, 2, 6)));
        f.setPreferredSize(new java.awt.Dimension(210, 34));
        f.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                f.setBorder(BorderFactory.createCompoundBorder(
                        new RoundedBorder(PRIMARY, RADIUS_INPUT, 2, new Insets(0, 0, 0, 0)),
                        new EmptyBorder(2, 6, 2, 6)));
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                f.setBorder(BorderFactory.createCompoundBorder(
                        new RoundedBorder(BORDER_DARK, RADIUS_INPUT),
                        new EmptyBorder(2, 6, 2, 6)));
            }
        });
    }

    /** Rounded input row used on login / dialogs. */
    public static JPanel inputRow(String icon, JComponent field) {
        JPanel row = new JPanel(new java.awt.BorderLayout(8, 0));
        row.setBackground(Color.WHITE);
        row.setMaximumSize(new java.awt.Dimension(Integer.MAX_VALUE, 42));
        row.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(BORDER_DARK, RADIUS_INPUT),
                new EmptyBorder(0, 4, 0, 4)));
        javax.swing.JLabel ic = new javax.swing.JLabel(icon);
        ic.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        ic.setForeground(PRIMARY_DARK);
        row.add(ic, java.awt.BorderLayout.WEST);
        field.setBorder(null);
        field.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        if (field instanceof JTextField) {
            ((JTextField) field).setColumns(18);
        }
        row.add(field, java.awt.BorderLayout.CENTER);
        return row;
    }

    // ------------------------------------------------------------------
    // Tables (same signature, modern look)
    // ------------------------------------------------------------------

    public static void styleTable(JTable table) {
        table.setFont(NORMAL_FONT);
        table.setForeground(TEXT_MAIN);
        table.setBackground(Color.WHITE);
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(241, 245, 249));
        table.setIntercellSpacing(new java.awt.Dimension(0, 1));
        table.setSelectionBackground(SELECTION);
        table.setSelectionForeground(TEXT_MAIN);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(false);
        table.setFocusable(false);
        table.setRowMargin(0);
        JTableHeader h = table.getTableHeader();
        h.setBackground(PRIMARY);
        h.setForeground(Color.WHITE);
        h.setFont(new Font("Segoe UI", Font.BOLD, 13));
        h.setPreferredSize(new java.awt.Dimension(0, 38));
        h.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, PRIMARY_DARK));
        h.setOpaque(true);
        // Windows / System LAFs paint their own pale XP-style header and ignore
        // setBackground(), which leaves white text on a pale background (invisible).
        // This renderer paints the header background itself, so headers stay
        // visible on any LAF. It reads the header's live background, so panels
        // can still override it per-module via getTableHeader().setBackground(ACCENT).
        h.setDefaultRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean focus, int r, int c) {
                javax.swing.JLabel l = (javax.swing.JLabel)
                        super.getTableCellRendererComponent(t, v, false, false, r, c);
                Color bg = PRIMARY;
                try {
                    if (t != null && t.getTableHeader() != null
                            && t.getTableHeader().getBackground() != null) {
                        bg = t.getTableHeader().getBackground();
                    }
                } catch (Exception ignored) {}
                l.setBackground(bg);
                l.setForeground(Color.WHITE);
                l.setFont(new Font("Segoe UI", Font.BOLD, 13));
                l.setOpaque(true);
                l.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                l.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 2, 0, UIUtil.darken(bg)),
                        BorderFactory.createEmptyBorder(6, 8, 6, 8)));
                return l;
            }
        });
        // Center body cells to match centered headers (fixes left-shifted look).
        // Covers both text (Object) and numeric (Number, e.g. ID) columns.
        javax.swing.table.DefaultTableCellRenderer bodyCenter =
                new javax.swing.table.DefaultTableCellRenderer();
        bodyCenter.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        table.setDefaultRenderer(Object.class, bodyCenter);
        table.setDefaultRenderer(Number.class, bodyCenter);
    }

    /**
     * Clicking an already-selected row deselects it (toggle).
     * Default Swing keeps the row selected; with this, clicking the
     * selected row again clears the selection.
     *
     * <p>Implemented in the selection model (not a mouse listener) so it
     * works regardless of look-and-feel listener order: every plain click
     * routes through {@code setSelectionInterval}. Only a sole single-row
     * selection toggles, so Ctrl/Shift multi-select is untouched.
     */
    public static void enableToggleDeselect(final JTable table) {
        javax.swing.ListSelectionModel current = table.getSelectionModel();
        javax.swing.DefaultListSelectionModel toggle =
                new javax.swing.DefaultListSelectionModel() {
            @Override
            public void setSelectionInterval(int index0, int index1) {
                if (index0 == index1 && index0 >= 0 && !isSelectionEmpty()
                        && getMinSelectionIndex() == index0
                        && getMaxSelectionIndex() == index0) {
                    clearSelection();
                    return;
                }
                super.setSelectionInterval(index0, index1);
            }
        };
        toggle.setSelectionMode(current.getSelectionMode());
        table.setSelectionModel(toggle);
    }

    // ------------------------------------------------------------------
    // Dialogs
    // ------------------------------------------------------------------

    public static void showSuccess(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showError(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static boolean confirmDelete(Component parent, String item) {
        int r = JOptionPane.showConfirmDialog(parent,
                "Are you sure you want to delete " + item + "?\nThis action cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        return r == JOptionPane.YES_OPTION;
    }

    
    public static Color darken(Color c) {
        return new Color(Math.max(0, c.getRed() - 18),
                Math.max(0, c.getGreen() - 18),
                Math.max(0, c.getBlue() - 18));
    }
}
