package com.optimotion.utils;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.JTextComponent;


public class FloatingField extends JPanel {

    private final JTextComponent field;
    private final JLabel lblFloat;
    private final String placeholder;

    // Increased sizes (was 15 / 14 / 11)
    private static final float FIELD_SIZE = 17f;
    private static final float HINT_BIG = 16f;
    private static final float HINT_SMALL = 13f;

    private static final Color HINT_COLOR = new Color(110, 120, 135);
    private static final int PAD_X = 14;
    private static final int FIELD_Y = 22;
    private static final int FIELD_H = 20;
    private static final int LABEL_Y_IDLE = 21;
    private static final int LABEL_Y_FLOAT = 5;

    private static final int ANIM_MS = 180;
    private static final int TIMER_DELAY = 16;

    private float progress = 0f; // 0 = inside, 1 = floated on top
    private Timer animTimer;
    private long animStart;
    private float animFrom;
    private float animTo;

    public FloatingField(JTextComponent field, String placeholder) {
        super(null); // absolute layout for smooth slide
        this.field = field;
        this.placeholder = placeholder;

        setBackground(Color.WHITE);
        setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 18),
                new EmptyBorder(0, 0, 0, 0)));
        setPreferredSize(new Dimension(0, 48));
        setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        setMinimumSize(new Dimension(0, 48));

        lblFloat = new JLabel(placeholder);
        lblFloat.setFont(new Font("Segoe UI", Font.PLAIN, Math.round(HINT_BIG)));
        lblFloat.setForeground(HINT_COLOR);
        lblFloat.setOpaque(false);
        lblFloat.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                field.requestFocusInWindow();
            }
        });
        // Clicking empty padding focuses the field too
        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                field.requestFocusInWindow();
            }
        });

        field.setBorder(null);
        field.setOpaque(false);
        field.setBackground(new Color(0, 0, 0, 0));
        field.setFont(new Font("Segoe UI", Font.PLAIN, Math.round(FIELD_SIZE)));
        field.setForeground(UIUtil.TEXT_MAIN);
        field.setCaretColor(UIUtil.PRIMARY_DARK);

        add(lblFloat);
        add(field);

        field.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override public void focusGained(java.awt.event.FocusEvent e) {
                animateTo(1f);
                paintFocus(true);
            }
            @Override public void focusLost(java.awt.event.FocusEvent e) {
                if (currentText().isEmpty()) {
                    animateTo(0f);
                }
                paintFocus(false);
            }
        });
        field.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e) { sync(); }
            @Override public void removeUpdate(DocumentEvent e) { sync(); }
            @Override public void changedUpdate(DocumentEvent e) { sync(); }
            private void sync() {
                if (!currentText().isEmpty()) {
                    animateTo(1f);
                } else if (!field.hasFocus()) {
                    animateTo(0f);
                }
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override public void componentResized(java.awt.event.ComponentEvent e) {
                layoutChildren();
            }
        });

        // Initial state (login fields start empty)
        progress = currentText().isEmpty() ? 0f : 1f;
        applyProgress(progress);
        paintFocus(false);
    }

    private String currentText() {
        if (field instanceof JPasswordField) {
            return new String(((JPasswordField) field).getPassword());
        }
        return field.getText() == null ? "" : field.getText();
    }

    private void paintFocus(boolean focused) {
        setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(
                        focused ? UIUtil.PRIMARY : UIUtil.BORDER_DARK, 18,
                        focused ? 2 : 1, new Insets(0, 0, 0, 0)),
                new EmptyBorder(0, 0, 0, 0)));
        lblFloat.setForeground(focused ? UIUtil.PRIMARY_DARK : HINT_COLOR);
        repaint();
    }

    private void animateTo(float target) {
        if (Math.abs(progress - target) < 0.01f && (animTimer == null || !animTimer.isRunning())) {
            progress = target;
            applyProgress(progress);
            return;
        }
        if (animTimer != null && animTimer.isRunning()) {
            animTimer.stop();
        }
        animFrom = progress;
        animTo = target;
        animStart = System.currentTimeMillis();
        if (animTimer == null) {
            animTimer = new Timer(TIMER_DELAY, e -> {
                float t = (System.currentTimeMillis() - animStart) / (float) ANIM_MS;
                if (t >= 1f) {
                    t = 1f;
                }
                // easeOutCubic for a soft landing
                float eased = 1f - (float) Math.pow(1f - t, 3);
                progress = animFrom + (animTo - animFrom) * eased;
                applyProgress(progress);
                if (t >= 1f) {
                    ((Timer) e.getSource()).stop();
                }
            });
            animTimer.setRepeats(true);
        } else {
            // rewire existing timer
            for (java.awt.event.ActionListener al : animTimer.getActionListeners()) {
                animTimer.removeActionListener(al);
            }
            animTimer.addActionListener(e -> {
                float t = (System.currentTimeMillis() - animStart) / (float) ANIM_MS;
                if (t >= 1f) {
                    t = 1f;
                }
                float eased = 1f - (float) Math.pow(1f - t, 3);
                progress = animFrom + (animTo - animFrom) * eased;
                applyProgress(progress);
                if (t >= 1f) {
                    ((Timer) e.getSource()).stop();
                }
            });
        }
        animTimer.start();
    }

    private void applyProgress(float p) {
        float fontSize = HINT_BIG + (HINT_SMALL - HINT_BIG) * p;
        lblFloat.setFont(new Font("Segoe UI", Font.PLAIN, 12).deriveFont(fontSize));
        layoutChildren();
    }

    private void layoutChildren() {
        int w = getWidth();
        if (w <= 0) {
            w = 300;
        }
        int labelY = Math.round(LABEL_Y_IDLE + (LABEL_Y_FLOAT - LABEL_Y_IDLE) * progress);
        int labelH = progress > 0.5f ? 14 : 20;
        lblFloat.setBounds(PAD_X, labelY, w - PAD_X * 2, labelH);
        field.setBounds(PAD_X, FIELD_Y, w - PAD_X * 2, FIELD_H);
        // Keep label above field while sliding
        setComponentZOrder(lblFloat, 0);
        setComponentZOrder((Component) field, 1);
    }

    @Override
    public void doLayout() {
        super.doLayout();
        layoutChildren();
    }

    public JTextComponent getField() {
        return field;
    }

    // ---- Factories ----

    public static FloatingField forText(String placeholder, int columns) {
        return new FloatingField(new HintTextField(placeholder, columns), placeholder);
    }

    public static FloatingField forPassword(String placeholder, int columns) {
        HintPasswordField pf = new HintPasswordField(placeholder, columns);
        pf.setEchoChar('\u2022');
        return new FloatingField(pf, placeholder);
    }

    /** Plain text field (placeholder is drawn by the animated label). */
    public static class HintTextField extends JTextField {
        public HintTextField(String hint, int columns) {
            super(columns);
        }
    }

    /** Plain password field (placeholder is drawn by the animated label). */
    public static class HintPasswordField extends JPasswordField {
        public HintPasswordField(String hint, int columns) {
            super(columns);
        }
    }
}
