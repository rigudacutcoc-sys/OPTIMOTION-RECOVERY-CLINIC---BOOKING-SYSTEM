package com.optimotion.utils;

import com.optimotion.models.User;

public final class Session {

    public static final String ROLE_STAFF = "staff";
    public static final String ROLE_ADMIN = "administrator";

    private static User current;

    private Session() {}

    public static void login(User u) { current = u; }

    public static void logout() { current = null; }

    public static User current() { return current; }

    public static boolean isLoggedIn() { return current != null; }

    
    public static boolean isAdmin() {
        return current != null && ROLE_ADMIN.equalsIgnoreCase(current.getRole());
    }

    public static boolean isStaff() {
        return current != null && ROLE_STAFF.equalsIgnoreCase(current.getRole());
    }

    
    public static void requireAdmin() {
        if (!isAdmin()) {
            throw new SecurityException("Access denied: administrators only.");
        }
    }

    
    public static void requireLogin() {
        if (!isLoggedIn()) {
            throw new SecurityException("Access denied: please log in first.");
        }
    }

   
    public static boolean isValidRole(String role) {
        return ROLE_STAFF.equalsIgnoreCase(role) || ROLE_ADMIN.equalsIgnoreCase(role);
    }
}
