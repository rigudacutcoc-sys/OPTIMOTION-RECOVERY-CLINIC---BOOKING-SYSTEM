package com.optimotion.utils;

import java.util.regex.Pattern;


public class ValidationUtil {

    private static final Pattern EMAIL =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE =
            Pattern.compile("^[0-9+\\-\\s]{7,15}$");
    private static final Pattern NAME =
            Pattern.compile("^[\\p{L} .'-]{2,100}$");

    public static boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        if (isEmpty(email)) return true; // email optional in most forms
        return EMAIL.matcher(email.trim()).matches();
    }

    public static boolean isValidEmailRequired(String email) {
        return !isEmpty(email) && EMAIL.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return !isEmpty(phone) && PHONE.matcher(phone.trim()).matches();
    }

    /** Letters + space/dot/hyphen/apostrophe only, 2-100 chars, at least one letter. */
    public static boolean isValidName(String name) {
        if (isEmpty(name)) return false;
        String t = name.trim();
        return NAME.matcher(t).matches() && t.matches(".*\\p{L}.*");
    }

    /**
     * Blocks digits/symbols as typed/pasted: name accepts letters, space,
     * dot, hyphen, apostrophe only (no numbers).
     */
    public static void applyNameFilter(javax.swing.JTextField field) {
        javax.swing.text.AbstractDocument doc =
                (javax.swing.text.AbstractDocument) field.getDocument();
        doc.setDocumentFilter(new javax.swing.text.DocumentFilter() {
            private boolean ok(String s) {
                for (int i = 0; i < s.length(); i++) {
                    char ch = s.charAt(i);
                    if (!Character.isLetter(ch) && ch != ' ' && ch != '.'
                            && ch != '\'' && ch != '-' && ch != '\u00D1' && ch != '\u00F1') {
                        return false;
                    }
                }
                return true;
            }
            @Override
            public void insertString(FilterBypass fb, int off, String s,
                                     javax.swing.text.AttributeSet a)
                    throws javax.swing.text.BadLocationException {
                if (s == null || s.isEmpty() || !ok(s)
                        || fb.getDocument().getLength() + s.length() > 100) {
                    java.awt.Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.insertString(fb, off, s, a);
            }
            @Override
            public void replace(FilterBypass fb, int off, int len, String s,
                                javax.swing.text.AttributeSet a)
                    throws javax.swing.text.BadLocationException {
                if (s != null && !s.isEmpty() && (!ok(s)
                        || fb.getDocument().getLength() - len + s.length() > 100)) {
                    java.awt.Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.replace(fb, off, len, s, a);
            }
        });
    }

    /**
     * Blocks letters as typed/pasted: contact accepts digits, +, -, space
     * only (max 15 chars, matches PHONE save rule).
     */
    public static void applyContactFilter(javax.swing.JTextField field) {
        javax.swing.text.AbstractDocument doc =
                (javax.swing.text.AbstractDocument) field.getDocument();
        doc.setDocumentFilter(new javax.swing.text.DocumentFilter() {
            private boolean ok(String s) {
                for (int i = 0; i < s.length(); i++) {
                    char ch = s.charAt(i);
                    if (!(ch >= '0' && ch <= '9') && ch != '+' && ch != '-' && ch != ' ') {
                        return false;
                    }
                }
                return true;
            }
            @Override
            public void insertString(FilterBypass fb, int off, String s,
                                     javax.swing.text.AttributeSet a)
                    throws javax.swing.text.BadLocationException {
                if (s == null || s.isEmpty() || !ok(s)
                        || fb.getDocument().getLength() + s.length() > 15) {
                    java.awt.Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.insertString(fb, off, s, a);
            }
            @Override
            public void replace(FilterBypass fb, int off, int len, String s,
                                javax.swing.text.AttributeSet a)
                    throws javax.swing.text.BadLocationException {
                if (s != null && !s.isEmpty() && (!ok(s)
                        || fb.getDocument().getLength() - len + s.length() > 15)) {
                    java.awt.Toolkit.getDefaultToolkit().beep();
                    return;
                }
                super.replace(fb, off, len, s, a);
            }
        });
    }

    public static boolean isValidUsername(String u) {
        return u != null && u.trim().length() >= 4 && u.trim().matches("[A-Za-z0-9_.-]+");
    }

    public static boolean isValidPassword(String p) {
        return p != null && p.length() >= 6;
    }

    public static boolean isPositive(double v) {
        return v > 0;
    }
}
