package com.optimotion.models;

/** One row of the Administrator Sales Report (Paid payments only). */
public class SalesRecord {
    private int id;
    private String service;
    private String patient;
    private Integer staffUserId; // null = Unassigned
    private String staffName;
    private double total;

    public int getId() { return id; }
    public void setId(int v) { this.id = v; }
    public String getService() { return service; }
    public void setService(String v) { this.service = v; }
    public String getPatient() { return patient; }
    public void setPatient(String v) { this.patient = v; }
    public Integer getStaffUserId() { return staffUserId; }
    public void setStaffUserId(Integer v) { this.staffUserId = v; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String v) { this.staffName = v; }
    public double getTotal() { return total; }
    public void setTotal(double v) { this.total = v; }
}
