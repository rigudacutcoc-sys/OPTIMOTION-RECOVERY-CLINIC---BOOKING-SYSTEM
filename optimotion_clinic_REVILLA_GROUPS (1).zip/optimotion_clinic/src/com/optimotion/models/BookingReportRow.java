package com.optimotion.models;

/** One row of the Administrator Booking Report (active bookings). */
public class BookingReportRow {
    private int bookingId;
    private String patientName;
    private String patientPhone;
    private String service; // comma-joined treatment types, or "-"
    private String date;    // yyyy-MM-dd
    private String time;    // HH:mm
    private Integer staffUserId; // null = legacy unassigned
    private String staffName;
    private String status;

    public int getBookingId() { return bookingId; }
    public void setBookingId(int v) { this.bookingId = v; }
    public String getPatientName() { return patientName; }
    public void setPatientName(String v) { this.patientName = v; }
    public String getPatientPhone() { return patientPhone; }
    public void setPatientPhone(String v) { this.patientPhone = v; }
    public String getService() { return service; }
    public void setService(String v) { this.service = v; }
    public String getDate() { return date; }
    public void setDate(String v) { this.date = v; }
    public String getTime() { return time; }
    public void setTime(String v) { this.time = v; }
    public Integer getStaffUserId() { return staffUserId; }
    public void setStaffUserId(Integer v) { this.staffUserId = v; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String v) { this.staffName = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
}
