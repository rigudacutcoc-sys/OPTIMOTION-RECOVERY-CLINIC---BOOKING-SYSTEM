package com.optimotion.models;


public class Patient {
    private int id;
    private String fullName, gender, dob, phone, email, address, emergencyContact, medicalHistory;
    private boolean archived = false;

    public Patient() {}
    public Patient(int id, String fullName, String gender, String dob, String phone,
                   String email, String address, String emergencyContact, String medicalHistory) {
        this.id = id; this.fullName = fullName; this.gender = gender; this.dob = dob;
        this.phone = phone; this.email = email; this.address = address;
        this.emergencyContact = emergencyContact; this.medicalHistory = medicalHistory;
    }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getFullName() { return fullName; }
    public void setFullName(String v) { this.fullName = v; }
    public String getGender() { return gender; }
    public void setGender(String v) { this.gender = v; }
    public String getDob() { return dob; }
    public void setDob(String v) { this.dob = v; }
    public String getPhone() { return phone; }
    public void setPhone(String v) { this.phone = v; }
    public String getEmail() { return email; }
    public void setEmail(String v) { this.email = v; }
    public String getAddress() { return address; }
    public void setAddress(String v) { this.address = v; }
    public String getEmergencyContact() { return emergencyContact; }
    public void setEmergencyContact(String v) { this.emergencyContact = v; }
    public String getMedicalHistory() { return medicalHistory; }
    public void setMedicalHistory(String v) { this.medicalHistory = v; }
    public boolean isArchived() { return archived; }
    public void setArchived(boolean v) { this.archived = v; }
    @Override public String toString() { return id + " - " + fullName; }
}
