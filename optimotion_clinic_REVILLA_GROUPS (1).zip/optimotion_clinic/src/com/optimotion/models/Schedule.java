package com.optimotion.models;


public class Schedule {
    private int id;
    private Integer staffUserId; 
    private String staffName;
    private String schedDate;
    private String startTime;
    private String endTime;  
    private String status;    
    private String notes;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Integer getStaffUserId() { return staffUserId; }
    public void setStaffUserId(Integer v) { this.staffUserId = v; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String v) { this.staffName = v; }
    public String getSchedDate() { return schedDate; }
    public void setSchedDate(String v) { this.schedDate = v; }
    public String getStartTime() { return startTime; }
    public void setStartTime(String v) { this.startTime = v; }
    public String getEndTime() { return endTime; }
    public void setEndTime(String v) { this.endTime = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public String getNotes() { return notes; }
    public void setNotes(String v) { this.notes = v; }
}
