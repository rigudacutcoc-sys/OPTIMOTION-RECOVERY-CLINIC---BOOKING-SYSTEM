package com.optimotion.models;


public class Payment {
    private int id, patientId;
    private Integer treatmentId; // nullable
    private Integer staffUserId; // nullable: assigned staff for sales report (NEW)
    private String patientName;
    private String staffName; // joined users.full_name (read-only)
    private double amount;
    private String paymentDate, method, status;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int v) { this.patientId = v; }
    public Integer getTreatmentId() { return treatmentId; }
    public void setTreatmentId(Integer v) { this.treatmentId = v; }
    public Integer getStaffUserId() { return staffUserId; }
    public void setStaffUserId(Integer v) { this.staffUserId = v; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String v) { this.staffName = v; }
    public String getPatientName() { return patientName; }
    public void setPatientName(String v) { this.patientName = v; }
    public double getAmount() { return amount; }
    public void setAmount(double v) { this.amount = v; }
    public String getPaymentDate() { return paymentDate; }
    public void setPaymentDate(String v) { this.paymentDate = v; }
    public String getMethod() { return method; }
    public void setMethod(String v) { this.method = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
}
