package com.optimotion.models;

public class Service {
    private int id;
    private String name, description, status;
    private double price;
    private int durationMinutes;

    public Service() {}
    public Service(int id, String name, String description, double price,
                   int durationMinutes, String status) {
        this.id = id; this.name = name; this.description = description;
        this.price = price; this.durationMinutes = durationMinutes; this.status = status;
    }
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String v) { this.name = v; }
    public String getDescription() { return description; }
    public void setDescription(String v) { this.description = v; }
    public double getPrice() { return price; }
    public void setPrice(double v) { this.price = v; }
    public int getDurationMinutes() { return durationMinutes; }
    public void setDurationMinutes(int v) { this.durationMinutes = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    @Override public String toString() { return name + " (\u20B1 " + String.format("%.2f", price) + ")"; }
}
