package com.optimotion.models;

public class Appointment {
    private int id, patientId;
    private Integer staffUserId; // owner: users.id of the staff who booked (null = legacy)
    private String staffName; // joined users.full_name (read-only)
    private String patientName;
    private String appointmentDate; // "yyyy-MM-dd HH:mm"
    private String status, notes;
    private boolean archived = false;
    private String serviceTypes; // comma-separated treatment_type list (read-only, from treatments)
    private double totalAmount; // SUM(treatments.cost) for this booking (read-only)

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int v) { this.patientId = v; }
    public Integer getStaffUserId() { return staffUserId; }
    public void setStaffUserId(Integer v) { this.staffUserId = v; }
    public String getStaffName() { return staffName; }
    public void setStaffName(String v) { this.staffName = v; }
    public String getPatientName() { return patientName; }
    public void setPatientName(String v) { this.patientName = v; }
    public String getAppointmentDate() { return appointmentDate; }
    public void setAppointmentDate(String v) { this.appointmentDate = v; }
    public String getStatus() { return status; }
    public void setStatus(String v) { this.status = v; }
    public String getNotes() { return notes; }
    public void setNotes(String v) { this.notes = v; }
    public boolean isArchived() { return archived; }
    public void setArchived(boolean v) { this.archived = v; }
    public String getServiceTypes() { return serviceTypes; }
    public void setServiceTypes(String v) { this.serviceTypes = v; }
    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double v) { this.totalAmount = v; }
}
