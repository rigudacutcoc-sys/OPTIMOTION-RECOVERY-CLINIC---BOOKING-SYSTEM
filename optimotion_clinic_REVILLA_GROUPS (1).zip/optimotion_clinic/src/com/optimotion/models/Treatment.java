package com.optimotion.models;


public class Treatment {
    private int id, patientId;
    private Integer appointmentId;
    private Integer serviceId; // FK -> services.id (null = custom typed, legacy rows)
    private String patientName;
    private String treatmentType, description, sessionDate, progress;
    private int sessionCount;
    private double cost;
    private boolean archived = false;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getPatientId() { return patientId; }
    public void setPatientId(int v) { this.patientId = v; }
    public Integer getAppointmentId() { return appointmentId; }
    public void setAppointmentId(Integer v) { this.appointmentId = v; }
    public Integer getServiceId() { return serviceId; }
    public void setServiceId(Integer v) { this.serviceId = v; }
    public String getPatientName() { return patientName; }
    public void setPatientName(String v) { this.patientName = v; }
    public String getTreatmentType() { return treatmentType; }
    public void setTreatmentType(String v) { this.treatmentType = v; }
    public String getDescription() { return description; }
    public void setDescription(String v) { this.description = v; }
    public String getSessionDate() { return sessionDate; }
    public void setSessionDate(String v) { this.sessionDate = v; }
    public String getProgress() { return progress; }
    public void setProgress(String v) { this.progress = v; }
    public int getSessionCount() { return sessionCount; }
    public void setSessionCount(int v) { this.sessionCount = v; }
    public double getCost() { return cost; }
    public void setCost(double v) { this.cost = v; }
    public boolean isArchived() { return archived; }
    public void setArchived(boolean v) { this.archived = v; }
}
