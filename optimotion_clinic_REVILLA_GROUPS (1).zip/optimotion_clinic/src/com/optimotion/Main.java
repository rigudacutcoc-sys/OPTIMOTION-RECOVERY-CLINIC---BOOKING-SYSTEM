package com.optimotion;

import com.optimotion.utils.UIUtil;
import com.optimotion.views.LoginFrame;
import java.awt.Font;
import javax.swing.*;


public class Main {
    public static void main(String[] args) {
        
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e1) {
            try {
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        break;
                    }
                }
            } catch (Exception ignored) {
                // fall back to default L&F
            }
        }
        
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        try {
            Font f = new Font("Segoe UI", Font.PLAIN, 13);
            UIManager.put("Label.font", f);
            UIManager.put("Button.font", new Font("Segoe UI", Font.BOLD, 13));
            UIManager.put("TextField.font", f);
            UIManager.put("PasswordField.font", f);
            UIManager.put("Table.font", f);
        } catch (Exception ignored) {}
        UIUtil.applyModernDefaults();
        SwingUtilities.invokeLater(() -> new LoginFrame().setVisible(true));
    }
}
