package com.optimotion.views;

import com.optimotion.controllers.PatientController;
import com.optimotion.models.Patient;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class PatientPanel extends JPanel {

    private static final Color ACCENT = new Color(33, 150, 243); // blue

    private final PatientController ctrl = new PatientController();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Full Name", "Gender", "Date of Birth", "Phone", "Email", "Address"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JLabel lblSubtitle = new JLabel();
    private final JLabel lblCount = new JLabel();
    private final JScrollPane tableScroll = new JScrollPane();
    private final JPanel emptyPanel = new JPanel(new GridBagLayout());

    public PatientPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        // ---- Header banner ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("\u263A  Patient Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        lblSubtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblSubtitle.setForeground(new Color(225, 245, 254));
        lblSubtitle.setText("Manage patient records, contacts & medical history");
        left.add(title);
        left.add(lblSubtitle);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(180, 34));
        txtSearch.setToolTipText("Search name, phone, email or ID...");
        JButton btnSearch = ghostBtn("\uD83D\uDD0D Search");
        btnSearch.setPreferredSize(new Dimension(92, 34));
        searchBox.add(txtSearch);
        searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ---- Center: table card ----
        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        stripeTable();
        // accent header to match module
        table.getTableHeader().setBackground(ACCENT);
        // Readable proportions on wide screens; table still stretches on resize.
        table.getColumnModel().getColumn(0).setPreferredWidth(60);   // ID
        table.getColumnModel().getColumn(1).setPreferredWidth(170);  // Full Name
        table.getColumnModel().getColumn(2).setPreferredWidth(80);   // Gender
        table.getColumnModel().getColumn(3).setPreferredWidth(110);  // DOB
        table.getColumnModel().getColumn(4).setPreferredWidth(130);  // Phone
        table.getColumnModel().getColumn(5).setPreferredWidth(180);  // Email
        table.getColumnModel().getColumn(6).setPreferredWidth(200);  // Address
        // Friendly empty state (shown instead of an empty grid).
        emptyPanel.setBackground(Color.WHITE);
        JLabel lblEmpty = new JLabel(
                "<html><center><b>No patient records found.</b><br/>"
                + "Patients appear here automatically after booking.</center></html>",
                SwingConstants.CENTER);
        lblEmpty.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEmpty.setForeground(UIUtil.TEXT_MUTED);
        emptyPanel.add(lblEmpty);
        tableScroll.setBorder(null);
        tableScroll.setViewportView(table);
        card.add(tableScroll, BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        // ---- Footer (view-only): patients are created automatically via Bookings ----
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btns.setBackground(UIUtil.BG);
        JLabel ro = new JLabel("View-only: patients are added automatically when booking.");
        ro.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        ro.setForeground(UIUtil.TEXT_MUTED);
        btns.add(ro);
        footer.add(btns, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        txtSearch.addActionListener(e -> loadSearch());

        loadAll();
    }

    private JButton ghostBtn(String t) {
        return UIUtil.ghostButton(t, ACCENT.darker());
    }

    private JButton solidBtn(String t, Color bg) {
        return UIUtil.solidButton(t, bg);
    }

    private void stripeTable() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(javax.swing.SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                if (!sel) comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248,250,252));
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /** Reloads the list (called by the global Bookings refresh). */
    public void refresh() {
        txtSearch.setText("");
        loadAll();
    }

    private void loadAll() {
        try {
            fillTable(ctrl.getAll());
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load patients: " + ex.getMessage());
        }
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try {
            fillTable(ctrl.search(k));
        } catch (Exception ex) {
            UIUtil.showError(this, "Search failed: " + ex.getMessage());
        }
    }

    private void fillTable(List<Patient> list) {
        model.setRowCount(0);
        for (Patient p : list) {
            model.addRow(new Object[]{p.getId(), p.getFullName(), p.getGender(),
                    p.getDob(), p.getPhone(), p.getEmail(), p.getAddress()});
        }
        lblCount.setText("Total records: " + list.size());
        tableScroll.setViewportView(list.isEmpty() ? emptyPanel : table);
    }
}
