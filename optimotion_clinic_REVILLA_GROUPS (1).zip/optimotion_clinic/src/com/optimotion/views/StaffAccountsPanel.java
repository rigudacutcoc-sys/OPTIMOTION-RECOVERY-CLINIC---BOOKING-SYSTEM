package com.optimotion.views;

import com.optimotion.controllers.UserController;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class StaffAccountsPanel extends JPanel {

    private static final Color ACCENT = new Color(0, 121, 107); // teal dark

    private final UserController ctrl = new UserController();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Full Name", "Username", "Role", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JLabel lblCount = new JLabel();

    public StaffAccountsPanel(User user) {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        // Defense in depth: administrators only.
        if (user == null || !user.isAdmin()) {
            JPanel denied = new JPanel(new GridBagLayout());
            denied.setBackground(UIUtil.BG);
            denied.add(new JLabel("<html><center><h2>Access denied</h2>"
                    + "Staff accounts are for administrators only.</center></html>"));
            add(denied, BorderLayout.CENTER);
            return;
        }

        
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("\u263A  Staff Accounts");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Create staff logins, reset passwords & manage access");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(224, 242, 241));
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        txtSearch.setPreferredSize(new Dimension(200, 32));
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setToolTipText("Search name, username, role...");
        JButton btnSearch = UIUtil.ghostButton("\uD83D\uDD0D Search", ACCENT.darker());
        JButton btnRefresh = null; // removed: global Dashboard refresh
        searchBox.add(txtSearch);
        searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        
        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.getTableHeader().setBackground(ACCENT);
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btns.setBackground(UIUtil.BG);
        JButton btnAdd = UIUtil.solidButton("+ Create Staff", new Color(76, 175, 80));
        JButton btnReset = UIUtil.solidButton("Reset Password", new Color(33, 150, 243));
        JButton btnToggle = UIUtil.solidButton("Activate / Deactivate", new Color(255, 152, 0));
        JButton btnDelete = UIUtil.solidButton("\uD83D\uDDD1 Delete", new Color(211, 47, 47));
        btns.add(btnAdd);
        btns.add(btnReset);
        btns.add(btnToggle);
        btns.add(btnDelete);
        footer.add(btns, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        txtSearch.addActionListener(e -> loadSearch());
        btnAdd.addActionListener(e -> showCreateForm());
        btnReset.addActionListener(e -> resetSelected());
        btnToggle.addActionListener(e -> toggleSelected());
        btnDelete.addActionListener(e -> deleteSelected());

        loadAll();
    }

    /** Reloads the list (called by the global Dashboard refresh). */
    public void refresh() {
        txtSearch.setText("");
        loadAll();
    }

    private void loadAll() {
        try {
            fillTable(ctrl.getAll());
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load accounts: " + ex.getMessage());
        }
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try {
            fillTable(ctrl.search(k));
        } catch (Exception ex) {
            UIUtil.showError(this, "Search failed: " + ex.getMessage());
        }
    }

    private void fillTable(List<User> list) {
        model.setRowCount(0);
        for (User u : list) {
            model.addRow(new Object[]{
                    u.getId(),
                    u.getFullName(),
                    u.getUsername(),
                    u.getRole(),
                    u.isActive() ? "Active" : "Inactive"
            });
        }
        lblCount.setText("Total records: " + list.size());
    }

    private void showCreateForm() {
        JTextField fName = new JTextField(20);
        JTextField fUser = new JTextField(20);
        JPasswordField fPass = new JPasswordField(20);
        JPasswordField fConfirm = new JPasswordField(20);
        String[] roles = {"staff", "administrator"};
        JComboBox<String> fRole = new JComboBox<>(roles);
        fRole.setSelectedIndex(0);

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        form.add(new JLabel("Full Name*:"));
        form.add(fName);
        form.add(new JLabel("Username* (min 4 chars):"));
        form.add(fUser);
        form.add(new JLabel("Password* (min 6 chars):"));
        form.add(fPass);
        form.add(new JLabel("Confirm Password*:"));
        form.add(fConfirm);
        form.add(new JLabel("Role:"));
        form.add(fRole);

        int r = JOptionPane.showConfirmDialog(this, form, "Create Staff Account",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        String name = fName.getText().trim();
        String username = fUser.getText().trim();
        String pass = new String(fPass.getPassword());
        String conf = new String(fConfirm.getPassword());
        String role = (String) fRole.getSelectedItem();

        if (ValidationUtil.isEmpty(name)) {
            UIUtil.showError(this, "Full name is required.");
            return;
        }
        if (!ValidationUtil.isValidUsername(username)) {
            UIUtil.showError(this, "Username must be at least 4 characters (letters, numbers, _ . -).");
            return;
        }
        if (!ValidationUtil.isValidPassword(pass)) {
            UIUtil.showError(this, "Password must be at least 6 characters.");
            return;
        }
        if (!pass.equals(conf)) {
            UIUtil.showError(this, "Passwords do not match.");
            return;
        }

        try {
            boolean ok = ctrl.createUser(username, pass, name, role);
            if (ok) {
                UIUtil.showSuccess(this, "Account created for '" + username + "'.");
                loadAll();
            } else {
                UIUtil.showError(this, "Username already exists. Choose another.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Create failed: " + ex.getMessage());
        }
    }

    private int selectedId() {
        int row = table.getSelectedRow();
        if (row < 0) {
            UIUtil.showError(this, "Select an account first.");
            return -1;
        }
        return (int) model.getValueAt(row, 0);
    }

    private void resetSelected() {
        int id = selectedId();
        if (id < 0) return;
        String username = String.valueOf(model.getValueAt(table.getSelectedRow(), 2));
        JPasswordField fNew = new JPasswordField(20);
        JPanel form = new JPanel(new GridLayout(0, 1, 6, 6));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        form.add(new JLabel("New password for '" + username + "' (min 6 chars):"));
        form.add(fNew);
        int r = JOptionPane.showConfirmDialog(this, form, "Reset Password",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        try {
            if (ctrl.resetPassword(id, new String(fNew.getPassword()))) {
                UIUtil.showSuccess(this, "Password reset.");
            } else {
                UIUtil.showError(this, "Reset failed.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Reset failed: " + ex.getMessage());
        }
    }

    private void toggleSelected() {
        int row = table.getSelectedRow();
        int id = selectedId();
        if (id < 0) return;
        String status = String.valueOf(model.getValueAt(row, 4));
        boolean toActive = !"Active".equalsIgnoreCase(status);
        try {
            if (ctrl.setActive(id, toActive)) {
                UIUtil.showSuccess(this, toActive ? "Account activated." : "Account deactivated.");
                loadAll();
            } else {
                UIUtil.showError(this, "Update failed.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Update failed: " + ex.getMessage());
        }
    }

    private void deleteSelected() {
        int id = selectedId();
        if (id < 0) return;
        String username = String.valueOf(model.getValueAt(table.getSelectedRow(), 2));
        if (!UIUtil.confirmDelete(this, "account '" + username + "'")) return;
        try {
            if (ctrl.deleteUser(id)) {
                UIUtil.showSuccess(this, "Account deleted.");
                loadAll();
            } else {
                UIUtil.showError(this, "Delete failed.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Delete failed: " + ex.getMessage());
        }
    }
}
