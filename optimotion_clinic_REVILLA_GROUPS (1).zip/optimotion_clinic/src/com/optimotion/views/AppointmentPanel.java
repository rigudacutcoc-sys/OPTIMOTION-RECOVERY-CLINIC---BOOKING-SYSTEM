package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.ServiceController;
import com.optimotion.models.Appointment;
import com.optimotion.models.Patient;
import com.optimotion.models.Service;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class AppointmentPanel extends JPanel {

    private static final Color ACCENT = new Color(255, 152, 0); // orange

    private final AppointmentController ctrl = new AppointmentController();
    private final PatientController patientCtrl = new PatientController();
    private final ServiceController serviceCtrl = new ServiceController();

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Patient", "Date & Time", "Service Type", "Amount", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JLabel lblCount = new JLabel();
    // Patient filter: shows every booking for the selected patient, including
    // multiple same-day bookings (each row = separate Booking ID).
    private final JComboBox<String> cbPatientFilter = new JComboBox<>();
    private java.util.List<Patient> filterPatients = new java.util.ArrayList<>();

    private boolean showingArchived = false;
    private final JPanel btnsActive = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
    private final JPanel btnsArchived = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
    private JButton btnArchiveView;
    private final Runnable globalRefresh;

    public AppointmentPanel() {
        this(null);
    }

    /**
     * @param globalRefresh run when the header Refresh is pressed; when null,
     *                      Refresh only reloads this list. DashboardFrame passes
     *                      its global refresh so one click updates every page.
     */
    public AppointmentPanel(Runnable globalRefresh) {
        this.globalRefresh = globalRefresh;
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("Appointment Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Schedule, track & update patient visits");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(255, 243, 224));
        left.add(title); left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(150, 34));
        txtSearch.setToolTipText("Search patient, service, status, notes...");
        JButton btnSearch = ghostBtn("Search");
        JButton btnRefresh = ghostBtn("Refresh");
        btnRefresh.setToolTipText("Global refresh: reloads Dashboard, Appointments, Customers, Treatments, Payments, Schedule and Notifications");
        btnArchiveView = ghostBtn("Archived");
        btnArchiveView.setToolTipText("View archived appointments (restore or permanently delete)");
        for (JButton b : new JButton[]{btnSearch, btnRefresh, btnArchiveView}) {
            b.setPreferredSize(new Dimension(92, 34));
        }
        searchBox.add(txtSearch); searchBox.add(btnSearch); searchBox.add(btnRefresh);
        searchBox.add(btnArchiveView);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.getTableHeader().setBackground(ACCENT);
        stripeTable();
        fixColumnWidths();
        // Patient filter strip: pick a patient to list every booking for them,
        // including multiple same-day bookings (each row = separate Booking ID).
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        filterBar.setBackground(Color.WHITE);
        JLabel lblFilter = new JLabel("Patient:");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblFilter.setForeground(UIUtil.TEXT_MUTED);
        cbPatientFilter.setPreferredSize(new Dimension(260, 30));
        cbPatientFilter.setToolTipText("Show all appointments for the selected patient (same-day repeats listed separately)");
        JButton btnFilterClear = new JButton("Show All");
        btnFilterClear.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnFilterClear.setForeground(new Color(0, 105, 92));
        btnFilterClear.setBackground(new Color(224, 242, 241));
        btnFilterClear.setFocusPainted(false);
        btnFilterClear.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnFilterClear.setBorder(new UIUtil.RoundedBorder(new Color(178, 223, 219), 8));
        btnFilterClear.setPreferredSize(new Dimension(90, 30));
        JLabel lblHint = new JLabel("Multiple appointments per day allowed - each row is a separate Appointment ID.");
        lblHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblHint.setForeground(UIUtil.TEXT_MUTED);
        filterBar.add(lblFilter);
        filterBar.add(cbPatientFilter);
        filterBar.add(btnFilterClear);
        filterBar.add(lblHint);
        card.add(filterBar, BorderLayout.NORTH);
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btns.setBackground(UIUtil.BG);
        btnsActive.setBackground(UIUtil.BG);
        btnsArchived.setBackground(UIUtil.BG);
        JButton btnAdd = solidBtn("+ Appointment", new Color(76, 175, 80));
        Color bookGreen = new Color(76, 175, 80);
        JButton btnEdit = solidBtn("Reschedule", bookGreen);
        JButton btnStart = solidBtn("Start", bookGreen);
        btnStart.setToolTipText("Mark selected appointment as In Progress (other appointments untouched)");
        JButton btnComplete = solidBtn("Complete", bookGreen);
        JButton btnAddService = solidBtn("Add Service", bookGreen);
        btnAddService.setToolTipText("Add another service to the selected appointment (same Appointment ID)");
        JButton btnArchive = solidBtn("Archive", bookGreen);
        btnsActive.add(btnAdd); btnsActive.add(btnEdit);
        btnsActive.add(btnStart); btnsActive.add(btnComplete);
        btnsActive.add(btnAddService); btnsActive.add(btnArchive);
        JButton btnRestore = solidBtn("Restore", new Color(0, 150, 136));
        JButton btnDeletePerm = solidBtn("Delete", new Color(211, 47, 47));
        btnsArchived.add(btnRestore); btnsArchived.add(btnDeletePerm);
        btnsArchived.setVisible(false);
        btns.add(btnsActive); btns.add(btnsArchived);
        footer.add(btns, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        btnRefresh.addActionListener(e -> {
            if (globalRefresh != null) globalRefresh.run();
            else { txtSearch.setText(""); reloadPatientFilter(); loadAll(); }
        });
        txtSearch.addActionListener(e -> loadSearch());
        btnAdd.addActionListener(e -> showForm(null));
        btnEdit.addActionListener(e -> editSelected());
        btnStart.addActionListener(e -> setStatus("In Progress"));
        btnComplete.addActionListener(e -> setStatus("Completed"));
        btnAddService.addActionListener(e -> showAddServiceForm());
        btnArchive.addActionListener(e -> archiveSelected());
        btnRestore.addActionListener(e -> restoreSelected());
        btnDeletePerm.addActionListener(e -> deleteArchivedSelected());
        btnArchiveView.addActionListener(e -> toggleArchiveView());
        cbPatientFilter.addActionListener(e -> loadPatientFilterSelection());
        // Clear button is wired after filterBar creation (btnFilterClear local).
        for (java.awt.Component comp : ((JPanel) card.getComponent(0)).getComponents()) {
            if (comp instanceof JButton && "Show All".equals(((JButton) comp).getText())) {
                ((JButton) comp).addActionListener(ev -> {
                    cbPatientFilter.setSelectedIndex(0);
                    txtSearch.setText("");
                    loadAll();
                });
            }
        }

        reloadPatientFilter();
        loadAll();
    }

    private JButton ghostBtn(String t) {
        return UIUtil.ghostButton(t, ACCENT.darker());
    }

    private JButton solidBtn(String t, Color bg) {
        return UIUtil.solidButton(t, bg);
    }

    /**
     * Statuses offered when booking / rescheduling. "Confirmed" is retired
     * from the UI - existing Confirmed rows still display (see stripeTable)
     * but new bookings can no longer be set to Confirmed.
     */
    private static String[] bookableStatuses() {
        java.util.List<String> out = new java.util.ArrayList<>();
        for (String s : AppointmentController.STATUSES) {
            if (!"Confirmed".equals(s)) out.add(s);
        }
        return out.toArray(new String[0]);
    }

    private void stripeTable() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(javax.swing.SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                // Full text on hover - fixes cut-off Service Type
                // (e.g. "Electrotherapy, Hydrotherapy, Massa..").
                if (comp instanceof JComponent) {
                    ((JComponent) comp).setToolTipText(v == null ? null : v.toString());
                }
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248,250,252));
                    // Status is now column 5 (ID, Patient, Date & Time, Service Type, Amount, Status).
                    if (c == 5 && v != null) {
                        String s = v.toString();
                        if ("Scheduled".equals(s) || "Pending".equals(s)) {
                            comp.setForeground(new Color(230, 126, 0));
                        } else if ("In Progress".equals(s)) {
                            comp.setForeground(new Color(3, 169, 244));
                        } else if ("Completed".equals(s) || "Confirmed".equals(s)) {
                            comp.setForeground(new Color(46, 125, 50));
                        } else comp.setForeground(new Color(211, 47, 47));
                    } else comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /**
     * Gives Service Type ~3x the width of ID/Amount/Status so multi-service
     * bookings (e.g. "Electrotherapy, Hydrotherapy, Massage Therapy") are
     * not cut off. Hover tooltip (see stripeTable) still shows the full list.
     */
    private void fixColumnWidths() {
        // ID, Patient, Date & Time, Service Type, Amount, Status
        int[] w = {45, 140, 120, 340, 90, 110};
        try {
            if (table.getColumnModel().getColumnCount() == w.length) {
                for (int i = 0; i < w.length; i++) {
                    table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
                }
            }
            table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        } catch (Exception ignored) {}
    }

    /** Switches between the active list and the archive (restore / permanent delete). */
    private void toggleArchiveView() {
        showingArchived = !showingArchived;
        txtSearch.setText("");
        if (cbPatientFilter.getItemCount() > 0) cbPatientFilter.setSelectedIndex(0);
        table.clearSelection();
        btnsActive.setVisible(!showingArchived);
        btnsArchived.setVisible(showingArchived);
        btnArchiveView.setText(showingArchived ? "Active" : "Archived");
        loadAll();
    }

    /** Reloads this list (called by the global refresh in DashboardFrame). */
    public void refresh() {
        txtSearch.setText("");
        reloadPatientFilter();
        loadAll();
    }

    private void loadAll() {
        // If a patient filter is active, show every booking for that patient
        // (multiple same-day bookings appear as separate rows).
        if (cbPatientFilter.getSelectedIndex() > 0 && !showingArchived) {
            loadPatientFilterSelection();
            return;
        }
        try { fillTable(showingArchived ? ctrl.getArchived() : ctrl.getAll(), null); }
        catch (Exception ex) { UIUtil.showError(this, "Failed to load appointments: " + ex.getMessage()); }
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try { fillTable(showingArchived ? ctrl.searchArchived(k) : ctrl.search(k), null); }
        catch (Exception ex) { UIUtil.showError(this, "Search failed: " + ex.getMessage()); }
    }

    
    private void reloadPatientFilter() {
        try {
            Object keep = cbPatientFilter.getSelectedItem();
            filterPatients = patientCtrl.getAll();
            cbPatientFilter.removeAllItems();
            cbPatientFilter.addItem("All patients");
            for (Patient p : filterPatients) {
                String ph = p.getPhone() == null ? "" : p.getPhone();
                cbPatientFilter.addItem(p.getId() + " - " + p.getFullName() + " (" + ph + ")");
            }
            if (keep != null) {
                for (int i = 0; i < cbPatientFilter.getItemCount(); i++) {
                    if (keep.equals(cbPatientFilter.getItemAt(i))) {
                        cbPatientFilter.setSelectedIndex(i);
                        break;
                    }
                }
            }
        } catch (Exception ignored) {}
    }

    /** Shows all bookings for the patient picked in the filter (same-day repeats included). */
    private void loadPatientFilterSelection() {
        // Archived view stays global (restore/delete flow); patient filter applies to active list.
        if (showingArchived) {
            if (txtSearch.getText().trim().isEmpty()) {
                try { fillTable(ctrl.getArchived(), null); }
                catch (Exception ex) { UIUtil.showError(this, "Failed to load appointments: " + ex.getMessage()); }
            } else {
                loadSearch();
            }
            return;
        }
        int idx = cbPatientFilter.getSelectedIndex();
        if (idx <= 0) {
            if (txtSearch.getText().trim().isEmpty()) {
                try { fillTable(ctrl.getAll(), null); }
                catch (Exception ex) { UIUtil.showError(this, "Failed to load appointments: " + ex.getMessage()); }
            } else {
                loadSearch();
            }
            return;
        }
        if (idx - 1 >= filterPatients.size()) return;
        int pid = filterPatients.get(idx - 1).getId();
        try {
            java.util.List<Appointment> list = ctrl.getByPatient(pid);
            fillTable(list, filterPatients.get(idx - 1).getFullName());
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load patient bookings: " + ex.getMessage());
        }
    }

    private void fillTable(List<Appointment> list) {
        fillTable(list, null);
    }

    private void fillTable(List<Appointment> list, String patientFilterName) {
        model.setRowCount(0);
        for (Appointment a : list) {
            String svc = a.getServiceTypes();
            if (svc == null || svc.trim().isEmpty()) svc = "-";
            String amt = "\u20B1" + String.format("%.2f", a.getTotalAmount());
            model.addRow(new Object[]{a.getId(), a.getPatientName(),
                    a.getAppointmentDate(), svc, amt, a.getStatus()});
        }
        String prefix = showingArchived ? "Archived records: " : "Total records: ";
        if (patientFilterName != null) {
            lblCount.setText("Appointments for " + patientFilterName + ": " + list.size()
                    + " (same-day repeats listed separately)");
        } else {
            lblCount.setText(prefix + list.size());
        }
    }

    private void editSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select an appointment to update."); return; }
        int id = (int) model.getValueAt(row, 0);
        try {
            for (Appointment a : ctrl.getAllIncludingArchived()) {
                if (a.getId() == id) { showForm(a); return; }
            }
            UIUtil.showError(this, "Appointment no longer exists. Please refresh.");
        } catch (Exception ex) { UIUtil.showError(this, ex.getMessage()); }
    }

    /** One-click status change for the selected appointment (independent per Appointment ID). */
    private void setStatus(String status) {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select an appointment first."); return; }
        int id = (int) model.getValueAt(row, 0);
        try {
            if (ctrl.updateStatus(id, status)) {
                UIUtil.showSuccess(this, "Appointment #" + id + " marked as " + status + " (other appointments untouched).");
                reloadPatientFilter();
                loadAll();
            } else UIUtil.showError(this, "Update failed.");
        } catch (Exception ex) { UIUtil.showError(this, ex.getMessage()); }
    }

    /**
     * Adds another service to the SELECTED booking (same Booking ID).
     * Use this when the client wants an extra treatment in the same visit.
     * For a different time, use + Book instead (separate Booking ID).
     */
    private void showAddServiceForm() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select a booking first to add a service."); return; }
        int id = (int) model.getValueAt(row, 0);
        try {
            Appointment selected = null;
            for (Appointment a : ctrl.getAllIncludingArchived()) {
                if (a.getId() == id) { selected = a; break; }
            }
            if (selected == null) { UIUtil.showError(this, "Appointment no longer exists. Please refresh."); return; }
            if ("Cancelled".equals(selected.getStatus()) || "Completed".equals(selected.getStatus())) {
                UIUtil.showError(this, "Cannot add services to a " + selected.getStatus()
                        + " booking. Create an additional booking instead.");
                return;
            }
            java.util.List<String> current = ctrl.listTreatmentTypes(id);
            java.util.List<Service> services = serviceCtrl.getActive();
            if (services.isEmpty()) {
                UIUtil.showError(this, "No active services found. Ask an administrator to add services first.");
                return;
            }
            java.util.Set<String> curLower = new java.util.HashSet<>();
            for (String t : current) curLower.add(t.toLowerCase());
            java.awt.Window owner = javax.swing.SwingUtilities.getWindowAncestor(this);
            final JDialog dlg = new JDialog(owner, "Add Service - Booking #" + id,
                    java.awt.Dialog.ModalityType.APPLICATION_MODAL);
            JPanel banner = new JPanel(new BorderLayout(0, 2));
            banner.setBackground(new Color(0, 121, 107));
            banner.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
            JLabel hTitle = new JLabel("ADD SERVICE - BOOKING #" + id);
            hTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
            hTitle.setForeground(Color.WHITE);
            String staff = selected.getStaffName();
            if (staff == null || staff.trim().isEmpty()) staff = "Unassigned";
            JLabel hSub = new JLabel("<html>" + escHtml(selected.getPatientName()) + " &bull; "
                    + escHtml(selected.getAppointmentDate()) + " &bull; " + escHtml(staff)
                    + "<br>Same visit (same Booking ID). For a different time, use + Book instead.</html>");
            hSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            hSub.setForeground(new Color(224, 242, 241));
            banner.add(hTitle, BorderLayout.NORTH);
            banner.add(hSub, BorderLayout.SOUTH);
            JPanel body = new JPanel();
            body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
            body.setBackground(Color.WHITE);
            body.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
            JLabel lblCur = new JLabel("Current services: "
                    + (current.isEmpty() ? "-" : String.join(", ", current)));
            lblCur.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            lblCur.setForeground(UIUtil.TEXT_MUTED);
            lblCur.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            body.add(lblCur);
            body.add(Box.createVerticalStrut(8));
            body.add(cap("ADDITIONAL SERVICE  (tick one or more, duplicates disabled)"));
            body.add(Box.createVerticalStrut(4));
            JPanel checkPanel = new JPanel();
            checkPanel.setLayout(new BoxLayout(checkPanel, BoxLayout.Y_AXIS));
            checkPanel.setBackground(Color.WHITE);
            final java.util.LinkedHashMap<Integer, JCheckBox> checks = new java.util.LinkedHashMap<>();
            final java.util.Map<Integer, Service> byId = new java.util.HashMap<>();
            int enabledCount = 0;
            for (Service s : services) {
                byId.put(s.getId(), s);
                boolean dup = s.getName() != null && curLower.contains(s.getName().trim().toLowerCase());
                String label = s.getName() + "  (\u20B1" + String.format("%.2f", s.getPrice())
                        + " \u2022 " + s.getDurationMinutes() + " min)"
                        + (dup ? "  - already added" : "");
                JCheckBox cb = new JCheckBox(label);
                cb.setBackground(Color.WHITE);
                cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                if (dup) { cb.setEnabled(false); cb.setToolTipText("Already linked to this booking"); }
                else { enabledCount++; checks.put(s.getId(), cb); }
                checkPanel.add(cb);
            }
            JScrollPane sc = new JScrollPane(checkPanel);
            sc.setPreferredSize(new Dimension(520, 140));
            sc.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                    BorderFactory.createEmptyBorder(4, 4, 4, 4)));
            body.add(sc);
            body.add(Box.createVerticalStrut(8));
            JLabel lblNote = new JLabel("<html><i>Extended duration is re-checked against "
                    + "same-patient and same-staff overlaps. Status stays unchanged.</i></html>");
            lblNote.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            lblNote.setForeground(UIUtil.TEXT_MUTED);
            body.add(lblNote);
            if (enabledCount == 0) {
                body.add(Box.createVerticalStrut(6));
                JLabel lblAll = new JLabel("All active services are already linked to this booking.");
                lblAll.setForeground(new Color(211, 47, 47));
                body.add(lblAll);
            }
            JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
            btnBar.setBackground(Color.WHITE);
            btnBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtil.BORDER));
            JButton btnSave = UIUtil.solidButton("Add Service(s)", new Color(0, 121, 107));
            btnSave.setPreferredSize(new Dimension(170, 38));
            btnSave.setEnabled(enabledCount > 0);
            JButton btnCancel = neutralBtn("Cancel");
            btnBar.add(btnCancel);
            btnBar.add(btnSave);
            styleBookingInputs(body);
            dlg.getContentPane().setLayout(new BorderLayout());
            dlg.getContentPane().add(banner, BorderLayout.NORTH);
            dlg.getContentPane().add(body, BorderLayout.CENTER);
            dlg.getContentPane().add(btnBar, BorderLayout.SOUTH);
            btnCancel.addActionListener(e -> dlg.dispose());
            btnSave.addActionListener(e -> {
                try {
                    java.util.List<Integer> sel = new java.util.ArrayList<>();
                    for (java.util.Map.Entry<Integer, JCheckBox> en : checks.entrySet()) {
                        if (en.getValue().isSelected()) sel.add(en.getKey());
                    }
                    if (sel.isEmpty()) {
                        UIUtil.showError(dlg, "Tick at least one new service.");
                        return;
                    }
                    java.util.List<Integer> tids = ctrl.addServicesToBooking(id, sel);
                    dlg.dispose();
                    UIUtil.showSuccess(this, "Added " + tids.size()
                            + " service(s) to Booking #" + id + " (same visit, status unchanged).");
                    reloadPatientFilter();
                    loadAll();
                } catch (Exception ex2) {
                    UIUtil.showError(dlg, "Add failed: " + ex2.getMessage());
                }
            });
            dlg.pack();
            try {
                java.awt.Rectangle maxB = java.awt.GraphicsEnvironment
                        .getLocalGraphicsEnvironment().getMaximumWindowBounds();
                if (dlg.getHeight() > maxB.height - 20) {
                    dlg.setSize(dlg.getWidth(), maxB.height - 20);
                }
            } catch (Exception ignored) {}
            dlg.setLocationRelativeTo(null);
            dlg.setVisible(true);
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to open Add Service: " + ex.getMessage());
        }
    }

    /** Archives the selected active booking (restorable; cascades to customer/treatments). */
    private void archiveSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select a booking to archive."); return; }
        int id = (int) model.getValueAt(row, 0);
        int r = JOptionPane.showConfirmDialog(this,
                "Archive booking ID " + id + "?\nIt will be hidden from the active list.\nYou can restore it later from the Archived view.",
                "Archive Booking", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r != JOptionPane.YES_OPTION) return;
        try {
            if (ctrl.archive(id)) { UIUtil.showSuccess(this, "Booking archived."); loadAll(); }
            else UIUtil.showError(this, "Archive failed.");
        } catch (Exception ex) { UIUtil.showError(this, "Archive failed: " + ex.getMessage()); }
    }

    /** Restores an archived booking (plus its customer, treatments and payments). */
    private void restoreSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select an archived booking to restore."); return; }
        int id = (int) model.getValueAt(row, 0);
        try {
            if (ctrl.restore(id)) { UIUtil.showSuccess(this, "Booking restored."); loadAll(); }
            else UIUtil.showError(this, "Restore failed.");
        } catch (Exception ex) { UIUtil.showError(this, "Restore failed: " + ex.getMessage()); }
    }

    /** Permanently deletes an archived booking (only available inside the Archived view). */
    private void deleteArchivedSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select an archived booking to delete."); return; }
        int id = (int) model.getValueAt(row, 0);
        if (!UIUtil.confirmDelete(this, "archived booking ID " + id)) return;
        try {
            if (ctrl.delete(id)) { UIUtil.showSuccess(this, "Archived booking permanently deleted."); loadAll(); }
            else UIUtil.showError(this, "Delete failed.");
        } catch (Exception ex) { UIUtil.showError(this, "Delete failed: " + ex.getMessage()); }
    }

    private void showForm(Appointment existing) {
        if (existing == null) {
            showCreateForm();
            return;
        }
        showRescheduleForm(existing);
    }

    /**
     * NEW WORKFLOW: Bookings -&gt; + Book -&gt; Enter/Select Patient + Treatment + Appointment.
     * No prerequisite: opens even when no patients exist yet.
     * Delegates to AppointmentController.createFullBooking (single transaction):
     * resolve/reuse patient (phone dedupe) -&gt; insert appointment -&gt; auto-create linked treatment.
     */
    private void showCreateForm() {
        try {
            List<Patient> patients = patientCtrl.getAll();
            List<Service> services = serviceCtrl.getActive();
            if (services.isEmpty()) {
                UIUtil.showError(this, "No active services found. Ask an administrator to add services first.");
                return;
            }

            java.awt.Window owner = javax.swing.SwingUtilities.getWindowAncestor(this);
            final JDialog dlg = new JDialog(owner, "Book Appointment",
                    java.awt.Dialog.ModalityType.APPLICATION_MODAL);

            // ---- Banner: dark-teal identity (orange stays as accent in sections/buttons) ----
            JPanel banner = new JPanel(new BorderLayout(12, 2));
            banner.setBackground(new Color(0, 105, 92));
            banner.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
            JPanel bannerText = new JPanel(new BorderLayout(0, 2));
            bannerText.setOpaque(false);
            JLabel hTitle = new JLabel("BOOK APPOINTMENT");
            hTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
            hTitle.setForeground(Color.WHITE);
            JLabel hSub = new JLabel("Multiple bookings per day allowed - even at the same time");
            hSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            hSub.setForeground(new Color(178, 223, 219));
            bannerText.add(hTitle, BorderLayout.NORTH);
            bannerText.add(hSub, BorderLayout.SOUTH);
            banner.add(bannerText, BorderLayout.CENTER);
            // Fullscreen toggle: white ghost button so it is clearly visible on the teal banner.
            final JButton btnFull = UIUtil.ghostButton("\u26F6 Fullscreen", new Color(0, 105, 92).darker());
            btnFull.setPreferredSize(new Dimension(130, 34));
            btnFull.setToolTipText("Toggle fullscreen (F11) - fit the whole form on screen");
            banner.add(btnFull, BorderLayout.EAST);
            final java.awt.Rectangle[] normalBounds = new java.awt.Rectangle[1];
            final boolean[] isFull = new boolean[]{false};
            Runnable toggleFull = () -> {
                try {
                    if (!isFull[0]) {
                        normalBounds[0] = dlg.getBounds();
                        java.awt.Rectangle maxB = java.awt.GraphicsEnvironment
                                .getLocalGraphicsEnvironment().getMaximumWindowBounds();
                        dlg.setBounds(maxB);
                        btnFull.setText("\u26F6 Restore");
                        isFull[0] = true;
                    } else {
                        if (normalBounds[0] != null) {
                            dlg.setBounds(normalBounds[0]);
                        } else {
                            dlg.pack();
                            dlg.setLocationRelativeTo(null);
                        }
                        btnFull.setText("\u26F6 Fullscreen");
                        isFull[0] = false;
                    }
                } catch (Exception ignored) {}
            };
            btnFull.addActionListener(e -> toggleFull.run());
            // F11 shortcut for the same toggle.
            try {
                dlg.getRootPane().getInputMap(javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW)
                        .put(javax.swing.KeyStroke.getKeyStroke("F11"), "toggleFull");
                dlg.getRootPane().getActionMap().put("toggleFull",
                        new javax.swing.AbstractAction() {
                            @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                                toggleFull.run();
                            }
                        });
            } catch (Exception ignored) {}

            // ---- Section 1: patient picker + fields (mirrors patients table columns) ----
            final JComboBox<String> cbPick = new JComboBox<>();
            cbPick.addItem("+ New Patient");
            for (Patient p : patients) {
                String ph = p.getPhone() == null ? "" : p.getPhone();
                cbPick.addItem(p.getId() + " - " + p.getFullName() + " (" + ph + ")");
            }
            cbPick.setSelectedIndex(0);

            final JTextField fName = new JTextField(20);
            final JTextField fPhone = new JTextField(20);
            // Typing rules: name = letters only (no numbers), contact = numbers only (no letters).
            ValidationUtil.applyNameFilter(fName);
            ValidationUtil.applyContactFilter(fPhone);
            fName.setToolTipText("Letters only - numbers are blocked as you type");
            fPhone.setToolTipText("Numbers only (7-15 chars, + - space allowed) - letters are blocked");
            final JComboBox<String> fGender = new JComboBox<>(new String[]{"Male", "Female", "Other"});
            final JTextField fDob = new JTextField(20);
            fDob.setToolTipText("yyyy-MM-dd (optional, leave blank if unknown)");
            final JTextField fEmail = new JTextField(20);
            final JTextField fAddr = new JTextField(20);
            final JTextField fEmerg = new JTextField(20);
            ValidationUtil.applyContactFilter(fEmerg);
            fEmerg.setToolTipText("Numbers only - letters are blocked");
            final JTextArea fHist = new JTextArea(2, 20);
            fHist.setLineWrap(true);
            fHist.setWrapStyleWord(true);

            final java.util.List<JComponent> patientInputs = java.util.Arrays.<JComponent>asList(
                    fName, fPhone, fGender, fDob, fEmail, fAddr, fEmerg, fHist);

            // Read-only summary shown when an existing patient is picked.
            final JLabel vName = new JLabel();
            final JLabel vPhone = new JLabel();
            final JLabel vGender = new JLabel();
            final JLabel vDob = new JLabel();
            final JLabel vEmail = new JLabel();
            for (JLabel v : new JLabel[]{vName, vPhone, vGender, vDob, vEmail}) {
                v.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                v.setForeground(UIUtil.TEXT_MAIN);
            }
            final JPanel summaryGrid = new JPanel(new GridLayout(0, 2, 10, 6));
            summaryGrid.setBackground(new Color(248, 250, 252));
            summaryGrid.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER, 10),
                    BorderFactory.createEmptyBorder(10, 12, 10, 12)));
            summaryGrid.add(cap("NAME")); summaryGrid.add(vName);
            summaryGrid.add(cap("CONTACT")); summaryGrid.add(vPhone);
            summaryGrid.add(cap("GENDER")); summaryGrid.add(vGender);
            summaryGrid.add(cap("DATE OF BIRTH")); summaryGrid.add(vDob);
            summaryGrid.add(cap("EMAIL")); summaryGrid.add(vEmail);
            summaryGrid.setVisible(false);

            // Primary fields in a two-column grid; email spans the full width.
            final JPanel primaryGrid = new JPanel(new GridBagLayout());
            primaryGrid.setBackground(Color.WHITE);
            GridBagConstraints pg = new GridBagConstraints();
            pg.fill = GridBagConstraints.HORIZONTAL;
            pg.weightx = 1.0;
            pg.insets = new Insets(3, 6, 3, 6);
            pg.gridx = 0; pg.gridy = 0; pg.gridwidth = 1;
            primaryGrid.add(cap("FULL NAME *"), pg);
            pg.gridx = 1;
            primaryGrid.add(cap("CONTACT NUMBER *"), pg);
            pg.gridx = 0; pg.gridy = 1;
            primaryGrid.add(fName, pg);
            pg.gridx = 1;
            primaryGrid.add(fPhone, pg);
            pg.gridx = 0; pg.gridy = 2;
            primaryGrid.add(cap("GENDER"), pg);
            pg.gridx = 1;
            primaryGrid.add(cap("DATE OF BIRTH"), pg);
            pg.gridx = 0; pg.gridy = 3;
            primaryGrid.add(fGender, pg);
            pg.gridx = 1;
            primaryGrid.add(fDob, pg);
            pg.gridx = 0; pg.gridy = 4; pg.gridwidth = 2;
            primaryGrid.add(cap("EMAIL  (optional)"), pg);
            pg.gridy = 5;
            primaryGrid.add(fEmail, pg);
            pg.gridwidth = 1;

            // Secondary fields tucked into an expandable area (never removed).
            final JPanel extraPanel = new JPanel();
            extraPanel.setLayout(new BoxLayout(extraPanel, BoxLayout.Y_AXIS));
            extraPanel.setBackground(Color.WHITE);
            extraPanel.add(cap("ADDRESS"));
            extraPanel.add(fAddr);
            extraPanel.add(Box.createVerticalStrut(6));
            extraPanel.add(cap("EMERGENCY CONTACT"));
            extraPanel.add(fEmerg);
            extraPanel.add(Box.createVerticalStrut(6));
            extraPanel.add(cap("MEDICAL HISTORY"));
            extraPanel.add(new JScrollPane(fHist));
            extraPanel.setVisible(false);
            final JToggleButton btnMore = new JToggleButton(
                    "+ Additional information (address, emergency contact, medical history)");
            btnMore.setFont(new Font("Segoe UI", Font.BOLD, 12));
            btnMore.setForeground(new Color(0, 105, 92));
            btnMore.setContentAreaFilled(false);
            btnMore.setBorderPainted(false);
            btnMore.setFocusable(false);
            btnMore.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnMore.setHorizontalAlignment(SwingConstants.LEFT);
            btnMore.addActionListener(e -> {
                boolean show = btnMore.isSelected();
                btnMore.setText(show
                        ? "- Additional information (address, emergency contact, medical history)"
                        : "+ Additional information (address, emergency contact, medical history)");
                extraPanel.setVisible(show);
                // Don't exit fullscreen when expanding details.
                if (!isFull[0]) dlg.pack();
                else { dlg.revalidate(); dlg.repaint(); }
            });

            // Fill + lock fields when an existing patient is picked; clear + unlock for new.
            Runnable applyMode = () -> {
                int idx = cbPick.getSelectedIndex();
                if (idx <= 0) {
                    fName.setText("");
                    fPhone.setText("");
                    fGender.setSelectedIndex(0);
                    fDob.setText("");
                    fEmail.setText("");
                    fAddr.setText("");
                    fEmerg.setText("");
                    fHist.setText("");
                    for (JComponent c : patientInputs) c.setEnabled(true);
                    primaryGrid.setVisible(true);
                    btnMore.setVisible(true);
                    summaryGrid.setVisible(false);
                } else {
                    Patient p = patients.get(idx - 1);
                    fName.setText(p.getFullName() == null ? "" : p.getFullName());
                    fPhone.setText(p.getPhone() == null ? "" : p.getPhone());
                    String g = p.getGender();
                    if ("Male".equals(g) || "Female".equals(g) || "Other".equals(g)) fGender.setSelectedItem(g);
                    else fGender.setSelectedIndex(0);
                    fDob.setText(p.getDob() == null ? "" : p.getDob());
                    fEmail.setText(p.getEmail() == null ? "" : p.getEmail());
                    fAddr.setText(p.getAddress() == null ? "" : p.getAddress());
                    fEmerg.setText(p.getEmergencyContact() == null ? "" : p.getEmergencyContact());
                    fHist.setText(p.getMedicalHistory() == null ? "" : p.getMedicalHistory());
                    vName.setText(dash(p.getFullName()));
                    vPhone.setText(dash(p.getPhone()));
                    vGender.setText(dash(p.getGender()));
                    vDob.setText(dash(p.getDob()));
                    vEmail.setText(dash(p.getEmail()));
                    for (JComponent c : patientInputs) c.setEnabled(false);
                    primaryGrid.setVisible(false);
                    btnMore.setSelected(false);
                    btnMore.setText("+ Additional information (address, emergency contact, medical history)");
                    extraPanel.setVisible(false);
                    btnMore.setVisible(false);
                    summaryGrid.setVisible(true);
                }
                // Stay in fullscreen when switching patients - pack() would shrink it.
                if (!isFull[0]) dlg.pack();
                else { dlg.revalidate(); dlg.repaint(); }
            };
            cbPick.addActionListener(e -> applyMode.run());

            JPanel patBody = new JPanel();
            patBody.setLayout(new BoxLayout(patBody, BoxLayout.Y_AXIS));
            patBody.setBackground(Color.WHITE);
            JPanel pickStack = new JPanel(new BorderLayout(0, 2));
            pickStack.setBackground(Color.WHITE);
            pickStack.add(cap("PATIENT"), BorderLayout.NORTH);
            pickStack.add(cbPick, BorderLayout.CENTER);
            patBody.add(pickStack);
            patBody.add(Box.createVerticalStrut(8));
            patBody.add(summaryGrid);
            patBody.add(primaryGrid);
            patBody.add(Box.createVerticalStrut(4));
            patBody.add(btnMore);
            patBody.add(extraPanel);

            // ---- Section 2: treatment / service MULTI-SELECT (checkboxes) ----
            // One booking can include several services; each becomes one row in
            // treatments (treatments.appointment_id -> appointments.id).
            final java.util.List<Service> svcList = services;
            final java.util.LinkedHashMap<Integer, JCheckBox> svcChecks = new java.util.LinkedHashMap<>();
            final java.util.Map<Integer, Service> svcById = new java.util.HashMap<>();
            final JPanel svcCheckPanel = new JPanel();
            svcCheckPanel.setLayout(new BoxLayout(svcCheckPanel, BoxLayout.Y_AXIS));
            svcCheckPanel.setBackground(Color.WHITE);
            for (Service s : svcList) {
                svcById.put(s.getId(), s);
                String label = s.getName() + "  (\u20B1" + String.format("%.2f", s.getPrice())
                        + " \u2022 " + s.getDurationMinutes() + " min)";
                JCheckBox cb = new JCheckBox(label);
                cb.setBackground(Color.WHITE);
                cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                cb.setForeground(UIUtil.TEXT_MAIN);
                cb.setFocusable(false);
                String tip = s.getDescription() == null ? "" : s.getDescription().trim();
                if (!tip.isEmpty()) cb.setToolTipText(tip);
                svcCheckPanel.add(cb);
                svcChecks.put(s.getId(), cb);
            }
            final JLabel lblSvcTotal = new JLabel();
            lblSvcTotal.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblSvcTotal.setForeground(new Color(0, 105, 92));
            Runnable refreshSvcTotal = () -> {
                int n = 0;
                double total = 0;
                int mins = 0;
                for (java.util.Map.Entry<Integer, JCheckBox> e : svcChecks.entrySet()) {
                    if (e.getValue().isSelected()) {
                        Service s = svcById.get(e.getKey());
                        if (s != null) {
                            n++;
                            total += s.getPrice();
                            mins += s.getDurationMinutes();
                        }
                    }
                }
                if (n == 0) {
                    lblSvcTotal.setText("Tick at least one service (required).");
                    lblSvcTotal.setForeground(UIUtil.TEXT_MUTED);
                } else {
                    lblSvcTotal.setText("Selected: " + n + " service(s)  \u2022  Total: \u20B1"
                            + String.format("%.2f", total) + "  \u2022  Duration: " + mins + " min");
                    lblSvcTotal.setForeground(new Color(0, 105, 92));
                }
            };
            for (JCheckBox cb : svcChecks.values()) cb.addActionListener(e -> refreshSvcTotal.run());
            refreshSvcTotal.run();
            JScrollPane svcScroll = new JScrollPane(svcCheckPanel,
                    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            // Compact so DATE/TIME/STATUS stay reachable without deep scrolling.
            svcScroll.setPreferredSize(new Dimension(0, 96));
            svcScroll.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                    BorderFactory.createEmptyBorder(4, 4, 4, 4)));
            svcScroll.getVerticalScrollBar().setUnitIncrement(12);
            JPanel svcQuickRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            svcQuickRow.setBackground(Color.WHITE);
            JButton btnSvcAll = new JButton("Select All");
            JButton btnSvcClear = new JButton("Clear");
            for (JButton b : new JButton[]{btnSvcAll, btnSvcClear}) {
                b.setFont(new Font("Segoe UI", Font.BOLD, 11));
                b.setForeground(new Color(0, 105, 92));
                b.setBackground(new Color(224, 242, 241));
                b.setFocusPainted(false);
                b.setCursor(new Cursor(Cursor.HAND_CURSOR));
                b.setBorder(new UIUtil.RoundedBorder(new Color(178, 223, 219), 8));
                b.setPreferredSize(new Dimension(95, 28));
            }
            btnSvcAll.addActionListener(e -> {
                for (JCheckBox cb : svcChecks.values()) cb.setSelected(true);
                refreshSvcTotal.run();
            });
            btnSvcClear.addActionListener(e -> {
                for (JCheckBox cb : svcChecks.values()) cb.setSelected(false);
                refreshSvcTotal.run();
            });
            svcQuickRow.add(btnSvcAll);
            svcQuickRow.add(btnSvcClear);
            JPanel svcBody = new JPanel();
            svcBody.setLayout(new BoxLayout(svcBody, BoxLayout.Y_AXIS));
            svcBody.setBackground(Color.WHITE);
            // Section title already says "(select one or more)" - no duplicate caption.
            svcBody.add(svcScroll);
            svcBody.add(Box.createVerticalStrut(6));
            svcBody.add(lblSvcTotal);
            svcBody.add(Box.createVerticalStrut(6));
            svcBody.add(svcQuickRow);

            // ---- Section 3: appointment date / time / status / notes ----
            String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
            final JComboBox<String> cbMonth = new JComboBox<>(monthNames);
            final JComboBox<Integer> cbDay = new JComboBox<>();
            final JComboBox<Integer> cbYear = new JComboBox<>();
            int curYear = java.time.LocalDate.now().getYear();
            for (int y = curYear - 1; y <= curYear + 2; y++) cbYear.addItem(y);
            Runnable refillDays = () -> {
                Object keep = cbDay.getSelectedItem();
                int max = java.time.YearMonth.of((Integer) cbYear.getSelectedItem(),
                        cbMonth.getSelectedIndex() + 1).lengthOfMonth();
                cbDay.removeAllItems();
                for (int d = 1; d <= max; d++) cbDay.addItem(d);
                if (keep instanceof Integer && (Integer) keep <= max) cbDay.setSelectedItem(keep);
            };
            cbMonth.addActionListener(e -> refillDays.run());
            cbYear.addActionListener(e -> refillDays.run());
            refillDays.run();
            java.time.LocalDate today = java.time.LocalDate.now();
            cbYear.setSelectedItem(today.getYear());
            cbMonth.setSelectedIndex(today.getMonthValue() - 1);
            refillDays.run();
            int maxD = java.time.YearMonth.of(today.getYear(), today.getMonthValue()).lengthOfMonth();
            cbDay.setSelectedItem(Math.min(today.getDayOfMonth(), maxD));

            // Single time dropdown built from clinic operating hours + slot length.
            // Same "HH:mm" values as before flow into the unchanged booking validation.
            final JComboBox<String> cbTime = new JComboBox<>();
            final java.util.List<String> timeValues = new java.util.ArrayList<>();
            try {
                com.optimotion.controllers.SettingsController tsc =
                        new com.optimotion.controllers.SettingsController();
                String openS = tsc.openTime();
                String closeS = tsc.closeTime();
                int step = 60;
                try { step = Integer.parseInt(tsc.get("slot_minutes", "60").trim()); }
                catch (Exception ignored2) { step = 60; }
                if (step <= 0 || step > 720) step = 60;
                java.time.LocalTime tOpen = java.time.LocalTime.parse(openS.trim());
                java.time.LocalTime tClose = java.time.LocalTime.parse(closeS.trim());
                java.time.format.DateTimeFormatter vFmt =
                        java.time.format.DateTimeFormatter.ofPattern("HH:mm");
                java.time.format.DateTimeFormatter dFmt =
                        java.time.format.DateTimeFormatter.ofPattern("h:mm a");
                for (java.time.LocalTime t = tOpen; !t.isAfter(tClose); t = t.plusMinutes(step)) {
                    timeValues.add(t.format(vFmt));
                    cbTime.addItem(t.format(dFmt));
                }
            } catch (Exception ignored) { }
            if (cbTime.getItemCount() == 0) {
                timeValues.add("08:00");
                cbTime.addItem("8:00 AM");
            }
            int defIdx = timeValues.indexOf("10:00");
            cbTime.setSelectedIndex(defIdx >= 0 ? defIdx : 0);

            JPanel dateRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
            dateRow.setBackground(Color.WHITE);
            dateRow.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            dateRow.add(new JLabel("Month:"));
            dateRow.add(cbMonth);
            dateRow.add(new JLabel("Day:"));
            dateRow.add(cbDay);
            dateRow.add(new JLabel("Year:"));
            dateRow.add(cbYear);

            final JComboBox<String> fStatus = new JComboBox<>(bookableStatuses());
            fStatus.setSelectedItem("Scheduled");
            fStatus.setPreferredSize(new Dimension(220, 34));
            cbTime.setPreferredSize(new Dimension(220, 34));

            JPanel apptBody = new JPanel();
            apptBody.setLayout(new BoxLayout(apptBody, BoxLayout.Y_AXIS));
            apptBody.setBackground(Color.WHITE);
            // Fixed width so HTML wraps instead of stretching the dialog.
            JLabel lblMultiHint = new JLabel(
                    "<html><div style='width:660px'>Same patient may book again the same day "
                    + "with a different time/service. Each booking gets its own Booking ID. "
                    + "Different patients may even share the same time.</div></html>");
            lblMultiHint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            lblMultiHint.setForeground(new Color(0, 105, 92));
            lblMultiHint.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            // Cap heights so DATE/TIME/STATUS are not pushed below the fold.
            lblMultiHint.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            apptBody.add(lblMultiHint);
            apptBody.add(Box.createVerticalStrut(4));
            final JLabel lblExistingDay = new JLabel();
            lblExistingDay.setFont(new Font("Segoe UI", Font.PLAIN, 11));
            lblExistingDay.setForeground(UIUtil.TEXT_MUTED);
            lblExistingDay.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
            lblExistingDay.setMaximumSize(new Dimension(Integer.MAX_VALUE, 32));
            apptBody.add(lblExistingDay);
            apptBody.add(Box.createVerticalStrut(4));
            apptBody.add(cap("DATE"));
            apptBody.add(dateRow);
            apptBody.add(Box.createVerticalStrut(4));
            apptBody.add(cap("TIME"));
            apptBody.add(leftWrap(cbTime));
            apptBody.add(Box.createVerticalStrut(4));
            apptBody.add(cap("STATUS"));
            apptBody.add(leftWrap(fStatus));

            // Live preview: all bookings for the picked patient on the picked day.
            // Proves same-day repeats are listed separately (own Booking IDs).
            Runnable refreshExistingDay = () -> {
                try {
                    if (cbPick.getSelectedIndex() <= 0) {
                        lblExistingDay.setText("New patient - no existing bookings.");
                        return;
                    }
                    int pid = patients.get(cbPick.getSelectedIndex() - 1).getId();
                    String day = String.format("%04d-%02d-%02d",
                            (Integer) cbYear.getSelectedItem(),
                            cbMonth.getSelectedIndex() + 1,
                            (Integer) cbDay.getSelectedItem());
                    java.util.List<Appointment> dayList = ctrl.getByPatientAndDate(pid, day);
                    if (dayList.isEmpty()) {
                        java.util.List<Appointment> all = ctrl.getByPatient(pid);
                        lblExistingDay.setText("This patient has " + all.size()
                                + " booking(s) total, none on " + day
                                + ". Same-day booking allowed - pick any free time.");
                    } else {
                        StringBuilder sb = new StringBuilder();
                        sb.append("This patient already has ").append(dayList.size())
                          .append(" booking(s) on ").append(day).append(": ");
                        for (int i = 0; i < dayList.size(); i++) {
                            Appointment a = dayList.get(i);
                            if (i > 0) sb.append(", ");
                            sb.append("#").append(a.getId()).append(" at ")
                              .append(a.getAppointmentDate().length() >= 16
                                      ? a.getAppointmentDate().substring(11, 16) : a.getAppointmentDate());
                        }
                        sb.append(". Another time is fine if it does not overlap.");
                        lblExistingDay.setText("<html>" + sb.toString() + "</html>");
                    }
                } catch (Exception ignored) {
                    lblExistingDay.setText("");
                }
            };
            cbPick.addActionListener(e -> refreshExistingDay.run());
            cbMonth.addActionListener(e -> refreshExistingDay.run());
            cbDay.addActionListener(e -> refreshExistingDay.run());
            cbYear.addActionListener(e -> refreshExistingDay.run());
            cbTime.addActionListener(e -> refreshExistingDay.run());
            refreshExistingDay.run();

            // ---- Assemble body: three cards on a light background ----
            JPanel body = new JPanel();
            body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
            body.setBackground(UIUtil.BG);
            body.setBorder(BorderFactory.createEmptyBorder(14, 14, 14, 14));
            addBookSection(body, "PATIENT INFORMATION", patBody);
            body.add(Box.createVerticalStrut(12));
            addBookSection(body, "TREATMENT / SERVICES (select one or more)", svcBody);
            body.add(Box.createVerticalStrut(12));
            addBookSection(body, "APPOINTMENT DETAILS", apptBody);

            JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
            btnBar.setBackground(Color.WHITE);
            btnBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtil.BORDER));
            JButton btnBook = UIUtil.solidButton("Book Appointment", new Color(46, 125, 50));
            btnBook.setPreferredSize(new Dimension(180, 38));
            JButton btnCancel = new JButton("Cancel");
            btnCancel.setBackground(Color.WHITE);
            btnCancel.setForeground(new Color(51, 65, 85));
            btnCancel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            btnCancel.setFocusPainted(false);
            btnCancel.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnCancel.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
            btnCancel.setPreferredSize(new Dimension(140, 38));
            final Color cancelBase = Color.WHITE;
            final Color cancelHover = new Color(241, 245, 249);
            btnCancel.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override public void mouseEntered(java.awt.event.MouseEvent e) { btnCancel.setBackground(cancelHover); }
                @Override public void mouseExited(java.awt.event.MouseEvent e) { btnCancel.setBackground(cancelBase); }
            });
            btnBar.add(btnCancel);
            btnBar.add(btnBook);

            // Taller pickers for easier clicking, then uniform modern inputs.
            Dimension pkSize = cbPick.getPreferredSize();
            cbPick.setPreferredSize(new Dimension(pkSize.width, 36));
            styleBookingInputs(body);

            JScrollPane scroll = new JScrollPane(body,
                    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            // Fit inside the usable screen (excludes taskbar) so the
            // Cancel/Book bar never ends up off-screen. DATE/TIME/STATUS
            // are reached by scrolling the middle area only.
            int availH = 700;
            try {
                java.awt.Rectangle maxBounds = java.awt.GraphicsEnvironment
                        .getLocalGraphicsEnvironment().getMaximumWindowBounds();
                availH = maxBounds.height;
            } catch (Exception ex2) {
                try { availH = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height - 80; }
                catch (Exception ignored) { availH = 700; }
            }
            // banner (~80) + buttons (~62) + title bar/margins (~60) = ~200 reserved.
            int scrollH = Math.max(320, Math.min(560, availH - 220));
            scroll.setPreferredSize(new Dimension(760, scrollH));
            scroll.setBorder(null);
            scroll.getVerticalScrollBar().setUnitIncrement(16);
            // Start at top so PATIENT INFORMATION is seen first; user scrolls
            // down once to reach DATE/TIME/STATUS (now much closer).
            javax.swing.SwingUtilities.invokeLater(() -> {
                try { scroll.getVerticalScrollBar().setValue(0); } catch (Exception ignored) {}
            });
            dlg.getContentPane().setLayout(new BorderLayout());
            dlg.getContentPane().add(banner, BorderLayout.NORTH);
            dlg.getContentPane().add(scroll, BorderLayout.CENTER);
            dlg.getContentPane().add(btnBar, BorderLayout.SOUTH);

            btnCancel.addActionListener(e -> dlg.dispose());
            btnBook.addActionListener(e -> {
                try {
                    // ---- Validation + patient payload ----
                    Integer existingPatientId = null;
                    Patient newPatient = null;
                    boolean forceNewSeparate = false;
                    if (cbPick.getSelectedIndex() <= 0) {
                        String nm = fName.getText().trim();
                        String ph = fPhone.getText().trim();
                        if (nm.isEmpty()) {
                            UIUtil.showError(dlg, "Patient name cannot be empty.");
                            return;
                        }
                        if (!ValidationUtil.isValidName(nm)) {
                            UIUtil.showError(dlg, "Full name must contain letters only (no numbers).");
                            return;
                        }
                        if (ph.isEmpty()) {
                            UIUtil.showError(dlg, "Contact number cannot be empty.");
                            return;
                        }
                        if (!ValidationUtil.isValidPhone(ph)) {
                            UIUtil.showError(dlg, "Enter a valid contact number (7-15 digits, + - space allowed).");
                            return;
                        }
                        // Same name (case-insensitive): could be repeat visit OR
                        // different person with same name. Ask instead of blocking.
                        String normNm = nm.replaceAll("\\s+", " ").trim();
                        Patient nameMatch = null;
                        for (Patient ep : patients) {
                            String ef = ep.getFullName() == null ? ""
                                    : ep.getFullName().replaceAll("\\s+", " ").trim();
                            if (!ef.isEmpty() && ef.equalsIgnoreCase(normNm)) {
                                nameMatch = ep;
                                break;
                            }
                        }
                        if (nameMatch != null) {
                            int choice = javax.swing.JOptionPane.showConfirmDialog(dlg,
                                    "A client named \"" + nameMatch.getFullName() + "\" already exists (ID "
                                    + nameMatch.getId() + ", " + nameMatch.getPhone() + ").\n"
                                    + "You typed: \"" + nm + "\" (" + ph + ").\n\n"
                                    + "Yes = Book under EXISTING client (repeat visit)\n"
                                    + "No = Create as NEW separate client (different person)\n"
                                    + "Cancel = Go back and edit",
                                    "Possible duplicate client",
                                    javax.swing.JOptionPane.YES_NO_CANCEL_OPTION,
                                    javax.swing.JOptionPane.QUESTION_MESSAGE);
                            if (choice == javax.swing.JOptionPane.CANCEL_OPTION
                                    || choice == javax.swing.JOptionPane.CLOSED_OPTION) {
                                return;
                            }
                            if (choice == javax.swing.JOptionPane.YES_OPTION) {
                                existingPatientId = nameMatch.getId();
                            } else if (choice == javax.swing.JOptionPane.NO_OPTION) {
                                // Explicit "create as NEW separate client" — even with
                                // the same name (and same phone). Passed to the
                                // controller to skip phone-dedupe reuse.
                                forceNewSeparate = true;
                            }
                        }
                        if (existingPatientId == null) {
                        if (!ValidationUtil.isValidEmail(fEmail.getText())) {
                            UIUtil.showError(dlg, "Enter a valid email or leave it blank.");
                            return;
                        }
                        String dobVal = fDob.getText().trim();
                        if (!dobVal.isEmpty()) {
                            if (!dobVal.matches("\\d{4}-\\d{2}-\\d{2}")) {
                                UIUtil.showError(dlg, "Birth date must be yyyy-MM-dd or empty.");
                                return;
                            }
                            if (dobVal.compareTo(java.time.LocalDate.now().toString()) > 0) {
                                UIUtil.showError(dlg, "Date of birth cannot be in the future.");
                                return;
                            }
                        }
                        newPatient = new Patient();
                        newPatient.setFullName(nm);
                        newPatient.setGender((String) fGender.getSelectedItem());
                        newPatient.setDob(dobVal);
                        newPatient.setPhone(ph);
                        newPatient.setEmail(fEmail.getText().trim());
                        newPatient.setAddress(fAddr.getText().trim());
                        newPatient.setEmergencyContact(fEmerg.getText().trim());
                        newPatient.setMedicalHistory(fHist.getText().trim());
                        }
                    } else {
                        existingPatientId = patients.get(cbPick.getSelectedIndex() - 1).getId();
                    }

                    java.util.List<Integer> selIds = new java.util.ArrayList<>();
                    java.util.List<String> selNames = new java.util.ArrayList<>();
                    for (java.util.Map.Entry<Integer, JCheckBox> e2 : svcChecks.entrySet()) {
                        if (e2.getValue().isSelected()) {
                            selIds.add(e2.getKey());
                            Service ss = svcById.get(e2.getKey());
                            if (ss != null) selNames.add(ss.getName());
                        }
                    }
                    if (selIds.isEmpty()) {
                        UIUtil.showError(dlg, "Please tick at least one treatment/service.");
                        return;
                    }

                    if (cbTime.getSelectedIndex() < 0
                            || cbTime.getSelectedIndex() >= timeValues.size()) {
                        UIUtil.showError(dlg, "Please select a time.");
                        return;
                    }
                    String dateTime = String.format("%04d-%02d-%02d %s",
                            (Integer) cbYear.getSelectedItem(),
                            cbMonth.getSelectedIndex() + 1,
                            (Integer) cbDay.getSelectedItem(),
                            timeValues.get(cbTime.getSelectedIndex()));

                    AppointmentController.BookingResult br = ctrl.createFullBooking(
                            newPatient, existingPatientId, selIds, dateTime,
                            (String) fStatus.getSelectedItem(), "", forceNewSeparate);
                    dlg.dispose();
                    String msg = (br.reusedPatient
                            ? "Existing patient reused (ID " + br.patientId + ", no duplicate created).\n"
                            : "New patient created (ID " + br.patientId + ").\n")
                            + "Appointment #" + br.appointmentId + " booked with "
                            + String.join(", ", selNames) + ".\n"
                            + "Multiple bookings per day allowed - each has its own Booking ID.";
                    UIUtil.showSuccess(this, msg);
                    reloadPatientFilter();
                    loadAll();
                } catch (Exception ex) {
                    UIUtil.showError(dlg, "Save failed: " + ex.getMessage());
                }
            });

            // Focus starts in Full Name (not on the dropdown) so no dotted focus rect shows.
            dlg.addWindowListener(new java.awt.event.WindowAdapter() {
                @Override public void windowOpened(java.awt.event.WindowEvent e) {
                    fName.requestFocusInWindow();
                }
            });
            dlg.pack();
            // Never let the dialog grow taller than the usable screen (taskbar
            // excluded) - otherwise Cancel/Book ends up off-screen.
            try {
                java.awt.Rectangle maxB = java.awt.GraphicsEnvironment
                        .getLocalGraphicsEnvironment().getMaximumWindowBounds();
                java.awt.Dimension d = dlg.getSize();
                int maxW = Math.min(d.width, maxB.width - 40);
                int maxH2 = Math.min(d.height, maxB.height - 20);
                if (d.height > maxH2 || d.width > maxW) {
                    dlg.setSize(maxW, maxH2);
                }
            } catch (Exception ignored) {}
            dlg.setLocationRelativeTo(null);
            dlg.setVisible(true);
        } catch (Exception ex) {
            UIUtil.showError(this, "Save failed: " + ex.getMessage());
        }
    }

    /** White card with a dark-teal title + short orange accent rule; body goes below. */
    private void addBookSection(JPanel parent, String title, JComponent bodyPart) {
        JPanel card = new JPanel(new BorderLayout(0, 0));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 12),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        JPanel head = new JPanel(new BorderLayout(0, 5));
        head.setBackground(Color.WHITE);
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.BOLD, 13));
        t.setForeground(new Color(0, 105, 92));
        JPanel ruleWrap = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        ruleWrap.setBackground(Color.WHITE);
        JPanel rule = new JPanel();
        rule.setBackground(ACCENT);
        rule.setPreferredSize(new Dimension(44, 3));
        ruleWrap.add(rule);
        head.add(t, BorderLayout.NORTH);
        head.add(ruleWrap, BorderLayout.SOUTH);
        head.setBorder(BorderFactory.createEmptyBorder(0, 0, 8, 0));
        card.add(head, BorderLayout.NORTH);
        card.add(bodyPart, BorderLayout.CENTER);
        parent.add(card);
    }

    /** Small muted caption placed above booking fields. */
    private JLabel cap(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(UIUtil.TEXT_MUTED);
        l.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return l;
    }

    /** Left-aligned white wrapper that keeps a control at its preferred size. */
    private JPanel leftWrap(JComponent c) {
        JPanel w = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        w.setBackground(Color.WHITE);
        w.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        w.add(c);
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        return w;
    }

    private static String dash(String s) {
        return (s == null || s.trim().isEmpty()) ? "-" : s.trim();
    }

    private static String escHtml(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /**
     * Uniform modern inputs inside the booking dialog: rounded borders,
     * comfortable heights, white background. Combos are set non-focusable
     * so the dotted focus rectangle never shows; they still open with the mouse.
     */
    private void styleBookingInputs(java.awt.Container root) {
        for (java.awt.Component c : root.getComponents()) {
            if (c instanceof JTextField) {
                JTextField f = (JTextField) c;
                f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                f.setBackground(Color.WHITE);
                f.setBorder(BorderFactory.createCompoundBorder(
                        new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                        BorderFactory.createEmptyBorder(2, 8, 2, 8)));
                Dimension d = f.getPreferredSize();
                f.setPreferredSize(new Dimension(d.width, 32));
            } else if (c instanceof JComboBox) {
                JComboBox<?> cb = (JComboBox<?>) c;
                cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                cb.setBackground(Color.WHITE);
                cb.setFocusable(false);
                cb.setBorder(BorderFactory.createCompoundBorder(
                        new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                        BorderFactory.createEmptyBorder(2, 4, 2, 4)));
            } else if (c instanceof JTextArea) {
                JTextArea a = (JTextArea) c;
                a.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                a.setBackground(Color.WHITE);
            }
            if (c instanceof java.awt.Container) styleBookingInputs((java.awt.Container) c);
        }
    }

    private void showRescheduleForm(Appointment existing) {
        final List<Patient> patients;
        try {
            patients = patientCtrl.getAll();
        } catch (Exception ex) {
            UIUtil.showError(this, ex.getMessage());
            return;
        }
        if (patients.isEmpty()) {
            UIUtil.showError(this, "Add at least one patient first.");
            return;
        }
        final JComboBox<String> cbPatient = new JComboBox<>();
        for (Patient p : patients) cbPatient.addItem(p.getId() + " - " + p.getFullName());

        // ---- Date & time picker: no typing needed ----
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        final JComboBox<String> cbMonth = new JComboBox<>(monthNames);
        final JComboBox<Integer> cbDay = new JComboBox<>();
        final JComboBox<Integer> cbYear = new JComboBox<>();
        int curYear = java.time.LocalDate.now().getYear();
        for (int y = curYear - 1; y <= curYear + 2; y++) cbYear.addItem(y);
        // Full time options so any time can be picked/recorded.
        // Operating-hours rule is still enforced on save (see AppointmentController).
        int openH = 8;
        try {
            com.optimotion.controllers.SettingsController sc =
                    new com.optimotion.controllers.SettingsController();
            openH = Integer.parseInt(sc.openTime().substring(0, 2));
        } catch (Exception ignored) { }
        final JComboBox<String> cbHour = new JComboBox<>();
        for (int hh = 0; hh < 24; hh++) cbHour.addItem(String.format("%02d", hh));
        final JComboBox<String> cbMinute = new JComboBox<>();
        for (int mm = 0; mm < 60; mm++) cbMinute.addItem(String.format("%02d", mm));
        Runnable refillDays = () -> {
            Object keep = cbDay.getSelectedItem();
            int max = java.time.YearMonth.of((Integer) cbYear.getSelectedItem(),
                    cbMonth.getSelectedIndex() + 1).lengthOfMonth();
            cbDay.removeAllItems();
            for (int d = 1; d <= max; d++) cbDay.addItem(d);
            if (keep instanceof Integer && (Integer) keep <= max) cbDay.setSelectedItem(keep);
        };
        cbMonth.addActionListener(e -> refillDays.run());
        cbYear.addActionListener(e -> refillDays.run());
        refillDays.run();
        // Fixed widths so month/day/year and hour/minute are never cut off.
        cbMonth.setPreferredSize(new Dimension(78, 32));
        cbDay.setPreferredSize(new Dimension(64, 32));
        cbYear.setPreferredSize(new Dimension(86, 32));
        cbHour.setPreferredSize(new Dimension(64, 32));
        cbMinute.setPreferredSize(new Dimension(64, 32));
        JPanel dateRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        dateRow.setBackground(Color.WHITE);
        dateRow.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        dateRow.add(new JLabel("Month:"));
        dateRow.add(cbMonth);
        dateRow.add(new JLabel("Day:"));
        dateRow.add(cbDay);
        dateRow.add(new JLabel("Year:"));
        dateRow.add(cbYear);
        JPanel timeRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        timeRow.setBackground(Color.WHITE);
        timeRow.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        timeRow.add(cbHour);
        timeRow.add(new JLabel(":"));
        timeRow.add(cbMinute);
        JLabel hint24 = new JLabel("(24-hour)");
        hint24.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint24.setForeground(Color.GRAY);
        timeRow.add(hint24);

        final JComboBox<String> fStatus = new JComboBox<>(bookableStatuses());
        // Old rows may still be Confirmed - show it so the record displays
        // correctly; user can move it to any other status but not back.
        if ("Confirmed".equals(existing.getStatus())) fStatus.addItem("Confirmed");
        fStatus.setPreferredSize(new Dimension(220, 32));

        java.time.LocalDate today = java.time.LocalDate.now();
        selectById(cbPatient, existing.getPatientId());
        String dt = existing.getAppointmentDate() == null ? "" : existing.getAppointmentDate();
        if (dt.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
            cbYear.setSelectedItem(Integer.parseInt(dt.substring(0, 4)));
            cbMonth.setSelectedIndex(Integer.parseInt(dt.substring(5, 7)) - 1);
            refillDays.run();
            cbDay.setSelectedItem(Integer.parseInt(dt.substring(8, 10)));
            cbHour.setSelectedItem(dt.substring(11, 13));
            cbMinute.setSelectedItem(dt.substring(14, 16));
        } else {
            setDateDefaults(cbYear, cbMonth, cbDay, cbHour, cbMinute, today, openH);
        }
        fStatus.setSelectedItem(existing.getStatus());

        java.awt.Window owner = javax.swing.SwingUtilities.getWindowAncestor(this);
        final JDialog dlg = new JDialog(owner, "Reschedule Booking",
                java.awt.Dialog.ModalityType.APPLICATION_MODAL);

        JPanel banner = new JPanel(new BorderLayout(12, 2));
        banner.setBackground(ACCENT);
        banner.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        JPanel bannerText2 = new JPanel(new BorderLayout(0, 2));
        bannerText2.setOpaque(false);
        JLabel hTitle = new JLabel("RESCHEDULE BOOKING #" + existing.getId());
        hTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        hTitle.setForeground(Color.WHITE);
        JLabel hSub = new JLabel("Same-day repeats allowed - overlapping times blocked");
        hSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        hSub.setForeground(new Color(255, 243, 224));
        bannerText2.add(hTitle, BorderLayout.NORTH);
        bannerText2.add(hSub, BorderLayout.SOUTH);
        banner.add(bannerText2, BorderLayout.CENTER);
        final JButton btnFull2 = UIUtil.ghostButton("\u26F6 Fullscreen", ACCENT.darker());
        btnFull2.setPreferredSize(new Dimension(130, 34));
        btnFull2.setToolTipText("Toggle fullscreen (F11)");
        banner.add(btnFull2, BorderLayout.EAST);
        final java.awt.Rectangle[] normalB2 = new java.awt.Rectangle[1];
        final boolean[] isFull2 = new boolean[]{false};
        Runnable toggleFull2 = () -> {
            try {
                if (!isFull2[0]) {
                    normalB2[0] = dlg.getBounds();
                    java.awt.Rectangle maxB = java.awt.GraphicsEnvironment
                            .getLocalGraphicsEnvironment().getMaximumWindowBounds();
                    dlg.setBounds(maxB);
                    btnFull2.setText("\u26F6 Restore");
                    isFull2[0] = true;
                } else {
                    if (normalB2[0] != null) dlg.setBounds(normalB2[0]);
                    else { dlg.pack(); dlg.setLocationRelativeTo(null); }
                    btnFull2.setText("\u26F6 Fullscreen");
                    isFull2[0] = false;
                }
            } catch (Exception ignored) {}
        };
        btnFull2.addActionListener(e -> toggleFull2.run());
        try {
            dlg.getRootPane().getInputMap(javax.swing.JComponent.WHEN_IN_FOCUSED_WINDOW)
                    .put(javax.swing.KeyStroke.getKeyStroke("F11"), "toggleFull2");
            dlg.getRootPane().getActionMap().put("toggleFull2",
                    new javax.swing.AbstractAction() {
                        @Override public void actionPerformed(java.awt.event.ActionEvent e) {
                            toggleFull2.run();
                        }
                    });
        } catch (Exception ignored) {}

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
        String staffLine = existing.getStaffName();
        if (staffLine == null || staffLine.trim().isEmpty()) staffLine = "Unassigned";
        JLabel lblMeta = new JLabel("<html>Booking ID: <b>#" + existing.getId()
                + "</b> &nbsp;&bull;&nbsp; Assigned staff: <b>" + escHtml(staffLine) + "</b><br>"
                + "<i>Each booking keeps its own ID. Moving to an overlapping time for the same "
                + "patient will be blocked.</i></html>");
        lblMeta.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblMeta.setForeground(UIUtil.TEXT_MUTED);
        lblMeta.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        body.add(lblMeta);
        body.add(Box.createVerticalStrut(8));
        body.add(cap("PATIENT"));
        body.add(Box.createVerticalStrut(2));
        body.add(fullWidthLike(cbPatient));
        body.add(Box.createVerticalStrut(8));
        body.add(cap("DATE"));
        body.add(Box.createVerticalStrut(2));
        body.add(dateRow);
        body.add(Box.createVerticalStrut(8));
        body.add(cap("TIME"));
        body.add(Box.createVerticalStrut(2));
        body.add(timeRow);
        body.add(Box.createVerticalStrut(8));
        body.add(cap("STATUS"));
        body.add(Box.createVerticalStrut(2));
        body.add(leftWrap(fStatus));

        dateRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        timeRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        styleBookingInputs(body);

        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
        btnBar.setBackground(Color.WHITE);
        btnBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtil.BORDER));
        JButton btnSave = UIUtil.solidButton("Save Changes", new Color(33, 150, 243));
        btnSave.setPreferredSize(new Dimension(170, 38));
        JButton btnCancel = neutralBtn("Cancel");
        btnBar.add(btnCancel);
        btnBar.add(btnSave);

        JScrollPane scroll = new JScrollPane(body,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        int maxH;
        try {
            maxH = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height - 120;
        } catch (Exception ex2) { maxH = 640; }
        scroll.setPreferredSize(new Dimension(600, Math.min(560, Math.max(440, maxH))));
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        dlg.getContentPane().setLayout(new BorderLayout());
        dlg.getContentPane().add(banner, BorderLayout.NORTH);
        dlg.getContentPane().add(scroll, BorderLayout.CENTER);
        dlg.getContentPane().add(btnBar, BorderLayout.SOUTH);

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSave.addActionListener(e -> {
            // Composed from dropdowns, so the format is always valid.
            String dateTime = String.format("%04d-%02d-%02d %s:%s",
                    (Integer) cbYear.getSelectedItem(),
                    cbMonth.getSelectedIndex() + 1,
                    (Integer) cbDay.getSelectedItem(),
                    cbHour.getSelectedItem(), cbMinute.getSelectedItem());
            int pid;
            try {
                pid = parseId((String) cbPatient.getSelectedItem());
            } catch (Exception ex2) {
                UIUtil.showError(dlg, "Invalid patient selection.");
                return;
            }

            try {
                boolean ok = ctrl.update(existing.getId(), pid, dateTime,
                        (String) fStatus.getSelectedItem(), "");
                if (ok) {
                    dlg.dispose();
                    UIUtil.showSuccess(AppointmentPanel.this, "Appointment saved.");
                    loadAll();
                } else UIUtil.showError(dlg, "Save failed.");
            } catch (Exception ex2) {
                UIUtil.showError(dlg, "Save failed: " + ex2.getMessage());
            }
        });

        dlg.pack();
        dlg.setLocationRelativeTo(null);
        dlg.setVisible(true);
    }

    /** Full-width white wrapper (BorderLayout stretches the control edge to edge). */
    private JPanel fullWidthLike(JComponent c) {
        JPanel w = new JPanel(new BorderLayout(0, 0));
        w.setBackground(Color.WHITE);
        w.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        w.add(c, BorderLayout.CENTER);
        // Cap height so BoxLayout never stretches it (and its control) vertically.
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        return w;
    }

    /** Neutral secondary button (same style as the booking dialog Cancel). */
    private JButton neutralBtn(String text) {
        JButton b = new JButton(text);
        b.setBackground(Color.WHITE);
        b.setForeground(new Color(51, 65, 85));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
        b.setPreferredSize(new Dimension(140, 38));
        final Color base = Color.WHITE;
        final Color hover = new Color(241, 245, 249);
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(base); }
        });
        return b;
    }

    /** Defaults for a new booking: today at 10:00 (or opening hour). */
    private void setDateDefaults(JComboBox<Integer> cbYear, JComboBox<String> cbMonth,
                                 JComboBox<Integer> cbDay, JComboBox<String> cbHour,
                                 JComboBox<String> cbMinute, java.time.LocalDate today, int openH) {
        cbYear.setSelectedItem(today.getYear());
        cbMonth.setSelectedIndex(today.getMonthValue() - 1);
        // rebuild days for the chosen month, then pick today
        int max = java.time.YearMonth.of(today.getYear(), today.getMonthValue()).lengthOfMonth();
        cbDay.removeAllItems();
        for (int d = 1; d <= max; d++) cbDay.addItem(d);
        cbDay.setSelectedItem(Math.min(today.getDayOfMonth(), max));
        String ten = String.format("%02d", 10);
        boolean hasTen = false;
        for (int i = 0; i < cbHour.getItemCount(); i++) {
            if (cbHour.getItemAt(i).equals(ten)) { hasTen = true; break; }
        }
        cbHour.setSelectedItem(hasTen ? ten : String.format("%02d", openH));
        cbMinute.setSelectedItem("00");
    }

    /** Extracts the numeric ID from a "ID - name" combo item. */
    private int parseId(String item) {
        int dash = item.indexOf(" - ");
        String idPart = (dash < 0) ? item.trim() : item.substring(0, dash).trim();
        return Integer.parseInt(idPart);
    }

    /** Selects the combo entry whose ID prefix matches, or index 0 if not found. */
    private void selectById(JComboBox<String> cb, int id) {
        String prefix = id + " - ";
        for (int i = 0; i < cb.getItemCount(); i++) {
            String item = cb.getItemAt(i);
            if (item != null && item.startsWith(prefix)) {
                cb.setSelectedIndex(i);
                return;
            }
        }
        if (cb.getItemCount() > 0) cb.setSelectedIndex(0);
    }
}
