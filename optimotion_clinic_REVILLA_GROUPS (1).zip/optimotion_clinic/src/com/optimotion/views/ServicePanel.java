package com.optimotion.views;

import com.optimotion.controllers.ServiceController;
import com.optimotion.models.Service;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class ServicePanel extends JPanel {

    private static final Color ACCENT = new Color(63, 81, 181); // indigo

    private final ServiceController ctrl = new ServiceController();
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Service Name", "Price (\u20B1)", "Duration (min)", "Status", "Description"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JLabel lblCount = new JLabel();

    public ServicePanel(com.optimotion.models.User user) {
        boolean admin = user != null && user.isAdmin();
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("\u271A  Services & Pricing");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel(admin
                ? "Manage service catalogue, prices & durations"
                : "Service catalogue (read-only)");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(232, 234, 246));
        left.add(title); left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        txtSearch.setPreferredSize(new Dimension(200, 32));
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setToolTipText("Search service name or description...");
        JButton btnSearch = ghostBtn("\uD83D\uDD0D Search");
        JButton btnRefresh = null; // removed: global Dashboard refresh
        searchBox.add(txtSearch); searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

       
        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.getTableHeader().setBackground(ACCENT);
        stripeTable();
        fixColumnWidths();
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        if (admin) {
            JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            btns.setBackground(UIUtil.BG);
            JButton btnAdd = solidBtn("+ Add Service", new Color(76, 175, 80));
            JButton btnEdit = solidBtn("\u270E Edit", new Color(33, 150, 243));
            JButton btnDelete = solidBtn("\uD83D\uDDD1 Delete", new Color(211, 47, 47));
            btns.add(btnAdd); btns.add(btnEdit); btns.add(btnDelete);
            footer.add(btns, BorderLayout.WEST);
            btnAdd.addActionListener(e -> showForm(null));
            btnEdit.addActionListener(e -> editSelected());
            btnDelete.addActionListener(e -> deleteSelected());
        } else {
            JLabel ro = new JLabel("Read-only: contact an administrator to change services.");
            ro.setFont(new Font("Segoe UI", Font.ITALIC, 12));
            ro.setForeground(UIUtil.TEXT_MUTED);
            footer.add(ro, BorderLayout.WEST);
        }
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        txtSearch.addActionListener(e -> loadSearch());

        loadAll();
    }

    private JButton ghostBtn(String t) {
        return UIUtil.ghostButton(t, ACCENT.darker());
    }

    private JButton solidBtn(String t, Color bg) {
        return UIUtil.solidButton(t, bg);
    }

    private void stripeTable() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(javax.swing.SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                // Full text on hover - fixes cut-off Service Name / Description.
                if (comp instanceof JComponent) {
                    ((JComponent) comp).setToolTipText(v == null ? null : v.toString());
                }
                // Center to match centered headers (see UIUtil.styleTable).
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(232, 234, 246));
                    if (c == 2) {
                        comp.setFont(comp.getFont().deriveFont(Font.BOLD));
                        comp.setForeground(new Color(48, 63, 159));
                    } else if (c == 4 && v != null) {
                        if ("Active".equals(v.toString())) comp.setForeground(new Color(46, 125, 50));
                        else comp.setForeground(new Color(211, 47, 47));
                    } else comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    private void fixColumnWidths() {
        // ID, Service Name, Price, Duration, Status, Description
        // Description gets ~44% of the width so long texts are not cut off.
        int[] w = {50, 220, 90, 100, 80, 420};
        try {
            if (table.getColumnModel().getColumnCount() == w.length) {
                for (int i = 0; i < w.length; i++) {
                    table.getColumnModel().getColumn(i).setPreferredWidth(w[i]);
                }
            }
            table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        } catch (Exception ignored) {}
    }

    /** Reloads the list (called by the global Dashboard refresh). */
    public void refresh() {
        txtSearch.setText("");
        loadAll();
    }

    private void loadAll() {
        try { fillTable(ctrl.getAll()); }
        catch (Exception ex) { UIUtil.showError(this, "Failed to load services: " + ex.getMessage()); }
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try { fillTable(ctrl.search(k)); }
        catch (Exception ex) { UIUtil.showError(this, "Search failed: " + ex.getMessage()); }
    }

    private void fillTable(List<Service> list) {
        model.setRowCount(0);
        for (Service s : list) {
            model.addRow(new Object[]{s.getId(), s.getName(),
                    String.format("%.2f", s.getPrice()), s.getDurationMinutes(),
                    s.getStatus(), s.getDescription()});
        }
        lblCount.setText("Total records: " + list.size());
    }

    private void editSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select a service to edit."); return; }
        int id = (int) model.getValueAt(row, 0);
        try {
            for (Service s : ctrl.getAll()) {
                if (s.getId() == id) { showForm(s); return; }
            }
        } catch (Exception ex) { UIUtil.showError(this, ex.getMessage()); }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { UIUtil.showError(this, "Select a service to delete."); return; }
        int id = (int) model.getValueAt(row, 0);
        String name = String.valueOf(model.getValueAt(row, 1));
        if (!UIUtil.confirmDelete(this, "service '" + name + "'")) return;
        try {
            if (ctrl.delete(id)) { UIUtil.showSuccess(this, "Service deleted."); loadAll(); }
            else UIUtil.showError(this, "Delete failed.");
        } catch (Exception ex) { UIUtil.showError(this, "Delete failed: " + ex.getMessage()); }
    }

    private void showForm(Service existing) {
        JTextField fName = new JTextField(20);
        JTextArea fDesc = new JTextArea(3, 20);
        JTextField fPrice = new JTextField("500.00", 20);
        JTextField fDuration = new JTextField("60", 20);
        JComboBox<String> fStatus = new JComboBox<>(new String[]{"Active", "Inactive"});

        if (existing != null) {
            fName.setText(existing.getName());
            fDesc.setText(existing.getDescription());
            fPrice.setText(String.valueOf(existing.getPrice()));
            fDuration.setText(String.valueOf(existing.getDurationMinutes()));
            fStatus.setSelectedItem(existing.getStatus());
        }

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        form.add(new JLabel("Service Name*:")); form.add(fName);
        form.add(new JLabel("Description:")); form.add(new JScrollPane(fDesc));
        form.add(new JLabel("Price (\u20B1)*:")); form.add(fPrice);
        form.add(new JLabel("Duration (minutes)*:")); form.add(fDuration);
        form.add(new JLabel("Status:")); form.add(fStatus);

        int r = JOptionPane.showConfirmDialog(this, form,
                existing == null ? "Add Service" : "Edit Service",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;

        if (ValidationUtil.isEmpty(fName.getText())) {
            UIUtil.showError(this, "Service name is required."); return;
        }
        double price;
        int duration;
        try {
            price = Double.parseDouble(fPrice.getText().trim());
            duration = Integer.parseInt(fDuration.getText().trim());
            if (price < 0 || duration < 1) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            UIUtil.showError(this, "Price must be >= 0 and duration >= 1 minute."); return;
        }

        try {
            Service s = existing == null ? new Service() : existing;
            s.setName(fName.getText().trim());
            s.setDescription(fDesc.getText().trim());
            s.setPrice(price);
            s.setDurationMinutes(duration);
            s.setStatus((String) fStatus.getSelectedItem());
            boolean ok = (existing == null) ? ctrl.create(s) : ctrl.update(s);
            if (ok) { UIUtil.showSuccess(this, "Service saved."); loadAll(); }
            else UIUtil.showError(this, "Save failed (name may already exist).");
        } catch (Exception ex) {
            UIUtil.showError(this, "Save failed: " + ex.getMessage());
        }
    }
}
