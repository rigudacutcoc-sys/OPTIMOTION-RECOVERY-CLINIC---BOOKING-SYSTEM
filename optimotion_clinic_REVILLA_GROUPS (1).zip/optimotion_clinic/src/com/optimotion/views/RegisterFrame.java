package com.optimotion.views;

import com.optimotion.controllers.AuthController;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import javax.swing.*;

public class RegisterFrame extends JFrame {

    private final JTextField txtFullName = new JTextField(20);
    private final JTextField txtUser = new JTextField(20);
    private final JPasswordField txtPass = new JPasswordField(20);
    private final JPasswordField txtConfirm = new JPasswordField(20);
    private final AuthController auth = new AuthController();

    public RegisterFrame() {
        setTitle("Optimotion Recovery Clinic - Register");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(480, 630);
        setLocationRelativeTo(null);
        setResizable(false);
        UIUtil.setWindowIcon(this);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(UIUtil.BG);

        JPanel header = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UIUtil.PRIMARY,
                        getWidth(), 0, UIUtil.PRIMARY_DARK);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        header.setPreferredSize(new Dimension(480, 100));
        header.setBorder(BorderFactory.createEmptyBorder(18, 24, 18, 24));
        JLabel t = new JLabel("Create Account");
        t.setFont(new Font("Segoe UI", Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        JLabel s = new JLabel("Join the Optimotion clinic team");
        s.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        s.setForeground(new Color(224, 242, 241));
        JPanel txt = new JPanel(new GridLayout(2, 1));
        txt.setOpaque(false);
        txt.add(t); txt.add(s);
        header.add(txt, BorderLayout.WEST);
        // small logo on the right if available
        ImageIcon logo = UIUtil.loadLogo(90, 50);
        if (logo != null) {
            JLabel li = new JLabel(logo);
            header.add(li, BorderLayout.EAST);
        }
        root.add(header, BorderLayout.NORTH);

        JPanel outer = new JPanel(new GridBagLayout());
        outer.setBackground(UIUtil.BG);
        outer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 16),
                BorderFactory.createEmptyBorder(6, 2, 6, 2)));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(4, 12, 4, 12);
        g.gridx = 0; g.weightx = 1;
        int y = 0;
        for (javax.swing.JTextField f : new javax.swing.JTextField[]{txtFullName, txtUser}) {
            f.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            f.setPreferredSize(new Dimension(0, 36));
        }
        for (javax.swing.JPasswordField f : new javax.swing.JPasswordField[]{txtPass, txtConfirm}) {
            f.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                    BorderFactory.createEmptyBorder(4, 8, 4, 8)));
            f.setPreferredSize(new Dimension(0, 36));
        }

        form.add(label("Full Name"), gc(g, y++));
        form.add(txtFullName, gc(g, y++));
        form.add(label("Username (minimal 4 chars: letters, numbers, _ . -)"), gc(g, y++));
        form.add(txtUser, gc(g, y++));
        form.add(label("Password (minimal 6 chars)"), gc(g, y++));
        form.add(txtPass, gc(g, y++));
        form.add(label("Confirm Password"), gc(g, y++));
        form.add(txtConfirm, gc(g, y++));

        JButton btnReg = new JButton("Register");
        UIUtil.styleButton(btnReg);
        btnReg.setPreferredSize(new Dimension(0, 42));
        g.insets = new Insets(12, 12, 4, 12);
        g.gridy = y++; form.add(btnReg, g);

        JButton btnBack = new JButton("Back to Login");
        btnBack.setContentAreaFilled(false);
        btnBack.setForeground(UIUtil.PRIMARY_DARK);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnBack.setBorder(new UIUtil.RoundedBorder(UIUtil.PRIMARY, 10));
        btnBack.setPreferredSize(new Dimension(0, 38));
        g.insets = new Insets(2, 12, 6, 12);
        g.gridy = y++; form.add(btnBack, g);

        GridBagConstraints oc = new GridBagConstraints();
        oc.fill = GridBagConstraints.HORIZONTAL;
        oc.weightx = 1.0;
        oc.gridx = 0; oc.gridy = 0;
        outer.add(form, oc);
        root.add(outer, BorderLayout.CENTER);

        btnReg.addActionListener(e -> doRegister());
        btnBack.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
        setContentPane(root);
    }

    private GridBagConstraints gc(GridBagConstraints base, int y) {
        GridBagConstraints c = (GridBagConstraints) base.clone();
        c.gridy = y;
        return c;
    }

    private JLabel label(String s) {
        // HTML with fixed width so long hints wrap to 2 lines
        // instead of getting cut off with "..."
        JLabel l = new JLabel("<html><body style='width:320px'>" + s + "</body></html>");
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(UIUtil.TEXT_MAIN);
        return l;
    }

    private void doRegister() {
        String name = txtFullName.getText().trim();
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword());
        String conf = new String(txtConfirm.getPassword());

        if (ValidationUtil.isEmpty(name)) {
            UIUtil.showError(this, "Full name is required."); return;
        }
        if (!ValidationUtil.isValidUsername(user)) {
            UIUtil.showError(this, "Username must be at least 4 characters (letters, numbers, _ . -)."); return;
        }
        if (!ValidationUtil.isValidPassword(pass)) {
            UIUtil.showError(this, "Password must be at least 6 characters."); return;
        }
        if (!pass.equals(conf)) {
            UIUtil.showError(this, "Passwords do not match."); return;
        }
        try {
            boolean ok = auth.register(user, pass, name);
            if (ok) {
                UIUtil.showSuccess(this, "Account created! Please log in.");
                dispose();
                new LoginFrame().setVisible(true);
            } else {
                UIUtil.showError(this, "Username already exists. Choose another.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Registration failed: " + ex.getMessage());
        }
    }
}
