package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.PaymentController;
import com.optimotion.controllers.ServiceController;
import com.optimotion.controllers.TreatmentController;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import javax.swing.*;


public class DashboardPanel extends JPanel {

    private final JPanel statsRow = new JPanel(new GridLayout(2, 3, 12, 12));
    private final Runnable globalRefresh;

    private static final Color BLUE = new Color(33, 150, 243);
    private static final Color ORANGE = new Color(255, 152, 0);
    private static final Color TEAL = new Color(0, 150, 136);
    private static final Color GREEN = new Color(76, 175, 80);
    private static final Color DARK = new Color(38, 50, 56);
    private static final Color INDIGO = new Color(63, 81, 181);

    public DashboardPanel(User user) {
        this(user, null);
    }

    /**
     * @param globalRefresh run when the header Refresh is pressed; when null,
     *                      Refresh only reloads this dashboard. DashboardFrame passes
     *                      its global refresh so one click updates every page.
     */
    public DashboardPanel(User user, Runnable globalRefresh) {
        this.globalRefresh = globalRefresh;
        setLayout(new BorderLayout(12, 12));
        setBackground(UIUtil.BG);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel title = new JLabel("Dashboard");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Welcome, " + user.getFullName() + " (" + user.getRole() + ")  |  " + LocalDate.now());
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);

        JButton btnRefresh = UIUtil.ghostButton("Refresh", UIUtil.PRIMARY_DARK);
        btnRefresh.setPreferredSize(new Dimension(85, 30));
        btnRefresh.setToolTipText("Global refresh: reloads Dashboard, Staff Accounts, Services, Reports, Sales Report, Booking Reports and Archive");
        btnRefresh.addActionListener(e -> {
            if (globalRefresh != null) globalRefresh.run();
            else loadData();
        });
        JPanel eastWrap = new JPanel(new GridBagLayout());
        eastWrap.setOpaque(false);
        eastWrap.add(btnRefresh);
        header.add(eastWrap, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ---- Center ----
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(UIUtil.BG);

        statsRow.setBackground(UIUtil.BG);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 230));
        center.add(statsRow);
        center.add(Box.createVerticalStrut(12));

        // ---- Clinic banner (admin dashboard photo) ----
        // Save your picture as src/resources/dashboard_banner.png (or .jpg/.jpeg),
        // re-run run.bat, and it fills the card below. Hidden if missing.
        Image bannerImg = loadBannerImage();
        if (bannerImg != null) {
            JPanel bannerCard = new JPanel(new BorderLayout());
            bannerCard.setBackground(Color.WHITE);
            bannerCard.setBorder(BorderFactory.createCompoundBorder(
                    new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                    BorderFactory.createEmptyBorder(8, 8, 8, 8)));
            bannerCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 396));
            bannerCard.add(new BannerPanel(bannerImg), BorderLayout.CENTER);
            center.add(bannerCard);
        }

        JScrollPane scroll = new JScrollPane(center);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        loadData();
    }

    /** Reloads stats (called by the global refresh in DashboardFrame). */
    public void refresh() {
        loadData();
    }

    /** Reload all stats from DB. */
    private void loadData() {
        try {
            int patients = safe(() -> new PatientController().count());
            int appointments = safe(() -> new AppointmentController().count());
            int treatments = safe(() -> new TreatmentController().count());
            int payments = safe(() -> new PaymentController().count());
            int services = safe(() -> new ServiceController().count());
            double revenue = 0;
            try { revenue = new PaymentController().totalRevenue(); } catch (Exception ignored) {}

            statsRow.removeAll();
            statsRow.add(UIUtil.statCard("Patients", String.valueOf(patients), BLUE));
            statsRow.add(UIUtil.statCard("Appointments", String.valueOf(appointments), ORANGE));
            statsRow.add(UIUtil.statCard("Treatments", String.valueOf(treatments), TEAL));
            statsRow.add(UIUtil.statCard("Services", String.valueOf(services), INDIGO));
            statsRow.add(UIUtil.statCard("Payments", String.valueOf(payments), GREEN));
            statsRow.add(UIUtil.statCard("Revenue", String.format("\u20B1 %.0f", revenue), DARK));
            statsRow.revalidate();
            statsRow.repaint();
        } catch (Exception ex) {
            UIUtil.showError(this, "Dashboard load failed: " + ex.getMessage());
        }
    }

    private interface Counter { int get() throws Exception; }
    private int safe(Counter c) {
        try { return c.get(); } catch (Exception e) { return 0; }
    }

    /**
     * Loads src/resources/dashboard_banner.png (or .jpg/.jpeg).
     * Returns null when the file is not there yet, so the dashboard
     * simply shows the stat cards.
     */
    private Image loadBannerImage() {
        String[] names = {"dashboard_banner.png", "dashboard_banner.jpg", "dashboard_banner.jpeg"};
        for (String n : names) {
            try {
                java.net.URL url = DashboardPanel.class.getResource("/resources/" + n);
                if (url == null) url = DashboardPanel.class.getResource("/" + n);
                if (url != null) return new ImageIcon(url).getImage();
            } catch (Exception ignored) {}
        }
        String[] paths = {"src/resources/dashboard_banner.png",
                "src/resources/dashboard_banner.jpg",
                "src/resources/dashboard_banner.jpeg",
                "bin/resources/dashboard_banner.png",
                "bin/resources/dashboard_banner.jpg",
                "bin/resources/dashboard_banner.jpeg"};
        for (String p : paths) {
            try {
                java.io.File f = new java.io.File(p);
                if (f.exists()) return new ImageIcon(f.getAbsolutePath()).getImage();
            } catch (Exception ignored) {}
        }
        return null;
    }

    /** Paints the banner photo COVERING the full card width (center-cropped). */
    private static class BannerPanel extends JPanel {
        private final Image img;

        BannerPanel(Image img) {
            this.img = img;
            setBackground(Color.WHITE);
            setPreferredSize(new Dimension(0, 380));
        }

        @Override
        public Dimension getMaximumSize() {
            return new Dimension(Integer.MAX_VALUE, 380);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            int iw = img.getWidth(null);
            int ih = img.getHeight(null);
            int w = getWidth();
            int h = getHeight();
            if (iw <= 0 || ih <= 0 || w <= 0 || h <= 0) return;
            double scale = Math.max((double) w / iw, (double) h / ih);
            int dw = (int) (iw * scale);
            int dh = (int) (ih * scale);
            int x = (w - dw) / 2;
            int y = (h - dh) / 2;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                    RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(img, x, y, dw, dh, null);
            g2.dispose();
        }
    }
}
