package com.optimotion.views;

import com.optimotion.models.User;
import com.optimotion.utils.Session;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import javax.swing.*;

public class DashboardFrame extends JFrame {

    private final CardLayout cards = new CardLayout();
    private final JPanel main = new JPanel(cards);
    private final Map<String, JButton> navButtons = new HashMap<>();
    private String activeMenu = "Dashboard";

    // Staff pages (global refresh targets; stay null for admin logins).
    private StaffDashboardPanel staffDashboard;
    private AppointmentPanel bookingsPanel;
    private PatientPanel customersPanel;
    private TreatmentPanel treatmentsPanel;
    private PaymentPanel paymentsPanel;
    private SchedulePanel schedulePanel;
    private NotificationsPanel notificationsPanel;
    private SalesReportPanel staffSalesReportPanel;

    // Admin pages (global refresh targets; stay null for staff logins).
    private DashboardPanel dashboardPanel;
    private StaffAccountsPanel staffAccountsPanel;
    private ServicePanel servicesPanel;
    private ReportPanel reportsPanel;
    private SalesReportPanel salesReportPanel;
    private BookingReportPanel bookingReportPanel;
    private ArchivePanel archivePanel;

    /**
     * Global refresh: reloads every page of the current role. Wired to the
     * Refresh button in Appointments (staff side, the only Refresh button there)
     * and in Dashboard (admin side, the only Refresh button there).
     */
    public void refreshAll() {
        if (staffDashboard != null) staffDashboard.refresh();
        if (bookingsPanel != null) bookingsPanel.refresh();
        if (customersPanel != null) customersPanel.refresh();
        if (treatmentsPanel != null) treatmentsPanel.refresh();
        if (paymentsPanel != null) paymentsPanel.refresh();
        if (schedulePanel != null) schedulePanel.refresh();
        if (notificationsPanel != null) notificationsPanel.refresh();
        if (staffSalesReportPanel != null) staffSalesReportPanel.refresh();
        if (dashboardPanel != null) dashboardPanel.refresh();
        if (staffAccountsPanel != null) staffAccountsPanel.refresh();
        if (servicesPanel != null) servicesPanel.refresh();
        if (reportsPanel != null) reportsPanel.refresh();
        if (salesReportPanel != null) salesReportPanel.refresh();
        if (bookingReportPanel != null) bookingReportPanel.refresh();
        if (archivePanel != null) archivePanel.refresh();
    }

    public DashboardFrame(User user) {
        boolean admin = user != null && user.isAdmin();
        String roleName = admin ? "Administrator" : "Staff";
        setTitle("Optimotion Recovery Clinic - " + roleName + " (" + user.getUsername() + ")");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1140, 720);
        setMinimumSize(new Dimension(1000, 640));
        setLocationRelativeTo(null);
        UIUtil.setWindowIcon(this);

        // Sidebar
        JPanel side = new JPanel();
        side.setBackground(UIUtil.ACCENT);
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(218, 0));
        side.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(0, 0, 0, 40)));

        // Brand with logo
        ImageIcon logo = UIUtil.loadLogo(150, 44);
        if (logo != null) {
            JLabel logoLbl = new JLabel(logo);
            logoLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            logoLbl.setBorder(BorderFactory.createEmptyBorder(16, 0, 6, 0));
            side.add(logoLbl);
        }
        JLabel brand = new JLabel("OPTIMOTION");
        brand.setFont(new Font("Segoe UI", Font.BOLD, 18));
        brand.setForeground(Color.WHITE);
        brand.setAlignmentX(Component.CENTER_ALIGNMENT);
        brand.setBorder(BorderFactory.createEmptyBorder(logo == null ? 20 : 4, 0, 2, 0));

        JLabel roleLbl = new JLabel(roleName.toUpperCase() + " PANEL");
        roleLbl.setFont(new Font("Segoe UI", Font.BOLD, 11));
        roleLbl.setForeground(new Color(128, 203, 196));
        roleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        // User chip: avatar circle + name
        JPanel userChip = new JPanel();
        userChip.setOpaque(false);
        userChip.setLayout(new BoxLayout(userChip, BoxLayout.X_AXIS));
        userChip.setAlignmentX(Component.CENTER_ALIGNMENT);
        userChip.setBorder(BorderFactory.createEmptyBorder(12, 16, 14, 16));
        String initials = initialsOf(user.getFullName());
        JLabel avatar = new JLabel(initials, SwingConstants.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(UIUtil.PRIMARY);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        avatar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        avatar.setForeground(Color.WHITE);
        avatar.setPreferredSize(new Dimension(38, 38));
        avatar.setMinimumSize(new Dimension(38, 38));
        avatar.setMaximumSize(new Dimension(38, 38));
        avatar.setOpaque(false);
        JLabel who = new JLabel("<html><b>" + escape(user.getFullName()) + "</b><br/><font size=2 color='#B0BEC5'>"
                + escape(user.getUsername()) + "</font></html>");
        who.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        who.setForeground(new Color(207, 216, 220));
        who.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        userChip.add(avatar);
        userChip.add(who);
        userChip.add(Box.createHorizontalGlue());

        side.add(brand);
        side.add(roleLbl);
        side.add(userChip);

        JSeparator navSep = new JSeparator();
        navSep.setForeground(new Color(55, 71, 79));
        navSep.setBackground(new Color(55, 71, 79));
        navSep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        side.add(navSep);
        side.add(Box.createVerticalStrut(8));

        // ---- Role-based content ----
        String[] menu;
        if (admin) {
            // Admin is limited to: Dashboard, Staff Accounts, Services, Reports, Archive.
            // Archive is view-only (staff do the archiving); Dashboard's Refresh
            // is the global refresh for all admin pages.
            dashboardPanel = new DashboardPanel(user, this::refreshAll);
            main.add(dashboardPanel, "Dashboard");
            staffAccountsPanel = new StaffAccountsPanel(user);
            main.add(staffAccountsPanel, "Staff Accounts");
            servicesPanel = new ServicePanel(user);
            main.add(servicesPanel, "Services");
            reportsPanel = new ReportPanel(user);
            main.add(reportsPanel, "Reports");
            salesReportPanel = new SalesReportPanel(user);
            main.add(salesReportPanel, "Sales Report");
            bookingReportPanel = new BookingReportPanel(user);
            main.add(bookingReportPanel, "Booking Reports");
            archivePanel = new ArchivePanel(user);
            main.add(archivePanel, "Archive");
            menu = new String[]{"Dashboard", "Staff Accounts", "Services", "Reports", "Sales Report", "Booking Reports", "Archive"};
        } else {
            staffDashboard = new StaffDashboardPanel(user);
            main.add(staffDashboard, "Dashboard");
            // Appointments + Customers (+ existing Treatments/Payments for daily ops).
            // Appointments gets the global refresh: its header Refresh button
            // reloads every staff page (it is the only Refresh button left).
            bookingsPanel = new AppointmentPanel(this::refreshAll);
            main.add(bookingsPanel, "Appointments");
            customersPanel = new PatientPanel();
            main.add(customersPanel, "Customers");
            treatmentsPanel = new TreatmentPanel();
            main.add(treatmentsPanel, "Treatments");
            paymentsPanel = new PaymentPanel();
            main.add(paymentsPanel, "Payments");
            staffSalesReportPanel = new SalesReportPanel(user);
            main.add(staffSalesReportPanel, "Sales Report");
            schedulePanel = new SchedulePanel(user);
            main.add(schedulePanel, "Schedule");
            notificationsPanel = new NotificationsPanel();
            main.add(notificationsPanel, "Notifications");
            menu = new String[]{"Dashboard", "Appointments", "Customers", "Treatments",
                    "Payments", "Sales Report", "Schedule", "Notifications"};
        }

        for (String m : menu) {
            JButton b = navButton(m, m.equals(activeMenu));
            navButtons.put(m, b);
            b.addActionListener(e -> {
                setActive(m);
                cards.show(main, m);
            });
            // wrapper for left active indicator + padding
            JPanel wrap = new JPanel(new BorderLayout());
            wrap.setOpaque(false);
            wrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
            wrap.setBorder(BorderFactory.createEmptyBorder(2, 10, 2, 10));
            wrap.add(b, BorderLayout.CENTER);
            side.add(wrap);
        }

        side.add(Box.createVerticalGlue());
        JPanel logoutWrap = new JPanel(new BorderLayout());
        logoutWrap.setOpaque(false);
        logoutWrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 52));
        logoutWrap.setBorder(BorderFactory.createEmptyBorder(6, 12, 12, 12));
        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setBackground(new Color(211, 47, 47));
        btnLogout.setFocusPainted(false);
        btnLogout.setBorder(new UIUtil.RoundedBorder(new Color(183, 28, 28), 10));
        btnLogout.setOpaque(false);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setUI(new javax.swing.plaf.basic.BasicButtonUI() {
            @Override
            public void paint(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(c.getBackground());
                g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 20, 20);
                g2.dispose();
                super.paint(g, c);
            }
        });
        btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                btnLogout.setBackground(new Color(183, 28, 28));
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                btnLogout.setBackground(new Color(211, 47, 47));
            }
        });
        btnLogout.addActionListener(e -> {
            int r = JOptionPane.showConfirmDialog(this, "Log out?",
                    "Logout", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) {
                Session.logout(); // end session securely
                dispose();
                new LoginFrame().setVisible(true);
            }
        });
        logoutWrap.add(btnLogout, BorderLayout.CENTER);
        side.add(logoutWrap);

        main.setBackground(UIUtil.BG);
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(side, BorderLayout.WEST);
        getContentPane().add(main, BorderLayout.CENTER);
    }

    /** Lets panels jump to another page (used by Quick Actions). */
    public void showPage(String name) {
        if (navButtons.containsKey(name)) {
            setActive(name);
            cards.show(main, name);
        }
    }

    private JButton navButton(String menu, boolean active) {
        JButton b = new JButton(menu);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setFont(new Font("Segoe UI", active ? Font.BOLD : Font.PLAIN, 13));
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setOpaque(true);
        b.setPreferredSize(new Dimension(0, 40));
        applyNavStyle(b, active);
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) {
                if (!menu.equals(activeMenu)) {
                    b.setBackground(new Color(55, 71, 79));
                    b.setForeground(Color.WHITE);
                }
            }
            @Override public void mouseExited(java.awt.event.MouseEvent e) {
                if (!menu.equals(activeMenu)) {
                    applyNavStyle(b, false);
                }
            }
        });
        return b;
    }

    private void applyNavStyle(JButton b, boolean active) {
        if (active) {
            b.setBackground(new Color(0, 105, 92));
            b.setForeground(Color.WHITE);
        } else {
            b.setBackground(UIUtil.ACCENT);
            b.setForeground(new Color(176, 190, 197));
        }
    }

    private void setActive(String menu) {
        activeMenu = menu;
        for (Map.Entry<String, JButton> e : navButtons.entrySet()) {
            boolean on = e.getKey().equals(menu);
            applyNavStyle(e.getValue(), on);
            e.getValue().setFont(new Font("Segoe UI", on ? Font.BOLD : Font.PLAIN, 13));
        }
    }

    private String initialsOf(String name) {
        if (name == null || name.trim().isEmpty()) return "?";
        String[] parts = name.trim().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < Math.min(2, parts.length); i++) {
            if (!parts[i].isEmpty()) sb.append(Character.toUpperCase(parts[i].charAt(0)));
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
