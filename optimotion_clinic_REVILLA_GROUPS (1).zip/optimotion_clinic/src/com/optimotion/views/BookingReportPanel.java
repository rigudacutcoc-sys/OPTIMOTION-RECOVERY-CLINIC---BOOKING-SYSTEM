package com.optimotion.views;

import com.optimotion.controllers.BookingReportController;
import com.optimotion.controllers.SalesReportController;
import com.optimotion.models.BookingReportRow;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * BookingReportPanel - Administrator-only Booking Reports.
 *
 * <p>Summary cards, search + date/status/staff filters, booking table,
 * View Details / Reset / Refresh / Export CSV. Live MySQL data via
 * {@link BookingReportController} - no mock records.
 */
public class BookingReportPanel extends JPanel {

    private static final Color C_TOTAL = new Color(38, 50, 56);
    private static final Color C_PENDING = new Color(255, 152, 0);
    private static final Color C_CONFIRMED = new Color(33, 150, 243);
    private static final Color C_INPROGRESS = new Color(3, 169, 244);
    private static final Color C_COMPLETED = new Color(46, 125, 50);
    private static final Color C_CANCELLED = new Color(211, 47, 47);

    private final JPanel cardsRow = new JPanel(new GridLayout(1, 6, 12, 12));
    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"Booking ID", "Patient Name", "Treatment / Service",
                    "Appointment Date", "Appointment Time", "Assigned Staff",
                    "Booking Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
        @Override public Class<?> getColumnClass(int c) {
            return c == 0 ? Integer.class : String.class;
        }
    };
    private final JTable table = new JTable(model);
    private final JScrollPane tableScroll = new JScrollPane();
    private final JPanel emptyPanel = new JPanel(new GridBagLayout());

    private final JTextField txtSearch = new JTextField(20);
    private final JComboBox<String> cbPreset = new JComboBox<>(
            new String[]{"All dates", "Today", "Last 7 days", "This month", "Custom range"});
    private final JTextField txtFrom = new JTextField(10);
    private final JTextField txtTo = new JTextField(10);
    private final JComboBox<String> cbStatus = new JComboBox<>(
            new String[]{"All statuses", "Pending", "Scheduled", "Confirmed", "In Progress", "Completed", "Cancelled"});
    private final JComboBox<String> cbStaff = new JComboBox<>();
    private final JLabel lblCount = new JLabel();

    /** Parallel to cbStaff items: null = All, else users.id. */
    private final List<Integer> staffIds = new ArrayList<>();
    private final List<BookingReportRow> cached = new ArrayList<>();
    private final BookingReportController ctrl = new BookingReportController();

    public BookingReportPanel(User user) {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        if (user == null || !user.isAdmin()) {
            JPanel denied = new JPanel(new GridBagLayout());
            denied.setBackground(UIUtil.BG);
            denied.add(new JLabel("<html><center><h2>Access denied</h2>"
                    + "Booking Reports are for administrators only.</center></html>"));
            add(denied, BorderLayout.CENTER);
            return;
        }

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("Booking Reports");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("View and monitor appointment bookings and staff assignments.");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);
        JButton btnRefresh = UIUtil.ghostButton("Refresh", UIUtil.PRIMARY_DARK);
        btnRefresh.setToolTipText("Reload report from database");
        btnRefresh.addActionListener(e -> refresh());
        JPanel east = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        east.setOpaque(false);
        east.add(btnRefresh);
        header.add(east, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ---- Center ----
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(UIUtil.BG);
        center.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));

        cardsRow.setBackground(UIUtil.BG);
        cardsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 105));
        center.add(cardsRow);
        center.add(Box.createVerticalStrut(12));

        center.add(filterCard());
        center.add(Box.createVerticalStrut(12));

        JPanel tableCard = new JPanel(new BorderLayout());
        tableCard.setBackground(Color.WHITE);
        tableCard.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.setAutoCreateRowSorter(true);
        styleStatusColumn();
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(160);
        table.getColumnModel().getColumn(2).setPreferredWidth(210);
        table.getColumnModel().getColumn(3).setPreferredWidth(120);
        table.getColumnModel().getColumn(4).setPreferredWidth(110);
        table.getColumnModel().getColumn(5).setPreferredWidth(140);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);
        emptyPanel.setBackground(Color.WHITE);
        JLabel lblEmpty = new JLabel(
                "<html><center><b>No bookings match the current filters.</b><br/>"
                + "Try Reset Filters or another search.</center></html>",
                SwingConstants.CENTER);
        lblEmpty.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEmpty.setForeground(UIUtil.TEXT_MUTED);
        emptyPanel.add(lblEmpty);
        tableScroll.setBorder(null);
        tableScroll.setViewportView(table);
        tableCard.add(tableScroll, BorderLayout.CENTER);
        center.add(tableCard);

        JScrollPane outer = new JScrollPane(center);
        outer.setBorder(null);
        outer.getVerticalScrollBar().setUnitIncrement(16);
        add(outer, BorderLayout.CENTER);

        // ---- Footer: actions + count ----
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btns.setBackground(UIUtil.BG);
        JButton btnDetails = UIUtil.solidButton("View Details", new Color(33, 150, 243));
        JButton btnReset = UIUtil.solidButton("Reset Filters", new Color(96, 125, 139));
        JButton btnExport = UIUtil.solidButton("Export CSV", new Color(0, 150, 136));
        btns.add(btnDetails);
        btns.add(btnReset);
        btns.add(btnExport);
        footer.add(btns, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnDetails.addActionListener(e -> viewDetails());
        btnReset.addActionListener(e -> resetFilters());
        btnExport.addActionListener(e -> exportCsv());

        loadStaffOptions();
        reload();
    }

    private JPanel filterCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 12),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 108));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.fill = GridBagConstraints.HORIZONTAL;

        UIUtil.styleSearchField(txtSearch);
        txtSearch.setToolTipText("Search patient name or booking ID...");
        txtSearch.putClientProperty("JTextField.placeholderText", "Search patient or booking ID...");
        txtSearch.addActionListener(e -> applyFilters());

        txtFrom.setToolTipText("From yyyy-MM-dd (Custom range only)");
        txtTo.setToolTipText("To yyyy-MM-dd (Custom range only)");
        for (JTextField f : new JTextField[]{txtFrom, txtTo}) {
            f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            f.setBackground(Color.WHITE);
            f.setEnabled(false);
        }
        cbPreset.setFocusable(false);
        cbStatus.setFocusable(false);
        cbStaff.setFocusable(false);
        for (JComboBox<?> cb : new JComboBox<?>[]{cbPreset, cbStatus, cbStaff}) {
            cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            cb.setBackground(Color.WHITE);
        }

        g.gridx = 0; g.gridy = 0; g.weightx = 1.0;
        card.add(txtSearch, g);
        g.gridx = 0; g.gridy = 1; g.weightx = 0;
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        row.setBackground(Color.WHITE);
        row.add(new JLabel("Date:"));
        row.add(cbPreset);
        row.add(txtFrom);
        row.add(new JLabel("to"));
        row.add(txtTo);
        row.add(new JLabel("Status:"));
        row.add(cbStatus);
        row.add(new JLabel("Staff:"));
        row.add(cbStaff);
        card.add(row, g);

        cbPreset.addActionListener(e -> {
            boolean custom = cbPreset.getSelectedIndex() == 4;
            txtFrom.setEnabled(custom);
            txtTo.setEnabled(custom);
            if (!custom) {
                LocalDate today = LocalDate.now();
                switch (cbPreset.getSelectedIndex()) {
                    case 1 -> { txtFrom.setText(today.toString()); txtTo.setText(today.toString()); }
                    case 2 -> { txtFrom.setText(today.minusDays(6).toString()); txtTo.setText(today.toString()); }
                    case 3 -> { txtFrom.setText(today.withDayOfMonth(1).toString()); txtTo.setText(today.toString()); }
                    default -> { txtFrom.setText(""); txtTo.setText(""); }
                }
            }
            applyFilters();
        });
        cbStatus.addActionListener(e -> applyFilters());
        cbStaff.addActionListener(e -> applyFilters());
        txtFrom.addActionListener(e -> applyFilters());
        txtTo.addActionListener(e -> applyFilters());
        return card;
    }

    private void styleStatusColumn() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(SwingConstants.CENTER);
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                    if (c == 6 && v != null) {
                        switch (v.toString()) {
                            case "Completed", "Confirmed" ->
                                    comp.setForeground(new Color(46, 125, 50));
                            case "In Progress" ->
                                    comp.setForeground(new Color(3, 169, 244));
                            case "Pending", "Scheduled" ->
                                    comp.setForeground(new Color(230, 126, 0));
                            default -> comp.setForeground(new Color(211, 47, 47));
                        }
                    } else comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /** Called by DashboardFrame.refreshAll(). */
    public void refresh() {
        Object staffKeep = cbStaff.getSelectedItem();
        loadStaffOptions();
        if (staffKeep != null) cbStaff.setSelectedItem(staffKeep);
        reload();
    }

    private void loadStaffOptions() {
        staffIds.clear();
        cbStaff.removeAllItems();
        cbStaff.addItem("All Staff");
        staffIds.add(null);
        try {
            for (User u : new SalesReportController().getStaffList()) {
                cbStaff.addItem(u.getFullName());
                staffIds.add(u.getId());
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load staff list: " + ex.getMessage());
        }
        cbStaff.setSelectedIndex(0);
    }

    private void reload() {
        try {
            cached.clear();
            cached.addAll(ctrl.getRows());
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load booking report: " + ex.getMessage());
        }
        updateCards();
        applyFilters();
    }

    private void updateCards() {
        int total = cached.size(), pend = 0, conf = 0, inprog = 0, comp = 0, canc = 0;
        for (BookingReportRow r : cached) {
            switch (r.getStatus() == null ? "" : r.getStatus()) {
                case "Pending" -> pend++;
                case "Confirmed" -> conf++;
                case "In Progress" -> inprog++;
                case "Completed" -> comp++;
                case "Cancelled" -> canc++;
                default -> { }
            }
        }
        cardsRow.removeAll();
        cardsRow.add(UIUtil.statCard("Total Bookings", String.valueOf(total), C_TOTAL));
        cardsRow.add(UIUtil.statCard("Pending Bookings", String.valueOf(pend), C_PENDING));
        cardsRow.add(UIUtil.statCard("Confirmed Bookings", String.valueOf(conf), C_CONFIRMED));
        cardsRow.add(UIUtil.statCard("In Progress", String.valueOf(inprog), C_INPROGRESS));
        cardsRow.add(UIUtil.statCard("Completed Bookings", String.valueOf(comp), C_COMPLETED));
        cardsRow.add(UIUtil.statCard("Cancelled Bookings", String.valueOf(canc), C_CANCELLED));
        cardsRow.revalidate();
        cardsRow.repaint();
    }

    private void applyFilters() {
        String q = txtSearch.getText().trim().toLowerCase();
        String from = txtFrom.getText().trim();
        String to = txtTo.getText().trim();
        int statusIdx = cbStatus.getSelectedIndex();
        int staffIdx = cbStaff.getSelectedIndex();
        Integer staffId = (staffIdx >= 0 && staffIdx < staffIds.size()) ? staffIds.get(staffIdx) : null;

        model.setRowCount(0);
        for (BookingReportRow r : cached) {
            if (!q.isEmpty()) {
                boolean idHit = String.valueOf(r.getBookingId()).contains(q);
                boolean nameHit = r.getPatientName() != null
                        && r.getPatientName().toLowerCase().contains(q);
                if (!idHit && !nameHit) continue;
            }
            if (!from.isEmpty() && r.getDate() != null && r.getDate().compareTo(from) < 0) continue;
            if (!to.isEmpty() && r.getDate() != null && r.getDate().compareTo(to) > 0) continue;
            if (statusIdx > 0 && !((String) cbStatus.getSelectedItem()).equals(r.getStatus())) continue;
            if (staffId != null && !staffId.equals(r.getStaffUserId())) continue;
            model.addRow(new Object[]{r.getBookingId(), nz(r.getPatientName()), nz(r.getService()),
                    nz(r.getDate()), nz(r.getTime()), nz(r.getStaffName()), nz(r.getStatus())});
        }
        lblCount.setText("Records: " + model.getRowCount() + " of " + cached.size());
        tableScroll.setViewportView(model.getRowCount() == 0 ? emptyPanel : table);
    }

    private void resetFilters() {
        txtSearch.setText("");
        cbPreset.setSelectedIndex(0);
        txtFrom.setText("");
        txtTo.setText("");
        txtFrom.setEnabled(false);
        txtTo.setEnabled(false);
        cbStatus.setSelectedIndex(0);
        cbStaff.setSelectedIndex(0);
        applyFilters();
    }

    private void viewDetails() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            UIUtil.showError(this, "Select a booking first, then click View Details.");
            return;
        }
        int id = Integer.parseInt(String.valueOf(
                model.getValueAt(table.convertRowIndexToModel(viewRow), 0)));
        BookingReportRow hit = null;
        for (BookingReportRow r : cached) {
            if (r.getBookingId() == id) { hit = r; break; }
        }
        if (hit == null) {
            UIUtil.showError(this, "Booking no longer exists. Refreshing.");
            reload();
            return;
        }
        JPanel body = new JPanel(new GridLayout(0, 2, 10, 6));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        String[][] rows = {
                {"Booking ID:", "#" + hit.getBookingId()},
                {"Patient:", nz(hit.getPatientName())},
                {"Contact:", nz(hit.getPatientPhone())},
                {"Treatment / Service:", nz(hit.getService())},
                {"Date:", nz(hit.getDate())},
                {"Time:", nz(hit.getTime())},
                {"Assigned Staff:", nz(hit.getStaffName())},
                {"Status:", nz(hit.getStatus())},
        };
        for (String[] kv : rows) {
            JLabel k = new JLabel(kv[0]);
            k.setFont(new Font("Segoe UI", Font.BOLD, 12));
            k.setForeground(UIUtil.TEXT_MUTED);
            JLabel v = new JLabel(kv[1]);
            v.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            v.setForeground(UIUtil.TEXT_MAIN);
            body.add(k);
            body.add(v);
        }
        JOptionPane.showMessageDialog(this, body,
                "Booking #" + hit.getBookingId(), JOptionPane.INFORMATION_MESSAGE);
    }

    private void exportCsv() {
        if (model.getRowCount() == 0) {
            UIUtil.showError(this, "Nothing to export with the current filters.");
            return;
        }
        JFileChooser fc = new JFileChooser();
        fc.setSelectedFile(new java.io.File("booking_report.csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        java.io.File f = fc.getSelectedFile();
        try (java.io.PrintWriter pw = new java.io.PrintWriter(f, "UTF-8")) {
            pw.println("Booking ID,Patient Name,Treatment / Service,Appointment Date,"
                    + "Appointment Time,Assigned Staff,Booking Status");
            for (int r = 0; r < model.getRowCount(); r++) {
                String[] cells = new String[model.getColumnCount()];
                for (int c = 0; c < cells.length; c++) {
                    cells[c] = "\"" + String.valueOf(model.getValueAt(r, c)).replace("\"", "\"\"") + "\"";
                }
                pw.println(String.join(",", cells));
            }
            UIUtil.showSuccess(this, "Exported " + model.getRowCount()
                    + " row(s) to " + f.getAbsolutePath());
        } catch (Exception ex) {
            UIUtil.showError(this, "Export failed: " + ex.getMessage());
        }
    }

    private String nz(String s) { return (s == null || s.trim().isEmpty()) ? "-" : s; }
}
