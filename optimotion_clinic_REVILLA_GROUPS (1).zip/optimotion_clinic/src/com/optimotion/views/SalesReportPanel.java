package com.optimotion.views;

import com.optimotion.controllers.SalesReportController;
import com.optimotion.models.SalesRecord;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * SalesReportPanel - Sales Report for Administrator and Staff.
 *
 * <p>Table: ID | Service / Treatment | Patient | Assigned Staff | Total.
 * Admin filter: "Filter by Staff" dropdown (All Staff + each active staff).
 * Staff view: same table/card/footer design, but locked to the logged-in
 * staff's own Paid payments (no dropdown, cannot see other staff).
 * Footer: live "Total Sales" of the visible rows.
 * Source: Paid payments only (Pending/Partial/Cancelled excluded).
 */
public class SalesReportPanel extends JPanel {

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Service / Treatment", "Patient", "Assigned Staff", "Total"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
        @Override public Class<?> getColumnClass(int c) {
            return c == 0 ? Integer.class : String.class;
        }
    };
    private final JTable table = new JTable(model);
    private final JComboBox<String> cbStaff = new JComboBox<>();
    private final JLabel lblTotal = new JLabel("Total Sales: \u20B10.00");
    private final JLabel lblCount = new JLabel();
    /** Parallel to cbStaff items: null = All, -1 = Unassigned, else users.id. */
    private final List<Integer> staffIds = new ArrayList<>();
    private final SalesReportController ctrl = new SalesReportController();
    private final User currentUser;
    private final boolean isAdmin;

    public SalesReportPanel(User user) {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        boolean staff = user != null && "staff".equalsIgnoreCase(user.getRole());
        if (user == null || (!user.isAdmin() && !staff)) {
            JPanel denied = new JPanel(new GridBagLayout());
            denied.setBackground(UIUtil.BG);
            denied.add(new JLabel("<html><center><h2>Access denied</h2>"
                    + "Sales Report is for administrators only.</center></html>"));
            add(denied, BorderLayout.CENTER);
            this.currentUser = null;
            this.isAdmin = false;
            return;
        }
        this.currentUser = user;
        this.isAdmin = user.isAdmin();

        // ---- Header (matches admin Reports style) ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("Sales Report");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel(isAdmin
                ? "Paid sales by staff  |  " + LocalDate.now()
                : "My paid sales  |  " + LocalDate.now());
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel filterBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        filterBox.setOpaque(false);
        JButton btnRefresh = null;
        if (isAdmin) {
            JLabel lblFilter = new JLabel("Filter by Staff:");
            lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 12));
            lblFilter.setForeground(Color.WHITE);
            cbStaff.setPreferredSize(new Dimension(190, 32));
            cbStaff.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            cbStaff.setBackground(Color.WHITE);
            cbStaff.setFocusable(false);
            btnRefresh = UIUtil.ghostButton("Refresh", UIUtil.PRIMARY_DARK);
            filterBox.add(lblFilter);
            filterBox.add(cbStaff);
            filterBox.add(btnRefresh);
            header.add(filterBox, BorderLayout.EAST);
        }
        // Staff: no filter / refresh controls in header - table auto-loads own sales.
        add(header, BorderLayout.NORTH);

        // ---- Table card ----
        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        styleTotalColumn();
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        // ---- Footer: count (left) + total sales (right) ----
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.WEST);
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTotal.setForeground(new Color(22, 101, 52));
        footer.add(lblTotal, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        cbStaff.addActionListener(e -> loadSales());
        if (btnRefresh != null) {
            btnRefresh.addActionListener(e -> refresh());
        }

        if (isAdmin) {
            loadStaffOptions();
        }
        loadSales();
    }

    private void styleTotalColumn() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(SwingConstants.CENTER);
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                    if (c == 4) {
                        comp.setFont(comp.getFont().deriveFont(Font.BOLD));
                        comp.setForeground(new Color(22, 101, 52));
                    } else comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /** Called by DashboardFrame.refreshAll(). */
    public void refresh() {
        if (currentUser == null) return;
        if (isAdmin) {
            Object keep = cbStaff.getSelectedItem();
            loadStaffOptions();
            if (keep != null) cbStaff.setSelectedItem(keep);
        }
        loadSales();
    }

    /** Fills "Filter by Staff" from users where role='staff'. */
    private void loadStaffOptions() {
        staffIds.clear();
        cbStaff.removeAllItems();
        cbStaff.addItem("All Staff");
        staffIds.add(null);
        try {
            List<User> staff = ctrl.getStaffList();
            for (User u : staff) {
                cbStaff.addItem(u.getFullName());
                staffIds.add(u.getId());
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load staff list: " + ex.getMessage());
        }
        cbStaff.setSelectedIndex(0);
    }

    /** Reloads the table for the selected staff + recalculates the total. */
    private void loadSales() {
        try {
            Integer staffId;
            if (isAdmin) {
                int idx = cbStaff.getSelectedIndex();
                staffId = (idx >= 0 && idx < staffIds.size()) ? staffIds.get(idx) : null;
            } else {
                // Staff: locked to own sales - cannot view other staff.
                staffId = currentUser.getId();
            }
            List<SalesRecord> rows = ctrl.getSales(staffId);
            fillTable(rows);
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load sales: " + ex.getMessage());
        }
    }

    private void fillTable(List<SalesRecord> rows) {
        model.setRowCount(0);
        double sum = 0;
        for (SalesRecord r : rows) {
            model.addRow(new Object[]{r.getId(), nz(r.getService()), nz(r.getPatient()),
                    nz(r.getStaffName()), peso(r.getTotal())});
            sum += r.getTotal();
        }
        lblCount.setText("Records: " + rows.size());
        lblTotal.setText("Total Sales: " + peso(sum));
    }

    private String peso(double v) {
        return String.format("\u20B1%,.2f", v);
    }

    private String nz(String s) { return (s == null || s.trim().isEmpty()) ? "-" : s; }
}
