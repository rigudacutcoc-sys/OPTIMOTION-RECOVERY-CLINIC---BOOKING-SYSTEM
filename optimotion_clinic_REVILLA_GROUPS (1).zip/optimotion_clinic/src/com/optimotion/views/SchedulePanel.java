package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.SettingsController;
import com.optimotion.controllers.TreatmentController;
import com.optimotion.models.Appointment;
import com.optimotion.models.Treatment;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import javax.swing.*;

/**
 * SchedulePanel - CALENDAR-BASED clinic schedule.
 *
 * <p>Monthly calendar (Sun-Sat) backed by the live MySQL database:
 * appointments come from {@link AppointmentController#getAll()} and the
 * treatment name per booking comes from {@link TreatmentController#getAll()}
 * via {@code treatments.appointment_id}. No hardcoded data.
 *
 * <p>Only this file changed for the redesign. Database schema, booking
 * flow (AppointmentPanel), staff roles and DashboardFrame navigation are
 * untouched. {@link #refresh()} is called by DashboardFrame.refreshAll()
 * so the calendar updates after add / edit / delete in Bookings.
 */
public class SchedulePanel extends JPanel {

    private static final Color ACCENT = new Color(0, 121, 107); // deep teal
    private static final Color ACCENT_SOFT = new Color(224, 242, 241);
    private static final DateTimeFormatter MONTH_FMT = DateTimeFormatter.ofPattern("MMMM yyyy");
    private static final DateTimeFormatter DAY_FMT = DateTimeFormatter.ofPattern("MMMM d, yyyy");

    private YearMonth currentMonth = YearMonth.now();
    private LocalDate selectedDate = LocalDate.now();

    // yyyy-MM-dd -> appointments on that day (active bookings only)
    private final Map<String, List<Appointment>> byDate = new HashMap<>();
    // appointment_id -> treatment names (one booking may now have several services)
    private final Map<Integer, java.util.List<String>> treatmentByAppt = new HashMap<>();

    private final JLabel lblMonthYear = new JLabel("", SwingConstants.CENTER);
    private final JLabel lblHours = new JLabel();
    private final JLabel lblCount = new JLabel();
    private final JLabel lblSelectedDate = new JLabel();
    private final JPanel calendarGrid = new JPanel(new GridLayout(0, 7, 6, 6));
    private final JPanel detailList = new JPanel();
    private final JScrollPane detailScroll;

    public SchedulePanel(User user) {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        // ---- Header (same Optimotion style as before) ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("Schedule");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        lblHours.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblHours.setForeground(new Color(224, 242, 241));
        left.add(title);
        left.add(lblHours);
        header.add(left, BorderLayout.WEST);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setOpaque(false);
        JButton btnTodayH = UIUtil.ghostButton("Today", ACCENT.darker());
        JButton btnRefreshH = UIUtil.ghostButton("Refresh", ACCENT.darker());
        btnTodayH.addActionListener(e -> goToday());
        btnRefreshH.addActionListener(e -> refresh());
        right.add(btnTodayH);
        right.add(btnRefreshH);
        header.add(right, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ---- Content: calendar (left) + day details (right) ----
        JPanel content = new JPanel(new BorderLayout(12, 0));
        content.setBackground(UIUtil.BG);
        content.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));

        JPanel calCard = new JPanel(new BorderLayout(0, 8));
        calCard.setBackground(Color.WHITE);
        calCard.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));

        // Month navigation row: < Previous | October 2026 | Next >
        JPanel nav = new JPanel(new BorderLayout(8, 0));
        nav.setBackground(Color.WHITE);
        JButton btnPrev = navBtn("< Previous");
        JButton btnNext = navBtn("Next >");
        btnPrev.addActionListener(e -> {
            currentMonth = currentMonth.minusMonths(1);
            selectedDate = null; // clear detail until user picks a day
            reload();
        });
        btnNext.addActionListener(e -> {
            currentMonth = currentMonth.plusMonths(1);
            selectedDate = null;
            reload();
        });
        lblMonthYear.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblMonthYear.setForeground(UIUtil.TEXT_MAIN);
        nav.add(btnPrev, BorderLayout.WEST);
        nav.add(lblMonthYear, BorderLayout.CENTER);
        nav.add(btnNext, BorderLayout.EAST);
        calCard.add(nav, BorderLayout.NORTH);

        // Weekday header Sun..Sat
        JPanel weekHead = new JPanel(new GridLayout(1, 7, 6, 0));
        weekHead.setBackground(Color.WHITE);
        String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String d : days) {
            JLabel l = new JLabel(d, SwingConstants.CENTER);
            l.setFont(new Font("Segoe UI", Font.BOLD, 12));
            l.setForeground("Sun".equals(d) ? new Color(211, 47, 47) : UIUtil.TEXT_MUTED);
            weekHead.add(l);
        }

        calendarGrid.setBackground(Color.WHITE);

        JPanel calCenter = new JPanel(new BorderLayout(0, 6));
        calCenter.setBackground(Color.WHITE);
        calCenter.add(weekHead, BorderLayout.NORTH);
        calCenter.add(calendarGrid, BorderLayout.CENTER);
        calCard.add(calCenter, BorderLayout.CENTER);

        // ---- Right: selected-date details ----
        JPanel detailCard = new JPanel(new BorderLayout(0, 8));
        detailCard.setBackground(Color.WHITE);
        detailCard.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)));
        detailCard.setPreferredSize(new Dimension(340, 0));

        lblSelectedDate.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblSelectedDate.setForeground(UIUtil.TEXT_MAIN);
        detailCard.add(lblSelectedDate, BorderLayout.NORTH);

        detailList.setLayout(new BoxLayout(detailList, BoxLayout.Y_AXIS));
        detailList.setBackground(Color.WHITE);
        detailScroll = new JScrollPane(detailList);
        detailScroll.setBorder(null);
        detailScroll.getVerticalScrollBar().setUnitIncrement(16);
        detailCard.add(detailScroll, BorderLayout.CENTER);

        // Split: calendar gets remaining width, details fixed ~340px
        content.add(calCard, BorderLayout.CENTER);
        content.add(detailCard, BorderLayout.EAST);
        add(content, BorderLayout.CENTER);

        // ---- Footer ----
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JLabel hint = new JLabel("Click a date to view its appointments. Bookings are managed under Bookings.");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        hint.setForeground(UIUtil.TEXT_MUTED);
        footer.add(hint, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        loadHours();
        reload();
    }

    private JButton navBtn(String t) {
        JButton b = new JButton(t);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setForeground(ACCENT.darker());
        b.setBackground(Color.WHITE);
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
        b.setPreferredSize(new Dimension(110, 34));
        return b;
    }

    private void goToday() {
        currentMonth = YearMonth.now();
        selectedDate = LocalDate.now();
        reload();
    }

    /** Called by DashboardFrame.refreshAll() after Bookings add/edit/delete. */
    public void refresh() {
        loadHours();
        reload();
    }

    private void loadHours() {
        try {
            SettingsController sc = new SettingsController();
            lblHours.setText("Clinic schedule  |  Operating hours: "
                    + sc.openTime() + " - " + sc.closeTime());
        } catch (Exception e) {
            lblHours.setText("Clinic schedule");
        }
    }

    /** Re-reads MySQL and repaints calendar + detail. */
    private void reload() {
        loadFromDatabase();
        rebuildCalendar();
        showSelectedDay();
        updateCounts();
    }

    /**
     * Loads LIVE data (no hardcoding) for the SHARED clinic calendar:
     * all bookings via getAllShared() (every staff sees the same dates),
     * treatment names via getAllUnscoped(). Bookings/Treatments/Payments
     * lists stay staff-scoped - only Schedule is shared.
     */
    private void loadFromDatabase() {
        byDate.clear();
        treatmentByAppt.clear();
        List<Appointment> all;
        try {
            all = new AppointmentController().getAllShared();
        } catch (Exception e) {
            all = new ArrayList<>();
        }
        for (Appointment a : all) {
            String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
            if (dt.length() < 10) continue;
            String key = dt.substring(0, 10); // yyyy-MM-dd
            byDate.computeIfAbsent(key, k -> new ArrayList<>()).add(a);
        }
        // Sort each day by time (HH:mm at index 11..16) so earliest shows first.
        for (List<Appointment> day : byDate.values()) {
            day.sort(Comparator.comparing(a -> {
                String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
                return dt.length() >= 16 ? dt.substring(11, 16) : dt;
            }));
        }
        try {
            for (Treatment t : new TreatmentController().getAllUnscoped()) {
                if (t.getAppointmentId() != null && t.getTreatmentType() != null) {
                    // Multi-service bookings create several rows per appointment_id.
                    treatmentByAppt
                            .computeIfAbsent(t.getAppointmentId(), k -> new java.util.ArrayList<>())
                            .add(t.getTreatmentType());
                }
            }
        } catch (Exception ignored) {
            // Treatment names optional - detail shows "-" if unavailable.
        }
    }

    /** Builds the 7-column day grid for currentMonth with dots/counts. */
    private void rebuildCalendar() {
        calendarGrid.removeAll();
        lblMonthYear.setText(currentMonth.format(MONTH_FMT));

        // Offset: SUNDAY-first. getValue(): MON=1..SUN=7, so SUN % 7 = 0.
        int offset = currentMonth.atDay(1).getDayOfWeek().getValue() % 7;
        int daysInMonth = currentMonth.lengthOfMonth();
        LocalDate today = LocalDate.now();

        for (int cell = 0; cell < 42; cell++) {
            int dayNum = cell - offset + 1;
            if (dayNum < 1 || dayNum > daysInMonth) {
                JPanel blank = new JPanel();
                blank.setBackground(Color.WHITE);
                calendarGrid.add(blank);
                continue;
            }
            LocalDate date = currentMonth.atDay(dayNum);
            int count = byDate.getOrDefault(date.toString(), new ArrayList<>()).size();
            boolean isToday = date.equals(today);
            boolean isSel = date.equals(selectedDate);

            JButton b = new JButton();
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
            b.setOpaque(true);

            // Label: day number + dot/count line when booked.
            String dotLine = count > 0
                    ? "<br><span style='color:" + (isSel ? "#FFFFFF" : "#009688")
                      + ";font-size:10px'>\u25CF " + count + "</span>"
                    : "<br><span style='font-size:10px'>&nbsp;</span>";
            b.setText("<html><div style='text-align:center'><span style='font-size:13px'>"
                    + dayNum + "</span>" + dotLine + "</div></html>");
            b.setToolTipText(count == 0 ? date.format(DAY_FMT) + " - No appointments"
                    : date.format(DAY_FMT) + " - " + count + " appointment(s)");

            if (isSel) {
                b.setBackground(ACCENT);
                b.setForeground(Color.WHITE);
                b.setBorder(BorderFactory.createLineBorder(ACCENT.darker(), 2, true));
                b.setFont(new Font("Segoe UI", Font.BOLD, 13));
            } else {
                b.setBackground(count > 0 ? ACCENT_SOFT : Color.WHITE);
                b.setForeground(Color.BLACK);
                b.setFont(new Font("Segoe UI", count > 0 ? Font.BOLD : Font.PLAIN, 13));
                if (isToday) {
                    b.setBorder(BorderFactory.createLineBorder(ACCENT, 2, true));
                } else {
                    b.setBorder(BorderFactory.createLineBorder(UIUtil.BORDER, 1, true));
                }
            }
            b.addActionListener(e -> {
                selectedDate = date;
                rebuildCalendar(); // refresh highlight only (data already loaded)
                showSelectedDay();
                updateCounts();
            });
            calendarGrid.add(b);
        }
        calendarGrid.revalidate();
        calendarGrid.repaint();
    }

    /** Shows all bookings for selectedDate: ID, Time, Patient, Treatment, Status. */
    private void showSelectedDay() {
        detailList.removeAll();
        if (selectedDate == null) {
            lblSelectedDate.setText("Select a date");
            JLabel hint = centeredLabel("Click any date on the calendar"
                    + "<br>to view its appointments.", UIUtil.TEXT_MUTED);
            detailList.add(hint);
        } else {
            lblSelectedDate.setText("Selected Date: " + selectedDate.format(DAY_FMT));
            List<Appointment> day = byDate.getOrDefault(selectedDate.toString(), new ArrayList<>());
            if (day.isEmpty()) {
                detailList.add(Box.createVerticalStrut(30));
                detailList.add(centeredLabel("No appointments for this date.", UIUtil.TEXT_MUTED));
            } else {
                for (Appointment a : day) {
                    detailList.add(appointmentCard(a));
                    detailList.add(Box.createVerticalStrut(10));
                }
            }
        }
        detailList.revalidate();
        detailList.repaint();
        // Scroll back to top when switching days.
        SwingUtilities.invokeLater(() -> detailScroll.getVerticalScrollBar().setValue(0));
    }

    /** One white card per booking with all required fields. */
    private JPanel appointmentCard(Appointment a) {
        String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
        String time24 = dt.length() >= 16 ? dt.substring(11, 16) : "";
        String time12 = to12h(time24);
        java.util.List<String> tNames = treatmentByAppt.getOrDefault(a.getId(),
                new java.util.ArrayList<>());
        String treatment = tNames.isEmpty() ? "-" : String.join(", ", tNames);
        String status = a.getStatus() == null ? "" : a.getStatus();

        JPanel card = new JPanel(new BorderLayout(0, 0));
        card.setBackground(new Color(248, 250, 252));
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 10),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 170));

        // Top row: time (left) + status badge (right)
        JLabel lblTime = new JLabel(time12.isEmpty() ? "(no time)" : time12);
        lblTime.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblTime.setForeground(UIUtil.TEXT_MAIN);
        JLabel badge = new JLabel(status, SwingConstants.CENTER);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setOpaque(true);
        badge.setBackground(statusBg(status));
        badge.setForeground(statusFg(status));
        badge.setBorder(BorderFactory.createEmptyBorder(4, 10, 4, 10));
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(new Color(248, 250, 252));
        top.add(lblTime, BorderLayout.WEST);
        top.add(badge, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JPanel rows = new JPanel(new GridLayout(0, 1, 0, 2));
        rows.setBackground(new Color(248, 250, 252));
        rows.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        rows.add(infoLine("Patient:", nz(a.getPatientName())));
        rows.add(infoLine("Treatment:", nz(treatment)));
        // Separate same-day bookings stay separate cards; show assigned staff
        // so staff/admins can tell who owns each Booking ID.
        String staff = a.getStaffName();
        rows.add(infoLine("Staff:", nz(staff)));
        rows.add(infoLine("ID:", "#" + a.getId()));
        if (a.getNotes() != null && !a.getNotes().trim().isEmpty()) {
            JLabel n = new JLabel("<html><i>" + esc(a.getNotes().trim()) + "</i></html>");
            n.setFont(new Font("Segoe UI", Font.ITALIC, 11));
            n.setForeground(UIUtil.TEXT_MUTED);
            rows.add(n);
        }
        card.add(rows, BorderLayout.CENTER);
        return card;
    }

    private JLabel infoLine(String cap, String val) {
        JLabel l = new JLabel("<html><b>" + cap + "</b> " + esc(val) + "</html>");
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(UIUtil.TEXT_MAIN);
        return l;
    }

    private JLabel centeredLabel(String html, Color fg) {
        JLabel l = new JLabel("<html><div style='text-align:center'>" + html + "</div></html>",
                SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        l.setForeground(fg);
        l.setAlignmentX(Component.CENTER_ALIGNMENT);
        return l;
    }

    private void updateCounts() {
        // Month total: sum days starting with yyyy-MM (TreeMap keeps order, not required).
        String prefix = currentMonth.toString(); // yyyy-MM
        Map<String, List<Appointment>> sorted = new TreeMap<>(byDate);
        int monthTotal = 0;
        for (Map.Entry<String, List<Appointment>> e : sorted.entrySet()) {
            if (e.getKey().startsWith(prefix)) monthTotal += e.getValue().size();
        }
        int dayTotal = selectedDate == null ? 0
                : byDate.getOrDefault(selectedDate.toString(), new ArrayList<>()).size();
        lblCount.setText(currentMonth.format(MONTH_FMT) + ": " + monthTotal
                + " appointment(s)"
                + (selectedDate != null ? "  |  Selected: " + dayTotal : ""));
    }

    // ---- Helpers ----

    /** "14:30" -> "2:30 PM", "10:00" -> "10:00 AM". */
    private static String to12h(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            String ap = h >= 12 ? "PM" : "AM";
            int h12 = h % 12;
            if (h12 == 0) h12 = 12;
            return h12 + ":" + String.format("%02d", m) + " " + ap;
        } catch (Exception e) {
            return hhmm;
        }
    }

    private static Color statusBg(String s) {
        if ("Confirmed".equals(s) || "Completed".equals(s)) return new Color(220, 252, 231);
        if ("In Progress".equals(s)) return new Color(225, 245, 254);
        if ("Cancelled".equals(s)) return new Color(254, 226, 226);
        return new Color(255, 243, 224); // Pending / Scheduled
    }

    private static Color statusFg(String s) {
        if ("Confirmed".equals(s) || "Completed".equals(s)) return new Color(22, 101, 52);
        if ("In Progress".equals(s)) return new Color(2, 119, 189);
        if ("Cancelled".equals(s)) return new Color(153, 27, 27);
        return new Color(154, 52, 18);
    }

    private static String nz(String s) {
        return (s == null || s.trim().isEmpty()) ? "-" : s.trim();
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
