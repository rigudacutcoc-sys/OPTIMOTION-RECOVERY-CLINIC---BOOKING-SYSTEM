package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.TreatmentController;
import com.optimotion.models.Appointment;
import com.optimotion.models.Patient;
import com.optimotion.models.Treatment;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * TreatmentPanel - mockup-driven Treatment Management.
 *
 * <p>Existing behavior preserved (no new tables, no hardcoded data):
 * <ul>
 *   <li>Reads via {@link TreatmentController#getAll()} (staff-scoped) plus
 *       {@link AppointmentController#getAllIncludingArchived()} for the booking
 *       status/date; appointment lookup failures fall back to treatment data.</li>
 *   <li>Storage stays one row per service ({@code treatments.appointment_id});
 *       display groups them so one booking = one row, totals never duplicated.</li>
 *   <li>Progress stored per service row ({@code Ongoing} vs {@code Recovered});
 *       booking pill: Cancelled (appointment) &gt; Completed (all finished) &gt;
 *       Pending (appointment not started) &gt; Ongoing.</li>
 *   <li>Update Progress writes every service row of THIS booking only.</li>
 * </ul>
 */
public class TreatmentPanel extends JPanel {

    private static final Color ACCENT = new Color(0, 150, 136); // teal
    private static final Color ACCENT_DARK = new Color(0, 121, 107);
    private static final Color NAVY = new Color(55, 71, 79); // table header

    private final TreatmentController ctrl = new TreatmentController();
    private final PatientController patientCtrl = new PatientController();

    private static final String[] COLS = {"#", "Booking ID", "Patient Name",
            "Treatment / Service", "Sessions", "Appointment Date",
            "Progress", "Total Cost", "Action"};

    private final DefaultTableModel model = new DefaultTableModel(COLS, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JComboBox<String> cbHeaderStatus =
            new JComboBox<>(new String[]{"All Statuses", "Ongoing", "Pending", "Completed", "Cancelled"});

    // Summary cards: big = service rows, small = bookings (mockup style).
    private final JLabel lblTotalBig = new JLabel("0", SwingConstants.CENTER);
    private final JLabel lblTotalSub = new JLabel("", SwingConstants.CENTER);
    private final JLabel lblOngBig = new JLabel("0", SwingConstants.CENTER);
    private final JLabel lblOngSub = new JLabel("", SwingConstants.CENTER);
    private final JLabel lblCompBig = new JLabel("0", SwingConstants.CENTER);
    private final JLabel lblCompSub = new JLabel("", SwingConstants.CENTER);

    // Single-date filter as a calendar dropdown (no typing, format always valid).
    private java.time.LocalDate filterDate = null;
    private final JButton btnDate = new JButton();
    private final JComboBox<String> cbService = new JComboBox<>();
    private final JComboBox<String> cbProgStatus = new JComboBox<>(
            new String[]{"All Progress Statuses", "Ongoing", "Pending", "Completed", "Cancelled"});
    private final JLabel lblShowing = new JLabel();
    private final JButton btnPrev = new JButton("<");
    private final JButton btnNext = new JButton(">");
    private final JLabel lblPage = new JLabel("1", SwingConstants.CENTER);

    private static final int PAGE_SIZE = 8;
    private int page = 0;

    /** All grouped bookings from DB (unfiltered). */
    private final List<BookingGroup> cached = new ArrayList<>();
    /** Filtered groups. */
    private final List<BookingGroup> visible = new ArrayList<>();
    private boolean syncingStatus = false;

    // ---- Booking details side panel ----
    private final JPanel detailsPanel = new JPanel(new BorderLayout());
    private final JLabel dPatientName = new JLabel();
    private final JLabel dPatientMeta = new JLabel();
    private final JLabel dAvatar = new JLabel("", SwingConstants.CENTER);
    private final JLabel dBookingId = new JLabel("", SwingConstants.RIGHT);
    private final JLabel dStatusPill = new JLabel("", SwingConstants.CENTER);
    private final JLabel dApptDate = new JLabel("", SwingConstants.CENTER);
    private final JLabel dTotalCost = new JLabel("", SwingConstants.CENTER);
    private final JPanel dServices = new JPanel();
    private final JLabel dProgressLabel = new JLabel();
    private final JProgressBar dProgressBar = new JProgressBar(0, 100);
    private final JLabel dProgressPct = new JLabel();
    private JScrollPane dScroll;
    private BookingGroup detailsGroup = null;

    /** One display row = one booking (one or more treatment rows combined). */
    private static class BookingGroup {
        Integer bookingId; // null only for standalone rows without appointment
        int patientId;
        String patientName;
        String dateTime; // "yyyy-MM-dd HH:mm"
        String apptStatus; // appointment status (may be null)
        List<Treatment> items = new ArrayList<>();

        String serviceNames() {
            List<String> names = new ArrayList<>();
            for (Treatment t : items) {
                String n = t.getTreatmentType();
                if (n != null && !n.trim().isEmpty() && !names.contains(n.trim())) {
                    names.add(n.trim());
                }
            }
            return names.isEmpty() ? "-" : String.join(" + ", names);
        }

        /** One line per service so nothing is cut off (row height grows instead). */
        String serviceHtml() {
            List<String> names = new ArrayList<>();
            for (Treatment t : items) {
                String n = t.getTreatmentType();
                if (n != null && !n.trim().isEmpty() && !names.contains(n.trim())) {
                    names.add(n.trim());
                }
            }
            if (names.isEmpty()) return "-";
            StringBuilder sb = new StringBuilder("<html><div style='text-align:center'>");
            sb.append(esc(names.get(0)));
            for (int i = 1; i < names.size(); i++) {
                sb.append("<br><span style='color:#78909C'>+ ").append(esc(names.get(i))).append("</span>");
            }
            sb.append("</div></html>");
            return sb.toString();
        }

        int serviceLines() {
            int n = 0;
            for (Treatment t : items) {
                if (t.getTreatmentType() != null && !t.getTreatmentType().trim().isEmpty()) n++;
            }
            return Math.max(1, n);
        }

        int totalSessions() {
            int s = 0;
            for (Treatment t : items) s += t.getSessionCount();
            return s;
        }

        double totalCost() {
            double c = 0;
            for (Treatment t : items) c += t.getCost();
            return c;
        }

        int finishedCount() {
            int n = 0;
            for (Treatment t : items) {
                if (isFinished(t.getProgress())) n++;
            }
            return n;
        }

        /** Only a finished row counts (Pending/Ongoing are both unfinished). */
        static boolean isFinished(String progress) {
            if (progress == null) return false;
            String t = progress.trim();
            return "Recovered".equalsIgnoreCase(t)
                    || "Completed".equalsIgnoreCase(t)
                    || "Finished".equalsIgnoreCase(t);
        }

        static String displayState(String progress) {
            if (progress == null) return "Pending";
            String t = progress.trim();
            if ("Ongoing".equalsIgnoreCase(t)) return "Ongoing";
            if (isFinished(t)) return "Completed";
            if ("Pending".equalsIgnoreCase(t)) return "Pending";
            return "Ongoing";
        }

        int percentComplete() {
            if (items.isEmpty()) return 0;
            return (int) Math.round(100.0 * finishedCount() / items.size());
        }

        /**
         * Coupled to the booking workflow: Cancelled (booking) &gt; Completed
         * (all rows finished) &gt; Ongoing (session started) &gt; Pending
         * (scheduled, not started). New bookings create Pending treatments;
         * moving the booking to In Progress flips them to Ongoing.
         */
        String displayProgress() {
            if ("Cancelled".equals(apptStatus)) return "Cancelled";
            boolean anyOngoing = false;
            boolean anyPending = false;
            for (Treatment t : items) {
                String s = displayState(t.getProgress());
                if ("Ongoing".equals(s)) anyOngoing = true;
                else if ("Pending".equals(s)) anyPending = true;
            }
            if (anyOngoing) return "Ongoing";
            if (anyPending) return "Pending";
            return "Completed";
        }

        String day() {
            return (dateTime != null && dateTime.length() >= 10) ? dateTime.substring(0, 10) : "";
        }

        /** Plain database ID only (no BKG- prefix). */
        String formattedId() {
            if (bookingId == null) {
                int tid = items.isEmpty() ? 0 : items.get(0).getId();
                return String.valueOf(tid);
            }
            return String.valueOf(bookingId);
        }

        String dateLinesHtml() {
            if (dateTime == null || dateTime.length() < 10) return "-";
            String day = dateTime.substring(0, 10);
            String time24 = dateTime.length() >= 16 ? dateTime.substring(11, 16) : "";
            String time12 = to12h(time24);
            return "<html><div style='text-align:center'>" + esc(day)
                    + (time12.isEmpty() ? "" : "<br>" + esc(time12)) + "</div></html>";
        }

        private static String esc(String s) {
            if (s == null) return "";
            return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        }
    }

    public TreatmentPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        add(buildHeader(), BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout(0, 0));
        content.setBackground(UIUtil.BG);

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(UIUtil.BG);
        top.setBorder(BorderFactory.createEmptyBorder(14, 14, 0, 14));
        top.add(summaryRow());
        top.add(Box.createVerticalStrut(12));
        top.add(filterCard());
        top.add(Box.createVerticalStrut(12));
        content.add(top, BorderLayout.NORTH);

        JPanel split = new JPanel(new BorderLayout(12, 0));
        split.setBackground(UIUtil.BG);
        split.setBorder(BorderFactory.createEmptyBorder(0, 14, 10, 14));
        split.add(tableCard(), BorderLayout.CENTER);
        buildDetailsPanel();
        detailsPanel.setVisible(false);
        split.add(detailsPanel, BorderLayout.EAST);
        content.add(split, BorderLayout.CENTER);
        add(content, BorderLayout.CENTER);

        add(buildFooter(), BorderLayout.SOUTH);

        cbHeaderStatus.addActionListener(e -> {
            if (syncingStatus) return;
            syncingStatus = true;
            syncStatusCombo(cbHeaderStatus, cbProgStatus);
            syncingStatus = false;
            page = 0;
            applyFilters();
        });
        cbProgStatus.addActionListener(e -> {
            if (syncingStatus) return;
            syncingStatus = true;
            syncStatusCombo(cbProgStatus, cbHeaderStatus);
            syncingStatus = false;
            page = 0;
            applyFilters();
        });
        cbService.addActionListener(e -> { page = 0; applyFilters(); });
        txtSearch.addActionListener(e -> { page = 0; applyFilters(); });

        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) {
                int col = table.columnAtPoint(e.getPoint());
                int viewRow = table.rowAtPoint(e.getPoint());
                if (col == 8 && viewRow >= 0) {
                    int start = page * PAGE_SIZE;
                    int idx = start + table.convertRowIndexToModel(viewRow);
                    if (idx >= 0 && idx < visible.size()) showDetails(visible.get(idx));
                }
            }
        });
        btnPrev.addActionListener(e -> {
            if (page > 0) { page--; fillTable(); }
        });
        btnNext.addActionListener(e -> {
            if ((page + 1) * PAGE_SIZE < visible.size()) { page++; fillTable(); }
        });

        loadServiceOptionsPlaceholder();
        reload();
    }

    /** Called by DashboardFrame.refreshAll(). Keeps current filters. */
    public void refresh() {
        reload();
    }

    // ---------- Builders ----------

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));

        JPanel titleBox = new JPanel(new BorderLayout(10, 0));
        titleBox.setOpaque(false);
        JPanel texts = new JPanel(new GridLayout(2, 1));
        texts.setOpaque(false);
        JLabel title = new JLabel("Treatment Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Manage ongoing treatments and patient recovery progress");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(224, 242, 241));
        texts.add(title);
        texts.add(sub);
        titleBox.add(texts, BorderLayout.CENTER);
        header.add(titleBox, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setPreferredSize(new Dimension(300, 36));
        txtSearch.setToolTipText("Search by patient name, booking ID or treatment...");
        txtSearch.putClientProperty("JTextField.placeholderText",
                "Search by patient name, booking ID or treatment...");
        styleCombo(cbHeaderStatus);
        cbHeaderStatus.setPreferredSize(new Dimension(140, 36));
        JButton btnSearch = UIUtil.ghostButton("Search", ACCENT_DARK);
        btnSearch.setPreferredSize(new Dimension(92, 36));
        btnSearch.addActionListener(e -> { page = 0; applyFilters(); });
        searchBox.add(txtSearch);
        searchBox.add(cbHeaderStatus);
        searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        return header;
    }

    private JPanel summaryRow() {
        JPanel row = new JPanel(new GridLayout(1, 3, 12, 0));
        row.setBackground(UIUtil.BG);
        row.setAlignmentX(Component.LEFT_ALIGNMENT);
        row.add(summaryCard("Total Active Treatments", lblTotalBig, lblTotalSub,
                new Color(224, 242, 241)));
        row.add(summaryCard("Ongoing Treatments", lblOngBig, lblOngSub,
                new Color(255, 243, 224)));
        row.add(summaryCard("Completed Treatments", lblCompBig, lblCompSub,
                new Color(232, 245, 233)));
        return row;
    }

    private JPanel summaryCard(String title, JLabel big, JLabel sub, Color tint) {
        JPanel card = new JPanel(new BorderLayout(10, 0));
        card.setBackground(tint);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        JPanel texts = new JPanel(new GridLayout(3, 1, 0, 0));
        texts.setOpaque(false);
        texts.setBackground(tint);
        JLabel t = new JLabel(title);
        t.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        t.setForeground(UIUtil.TEXT_MAIN);
        big.setFont(new Font("Segoe UI", Font.BOLD, 24));
        big.setForeground(UIUtil.TEXT_MAIN);
        big.setHorizontalAlignment(SwingConstants.LEFT);
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        sub.setForeground(UIUtil.TEXT_MUTED);
        sub.setHorizontalAlignment(SwingConstants.LEFT);
        texts.add(t);
        texts.add(big);
        texts.add(sub);
        card.add(texts, BorderLayout.CENTER);
        // Opaque children keep the tint (GridLayout panel default is opaque).
        for (Component c : texts.getComponents()) c.setBackground(tint);
        return card;
    }

    private JPanel filterCard() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 12),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        row.setBackground(Color.WHITE);
        styleDateButton(btnDate, "Date");
        btnDate.addActionListener(e -> pickDate());
        refreshDateButtons();
        styleCombo(cbService);
        styleCombo(cbProgStatus);
        cbService.setPreferredSize(new Dimension(180, 32));
        cbService.setMinimumSize(new Dimension(140, 32));
        cbProgStatus.setPreferredSize(new Dimension(180, 32));
        cbProgStatus.setMinimumSize(new Dimension(140, 32));
        JButton btnReset = UIUtil.solidButton("Reset Filters", new Color(96, 125, 139));
        btnReset.setPreferredSize(new Dimension(130, 34));
        btnReset.addActionListener(e -> resetFilters());

        row.add(filterLabel("Date:"));
        row.add(btnDate);
        row.add(filterLabel("Treatment:"));
        row.add(cbService);
        row.add(cbProgStatus);
        row.add(btnReset);
        card.add(row, BorderLayout.CENTER);
        return card;
    }

    private static JLabel filterLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(UIUtil.TEXT_MAIN);
        return l;
    }

    private void styleDateButton(JButton b, String placeholder) {
        b.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        b.setBackground(Color.WHITE);
        b.setForeground(UIUtil.TEXT_MAIN);
        b.setFocusable(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
        b.setPreferredSize(new Dimension(125, 32));
        b.setMinimumSize(new Dimension(115, 32));
        b.putClientProperty("placeholder", placeholder);
    }

    private void refreshDateButtons() {
        btnDate.setText((filterDate == null ? "Select date" : filterDate.toString()) + " \u25BE");
        btnDate.setToolTipText(filterDate == null
                ? "Pick a date to show only that day's bookings (optional)" : "Showing " + filterDate);
    }

    /** Single calendar dropdown for the date filter (no typing needed). */
    private void pickDate() {
        java.time.LocalDate initial = filterDate;
        if (initial == null) initial = java.time.LocalDate.now();
        java.awt.Window owner = SwingUtilities.getWindowAncestor(this);
        final JDialog dlg = new JDialog(owner, "Select date",
                java.awt.Dialog.ModalityType.APPLICATION_MODAL);
        dlg.setResizable(false);

        final java.time.YearMonth[] viewing = new java.time.YearMonth[]{
                java.time.YearMonth.from(initial)};
        final java.time.LocalDate today = java.time.LocalDate.now();
        final JLabel lblMonth = new JLabel("", SwingConstants.CENTER);
        lblMonth.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblMonth.setForeground(UIUtil.TEXT_MAIN);
        final JPanel grid = new JPanel(new GridLayout(0, 7, 4, 4));
        grid.setBackground(Color.WHITE);

        Runnable rebuild = new Runnable() {
            @Override public void run() {
                grid.removeAll();
                java.time.YearMonth ym = viewing[0];
                lblMonth.setText(ym.format(
                        java.time.format.DateTimeFormatter.ofPattern("MMMM yyyy")));
                String[] days = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
                for (String d : days) {
                    JLabel l = new JLabel(d, SwingConstants.CENTER);
                    l.setFont(new Font("Segoe UI", Font.BOLD, 11));
                    l.setForeground("Sun".equals(d) ? new Color(211, 47, 47) : UIUtil.TEXT_MUTED);
                    grid.add(l);
                }
                int offset = ym.atDay(1).getDayOfWeek().getValue() % 7; // Sunday-first
                for (int i = 0; i < offset; i++) {
                    JPanel blank = new JPanel();
                    blank.setBackground(Color.WHITE);
                    grid.add(blank);
                }
                for (int d = 1; d <= ym.lengthOfMonth(); d++) {
                    final java.time.LocalDate date = ym.atDay(d);
                    JButton b = new JButton(String.valueOf(d));
                    b.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                    b.setFocusPainted(false);
                    b.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    b.setBackground(Color.WHITE);
                    b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER, 8));
                    if (date.equals(today)) {
                        b.setBorder(new UIUtil.RoundedBorder(ACCENT, 8));
                    }
                    if (filterDate != null && date.equals(filterDate)) {
                        b.setBackground(ACCENT);
                        b.setForeground(Color.WHITE);
                    } else {
                        b.setForeground(UIUtil.TEXT_MAIN);
                    }
                    b.addActionListener(e -> {
                        filterDate = date;
                        refreshDateButtons();
                        page = 0;
                        applyFilters();
                        dlg.dispose();
                    });
                    grid.add(b);
                }
                grid.revalidate();
                grid.repaint();
                dlg.pack();
            }
        };

        JButton btnPrevM = new JButton("<");
        JButton btnNextM = new JButton(">");
        for (JButton b : new JButton[]{btnPrevM, btnNextM}) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 12));
            b.setBackground(Color.WHITE);
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
            b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 8));
            b.setPreferredSize(new Dimension(40, 30));
        }
        btnPrevM.addActionListener(e -> {
            viewing[0] = viewing[0].minusMonths(1);
            rebuild.run();
        });
        btnNextM.addActionListener(e -> {
            viewing[0] = viewing[0].plusMonths(1);
            rebuild.run();
        });
        JPanel nav = new JPanel(new BorderLayout(8, 0));
        nav.setBackground(Color.WHITE);
        nav.add(btnPrevM, BorderLayout.WEST);
        nav.add(lblMonth, BorderLayout.CENTER);
        nav.add(btnNextM, BorderLayout.EAST);

        JPanel foot = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 0));
        foot.setBackground(Color.WHITE);
        JButton btnToday = new JButton("Today");
        JButton btnClear = new JButton("Clear");
        for (JButton b : new JButton[]{btnToday, btnClear}) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 11));
            b.setFocusPainted(false);
            b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        }
        btnToday.setBackground(ACCENT);
        btnToday.setForeground(Color.WHITE);
        btnToday.setBorder(new UIUtil.RoundedBorder(ACCENT_DARK, 8));
        btnClear.setBackground(Color.WHITE);
        btnClear.setForeground(UIUtil.TEXT_MAIN);
        btnClear.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 8));
        btnToday.addActionListener(e -> {
            filterDate = today;
            refreshDateButtons();
            page = 0;
            applyFilters();
            dlg.dispose();
        });
        btnClear.addActionListener(e -> {
            filterDate = null;
            refreshDateButtons();
            page = 0;
            applyFilters();
            dlg.dispose();
        });
        foot.add(btnToday);
        foot.add(btnClear);

        JPanel body = new JPanel(new BorderLayout(0, 8));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        body.add(nav, BorderLayout.NORTH);
        body.add(grid, BorderLayout.CENTER);
        body.add(foot, BorderLayout.SOUTH);
        dlg.getContentPane().add(body);
        rebuild.run();
        dlg.setLocationRelativeTo(btnDate);
        dlg.setVisible(true);
    }

    private JPanel tableCard() {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.getTableHeader().setBackground(NAVY);
        table.setRowHeight(52);
        // Columns always fill the viewport - nothing slides sideways.
        // Preferred widths act as relative weights.
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        table.getColumnModel().getColumn(0).setPreferredWidth(40);   // #
        table.getColumnModel().getColumn(1).setPreferredWidth(100);  // Booking ID
        table.getColumnModel().getColumn(2).setPreferredWidth(130);  // Patient
        table.getColumnModel().getColumn(3).setPreferredWidth(190);  // Service
        table.getColumnModel().getColumn(4).setPreferredWidth(60);   // Sessions
        table.getColumnModel().getColumn(5).setPreferredWidth(120);  // Date
        table.getColumnModel().getColumn(6).setPreferredWidth(100);  // Progress
        table.getColumnModel().getColumn(7).setPreferredWidth(90);   // Cost
        table.getColumnModel().getColumn(8).setPreferredWidth(130);  // Action
        table.getColumnModel().getColumn(6).setCellRenderer(new PillRenderer());
        table.getColumnModel().getColumn(8).setCellRenderer(new ActionRenderer());
        stripeTable();
        JScrollPane sp = new JScrollPane(table,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(null);
        sp.getViewport().setBackground(Color.WHITE);
        sp.getVerticalScrollBar().setUnitIncrement(16);
        sp.setPreferredSize(new Dimension(0, 300));
        card.add(sp, BorderLayout.CENTER);

        JPanel pager = new JPanel(new BorderLayout(8, 0));
        pager.setBackground(Color.WHITE);
        lblShowing.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblShowing.setForeground(UIUtil.TEXT_MUTED);
        pager.add(lblShowing, BorderLayout.WEST);
        JPanel pg = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        pg.setBackground(Color.WHITE);
        stylePagerBtn(btnPrev);
        stylePagerBtn(btnNext);
        lblPage.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPage.setForeground(Color.WHITE);
        lblPage.setBackground(ACCENT);
        lblPage.setOpaque(true);
        lblPage.setPreferredSize(new Dimension(28, 28));
        pg.add(btnPrev);
        pg.add(lblPage);
        pg.add(btnNext);
        pager.add(pg, BorderLayout.EAST);
        card.add(pager, BorderLayout.SOUTH);
        return card;
    }

    private static void stylePagerBtn(JButton b) {
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setBackground(Color.WHITE);
        b.setForeground(UIUtil.TEXT_MAIN);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(40, 28));
        b.setMinimumSize(new Dimension(40, 28));
        b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 8));
    }

    private JPanel buildFooter() {
        JPanel footer = new JPanel(new BorderLayout(12, 0));
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JButton btnProgress = UIUtil.solidButton("Update Progress", new Color(33, 150, 243));
        btnProgress.setPreferredSize(new Dimension(160, 36));
        btnProgress.setToolTipText("Update progress for the selected booking only");
        btnProgress.addActionListener(e -> updateProgressSelected());
        footer.add(btnProgress, BorderLayout.WEST);
        JLabel ro = new JLabel("One row per booking — multi-service bookings are combined, totals never duplicated.",
                SwingConstants.CENTER);
        ro.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        ro.setForeground(UIUtil.TEXT_MUTED);
        footer.add(ro, BorderLayout.CENTER);
        JLabel total = new JLabel();
        total.setFont(new Font("Segoe UI", Font.BOLD, 12));
        total.setForeground(UIUtil.TEXT_MUTED);
        total.setName("footerTotal");
        footer.add(total, BorderLayout.EAST);
        footer.putClientProperty("totalLabel", total);
        return footer;
    }

    private void styleCombo(JComboBox<?> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(Color.WHITE);
        cb.setFocusable(false);
    }

    private void stripeTable() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                if (c == 6 || c == 8) {
                    return super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                }
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(SwingConstants.CENTER);
                if (c == 3 && comp instanceof JComponent) {
                    Object raw = t.getModel().getValueAt(t.convertRowIndexToModel(r), 3);
                    String plain = raw == null ? "" : raw.toString()
                            .replaceAll("<[^>]*>", " ").replaceAll("\\s+", " ").trim();
                    ((JComponent) comp).setToolTipText(plain.isEmpty() ? null : plain);
                }
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248, 250, 252));
                    comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /** Status pill (Ongoing/Pending/Completed/Cancelled) for the Progress column. */
    private static class PillRenderer extends DefaultTableCellRenderer {
        PillRenderer() { setHorizontalAlignment(SwingConstants.CENTER); setOpaque(true); }
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                       boolean focus, int r, int c) {
            String s = v == null ? "" : v.toString();
            setText(s);
            setToolTipText(s.isEmpty() ? null : s);
            setFont(new Font("Segoe UI", Font.BOLD, 11));
            Color[] cols = pillColors(s);
            // Pill keeps its own colors even on selected rows so it stays readable.
            setForeground(cols[1]);
            int stripe = 0;
            try { stripe = t.convertRowIndexToModel(r) % 2; } catch (Exception ignored) {}
            setBackground(stripe == 0 ? cols[0] : blend(cols[0], new Color(248, 250, 252)));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(cols[1], 1, true),
                    BorderFactory.createEmptyBorder(4, 10, 4, 10)));
            return this;
        }
    }

    /**
     * Outline "View Details" pill for the Action column (JLabel-based so the
     * text always paints, unlike JButton renderers on some look-and-feels).
     */
    private static class ActionRenderer extends DefaultTableCellRenderer {
        ActionRenderer() { setHorizontalAlignment(SwingConstants.CENTER); setOpaque(true); }
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                       boolean focus, int r, int c) {
            setText("View Details");
            setToolTipText("View booking details");
            setFont(new Font("Segoe UI", Font.BOLD, 12));
            setForeground(sel ? Color.WHITE : ACCENT_DARK);
            setBackground(sel ? ACCENT_DARK : Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(ACCENT, 1, true),
                    BorderFactory.createEmptyBorder(5, 12, 5, 12)));
            return this;
        }
    }

    private static Color[] pillColors(String s) {
        if ("Ongoing".equals(s)) return new Color[]{new Color(255, 243, 224), new Color(230, 126, 0)};
        if ("Pending".equals(s)) return new Color[]{new Color(227, 242, 253), new Color(21, 101, 192)};
        if ("Completed".equals(s)) return new Color[]{new Color(232, 245, 233), new Color(46, 125, 50)};
        if ("Cancelled".equals(s)) return new Color[]{new Color(255, 235, 238), new Color(198, 40, 40)};
        return new Color[]{Color.WHITE, Color.GRAY};
    }

    private static Color blend(Color a, Color b) {
        return new Color((a.getRed() + b.getRed()) / 2,
                (a.getGreen() + b.getGreen()) / 2, (a.getBlue() + b.getBlue()) / 2);
    }

    // ---------- Details side panel ----------

    private void buildDetailsPanel() {
        detailsPanel.setBackground(Color.WHITE);
        detailsPanel.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(0, 0, 0, 0)));
        // 330px: two info boxes + service pills fit side-by-side with room to spare.
        detailsPanel.setPreferredSize(new Dimension(330, 0));
        detailsPanel.setMinimumSize(new Dimension(300, 0));

        JPanel head = new JPanel(new BorderLayout());
        head.setBackground(ACCENT);
        head.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JLabel t = new JLabel("Booking Details");
        t.setFont(new Font("Segoe UI", Font.BOLD, 15));
        t.setForeground(Color.WHITE);
        head.add(t, BorderLayout.WEST);
        JButton btnX = new JButton("X");
        btnX.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnX.setForeground(Color.WHITE);
        btnX.setBackground(ACCENT);
        btnX.setFocusPainted(false);
        btnX.setBorderPainted(false);
        btnX.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnX.addActionListener(e -> hideDetails());
        head.add(btnX, BorderLayout.EAST);
        detailsPanel.add(head, BorderLayout.NORTH);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));

        // Two stacked rows: avatar + name on top, booking ID + status below.
        // (A single 3-column row forced the body wider than the 300px panel,
        //  which created the sideways scrollbar and cut-off names.)
        JPanel patRow = new JPanel(new BorderLayout(10, 0));
        patRow.setBackground(Color.WHITE);
        patRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        patRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));
        dAvatar.setFont(new Font("Segoe UI", Font.BOLD, 18));
        dAvatar.setForeground(ACCENT_DARK);
        dAvatar.setBackground(new Color(224, 242, 241));
        dAvatar.setOpaque(true);
        dAvatar.setPreferredSize(new Dimension(48, 48));
        dAvatar.setBorder(BorderFactory.createLineBorder(new Color(224, 242, 241), 2, true));
        patRow.add(dAvatar, BorderLayout.WEST);
        JPanel patTexts = new JPanel(new GridLayout(2, 1, 0, 0));
        patTexts.setBackground(Color.WHITE);
        dPatientName.setFont(new Font("Segoe UI", Font.BOLD, 13));
        dPatientName.setForeground(UIUtil.TEXT_MAIN);
        dPatientMeta.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dPatientMeta.setForeground(UIUtil.TEXT_MUTED);
        patTexts.add(dPatientName);
        patTexts.add(dPatientMeta);
        patRow.add(patTexts, BorderLayout.CENTER);
        body.add(patRow);
        body.add(Box.createVerticalStrut(6));
        JPanel bidRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        bidRow.setBackground(Color.WHITE);
        bidRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        bidRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 30));
        dBookingId.setFont(new Font("Segoe UI", Font.BOLD, 12));
        dBookingId.setForeground(UIUtil.TEXT_MAIN);
        dStatusPill.setFont(new Font("Segoe UI", Font.BOLD, 11));
        dStatusPill.setOpaque(true);
        bidRow.add(dBookingId);
        bidRow.add(dStatusPill);
        body.add(bidRow);
        body.add(Box.createVerticalStrut(10));

        JPanel infoRow = new JPanel(new GridLayout(1, 2, 8, 0));
        infoRow.setBackground(Color.WHITE);
        infoRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        // Short caption: the full "Appointment Date & Time" text forced each box
        // wider than half the panel and created the sideways scrollbar.
        infoRow.add(infoBox("Appointment Date", dApptDate));
        infoRow.add(infoBox("Total Cost", dTotalCost));
        body.add(infoRow);
        body.add(Box.createVerticalStrut(10));

        JLabel svcTitle = new JLabel("Services Included");
        svcTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        svcTitle.setForeground(UIUtil.TEXT_MAIN);
        svcTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(svcTitle);
        body.add(Box.createVerticalStrut(4));
        dServices.setLayout(new BoxLayout(dServices, BoxLayout.Y_AXIS));
        dServices.setBackground(Color.WHITE);
        dServices.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(dServices);
        body.add(Box.createVerticalStrut(10));

        JLabel pTitle = new JLabel("Progress");
        pTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        pTitle.setForeground(UIUtil.TEXT_MAIN);
        pTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(pTitle);
        dProgressLabel.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        dProgressLabel.setForeground(UIUtil.TEXT_MUTED);
        dProgressLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        body.add(dProgressLabel);
        body.add(Box.createVerticalStrut(4));
        JPanel barRow = new JPanel(new BorderLayout(8, 0));
        barRow.setBackground(Color.WHITE);
        barRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        dProgressBar.setStringPainted(false);
        dProgressBar.setForeground(ACCENT);
        dProgressBar.setBackground(new Color(236, 239, 241));
        dProgressBar.setPreferredSize(new Dimension(0, 10));
        barRow.add(dProgressBar, BorderLayout.CENTER);
        dProgressPct.setFont(new Font("Segoe UI", Font.BOLD, 12));
        dProgressPct.setForeground(UIUtil.TEXT_MAIN);
        barRow.add(dProgressPct, BorderLayout.EAST);
        body.add(barRow);

        // Vertical scroll only - nothing in the 300px panel may slide sideways.
        dScroll = new JScrollPane(body,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        dScroll.setBorder(null);
        dScroll.getVerticalScrollBar().setUnitIncrement(16);
        detailsPanel.add(dScroll, BorderLayout.CENTER);

        JPanel btns = new JPanel(new GridLayout(1, 2, 8, 0));
        btns.setBackground(Color.WHITE);
        btns.setBorder(BorderFactory.createEmptyBorder(10, 14, 14, 14));
        JButton btnUpdate = UIUtil.solidButton("Update Progress", ACCENT_DARK);
        btnUpdate.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btnUpdate.setPreferredSize(new Dimension(0, 36));
        btnUpdate.addActionListener(e -> {
            if (detailsGroup != null) updateProgressForGroup(detailsGroup);
        });
        JButton btnClose = new JButton("Close");
        btnClose.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnClose.setBackground(Color.WHITE);
        btnClose.setForeground(UIUtil.TEXT_MAIN);
        btnClose.setFocusPainted(false);
        btnClose.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnClose.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
        btnClose.setPreferredSize(new Dimension(0, 36));
        btnClose.addActionListener(e -> hideDetails());
        btns.add(btnUpdate);
        btns.add(btnClose);
        detailsPanel.add(btns, BorderLayout.SOUTH);
    }

    private static JPanel infoBox(String caption, JLabel value) {
        JPanel box = new JPanel(new BorderLayout(0, 2));
        box.setBackground(new Color(248, 250, 252));
        box.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 10),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        JLabel c = new JLabel(caption);
        c.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        c.setForeground(UIUtil.TEXT_MUTED);
        value.setFont(new Font("Segoe UI", Font.BOLD, 12));
        value.setForeground(UIUtil.TEXT_MAIN);
        box.add(c, BorderLayout.NORTH);
        box.add(value, BorderLayout.CENTER);
        return box;
    }

    private void showDetails(BookingGroup b) {
        detailsGroup = b;
        Patient p = findPatient(b.patientId);
        String phone = (p != null && p.getPhone() != null && !p.getPhone().trim().isEmpty())
                ? p.getPhone().trim() : "-";
        String initials = "?";
        if (b.patientName != null && !b.patientName.trim().isEmpty()) {
            String[] parts = b.patientName.trim().split("\\s+");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, parts.length); i++) {
                if (!parts[i].isEmpty()) sb.append(Character.toUpperCase(parts[i].charAt(0)));
            }
            if (sb.length() > 0) initials = sb.toString();
        }
        dAvatar.setText(initials);
        dPatientName.setText(b.patientName == null ? "-" : b.patientName);
        dPatientMeta.setText("<html>Patient ID: P-" + String.format("%04d", b.patientId)
                + "<br>" + esc(phone) + "</html>");
        dBookingId.setText(b.formattedId());
        Color[] cols = pillColors(b.displayProgress());
        dStatusPill.setText(" " + b.displayProgress() + " ");
        dStatusPill.setForeground(cols[1]);
        dStatusPill.setBackground(cols[0]);
        dStatusPill.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(cols[1], 1, true),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)));
        dApptDate.setText(b.dateTime == null || b.dateTime.isEmpty() ? "-" : b.dateTime);
        dTotalCost.setText(money(b.totalCost()));

        dServices.removeAll();
        for (Treatment t : b.items) {
            dServices.add(serviceRow(t));
            dServices.add(Box.createVerticalStrut(6));
        }
        dServices.revalidate();
        dServices.repaint();

        int pct = b.percentComplete();
        dProgressLabel.setText("Current Progress");
        dProgressBar.setValue(pct);
        dProgressPct.setText(pct + "%");

        detailsPanel.setVisible(true);
        detailsPanel.revalidate();
        detailsPanel.repaint();
        // Always start at the patient header (scroll position persisted otherwise).
        SwingUtilities.invokeLater(() -> {
            try { dScroll.getVerticalScrollBar().setValue(0); } catch (Exception ignored) {}
        });
    }

    private JPanel serviceRow(Treatment t) {
        JPanel row = new JPanel(new BorderLayout(6, 0));
        row.setBackground(new Color(248, 250, 252));
        row.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 10),
                BorderFactory.createEmptyBorder(8, 10, 8, 10)));
        String raw = BookingGroup.displayState(t.getProgress());
        JPanel texts = new JPanel(new GridLayout(2, 1, 0, 0));
        texts.setBackground(new Color(248, 250, 252));
        JLabel n = new JLabel(t.getTreatmentType() == null ? "-" : t.getTreatmentType());
        n.setFont(new Font("Segoe UI", Font.BOLD, 12));
        n.setForeground(UIUtil.TEXT_MAIN);
        JLabel m = new JLabel(t.getSessionCount() + " session  \u00B7  " + money(t.getCost()));
        m.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        m.setForeground(UIUtil.TEXT_MUTED);
        texts.add(n);
        texts.add(m);
        row.add(texts, BorderLayout.CENTER);
        Color[] cols = pillColors(raw);
        JLabel pill = new JLabel(raw, SwingConstants.CENTER);
        pill.setFont(new Font("Segoe UI", Font.BOLD, 10));
        pill.setForeground(cols[1]);
        pill.setBackground(cols[0]);
        pill.setOpaque(true);
        pill.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(cols[1], 1, true),
                BorderFactory.createEmptyBorder(3, 6, 3, 6)));
        pill.setPreferredSize(new Dimension(78, 24));
        row.add(pill, BorderLayout.EAST);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 56));
        return row;
    }

    private void hideDetails() {
        detailsGroup = null;
        detailsPanel.setVisible(false);
        detailsPanel.revalidate();
        detailsPanel.repaint();
    }

    // ---------- Data ----------

    private void loadServiceOptionsPlaceholder() {
        cbService.removeAllItems();
        cbService.addItem("All Treatments");
    }

    private void reload() {
        Map<Integer, Appointment> appts = new LinkedHashMap<>();
        try {
            for (Appointment a : new AppointmentController().getAllIncludingArchived()) {
                appts.put(a.getId(), a);
            }
        } catch (Exception ignored) {}
        try {
            List<Treatment> rows = ctrl.getAll();
            cached.clear();
            cached.addAll(groupByBooking(rows, appts));
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load treatments: " + ex.getMessage());
            cached.clear();
        }
        patientCache = null;
        refreshServiceOptions();
        updateCards();
        applyFilters();
        if (detailsGroup != null && detailsGroup.bookingId != null) {
            BookingGroup still = null;
            for (BookingGroup b : cached) {
                if (detailsGroup.bookingId.equals(b.bookingId)) { still = b; break; }
            }
            if (still != null) showDetails(still);
            else hideDetails();
        }
    }

    private List<BookingGroup> groupByBooking(List<Treatment> rows, Map<Integer, Appointment> appts) {
        Map<String, List<Treatment>> map = new LinkedHashMap<>();
        for (Treatment t : rows) {
            String key = (t.getAppointmentId() != null)
                    ? "B:" + t.getAppointmentId() : "T:" + t.getId();
            map.computeIfAbsent(key, k -> new ArrayList<>()).add(t);
        }
        List<BookingGroup> out = new ArrayList<>();
        for (List<Treatment> g : map.values()) {
            Treatment f = g.get(0);
            BookingGroup b = new BookingGroup();
            b.bookingId = f.getAppointmentId();
            b.patientId = f.getPatientId();
            b.patientName = f.getPatientName();
            b.dateTime = f.getSessionDate() == null ? "" : f.getSessionDate();
            Appointment a = (b.bookingId == null) ? null : appts.get(b.bookingId);
            if (a != null) {
                b.apptStatus = a.getStatus();
                String ad = a.getAppointmentDate();
                if ((b.dateTime == null || b.dateTime.isEmpty()) && ad != null && !ad.isEmpty()) {
                    b.dateTime = ad;
                }
            }
            b.items.addAll(g);
            out.add(b);
        }
        return out;
    }

    private void refreshServiceOptions() {
        Object keep = cbService.getSelectedItem();
        TreeSet<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (BookingGroup b : cached) {
            for (Treatment t : b.items) {
                if (t.getTreatmentType() != null && !t.getTreatmentType().trim().isEmpty()) {
                    names.add(t.getTreatmentType().trim());
                }
            }
        }
        cbService.removeAllItems();
        cbService.addItem("All Treatments");
        for (String n : names) cbService.addItem(n);
        if (keep != null) cbService.setSelectedItem(keep);
        if (cbService.getSelectedIndex() < 0) cbService.setSelectedIndex(0);
    }

    /** Cards: big = service rows, small = bookings (mockup style). */
    private void updateCards() {
        int rows = 0, bookings = cached.size();
        int ongRows = 0, compRows = 0;
        java.util.Set<Integer> ongBookings = new java.util.HashSet<>();
        java.util.Set<Integer> compBookings = new java.util.HashSet<>();
        for (BookingGroup b : cached) {
            rows += b.items.size();
            for (Treatment t : b.items) {
                if ("Ongoing".equals(t.getProgress())) {
                    ongRows++;
                    if (b.bookingId != null) ongBookings.add(b.bookingId);
                } else if (BookingGroup.isFinished(t.getProgress())) {
                    compRows++;
                }
            }
            if ("Completed".equals(b.displayProgress()) && b.bookingId != null) {
                compBookings.add(b.bookingId);
            }
        }
        lblTotalBig.setText(String.valueOf(rows));
        lblTotalSub.setText("across " + bookings + " booking" + (bookings == 1 ? "" : "s"));
        lblOngBig.setText(String.valueOf(ongRows));
        lblOngSub.setText("across " + ongBookings.size() + " booking" + (ongBookings.size() == 1 ? "" : "s"));
        lblCompBig.setText(String.valueOf(compRows));
        lblCompSub.setText("across " + compBookings.size() + " booking" + (compBookings.size() == 1 ? "" : "s"));
    }

    private String selectedStatus() {
        String h = (String) cbHeaderStatus.getSelectedItem();
        if (h != null && !"All Statuses".equals(h)) return h;
        String p = (String) cbProgStatus.getSelectedItem();
        if (p != null && !"All Progress Statuses".equals(p)) return p;
        return "All";
    }

    private void syncStatusCombo(JComboBox<String> from, JComboBox<String> to) {
        String v = (String) from.getSelectedItem();
        if (v == null) return;
        if (from == cbHeaderStatus) {
            if ("All Statuses".equals(v)) to.setSelectedItem("All Progress Statuses");
            else to.setSelectedItem(v);
        } else {
            if ("All Progress Statuses".equals(v)) to.setSelectedItem("All Statuses");
            else to.setSelectedItem(v);
        }
    }

    private void applyFilters() {
        String q = txtSearch.getText().trim().toLowerCase();
        String svc = (String) cbService.getSelectedItem();
        String prog = selectedStatus();
        String day = filterDate == null ? "" : filterDate.toString();

        visible.clear();
        for (BookingGroup b : cached) {
            if (!"All".equals(prog) && !prog.equals(b.displayProgress())) continue;
            if (svc != null && !"All Treatments".equals(svc)) {
                boolean hit = false;
                for (Treatment t : b.items) {
                    if (svc.equalsIgnoreCase(t.getTreatmentType() == null ? ""
                            : t.getTreatmentType().trim())) { hit = true; break; }
                }
                if (!hit) continue;
            }
            if (!day.isEmpty() && !b.day().equals(day)) continue;
            if (!q.isEmpty()) {
                String noSpace = q.replace(" ", "");
                String digits = q.replaceAll("\\D", "");
                boolean nameHit = b.patientName != null
                        && b.patientName.toLowerCase().contains(q);
                boolean idHit = false;
                if (b.bookingId != null) {
                    if (!digits.isEmpty() && String.valueOf(b.bookingId).contains(digits)) idHit = true;
                    if (b.formattedId().toLowerCase().contains(noSpace)) idHit = true;
                }
                boolean svcHit = false;
                for (Treatment t : b.items) {
                    if (t.getTreatmentType() != null
                            && t.getTreatmentType().toLowerCase().contains(q)) { svcHit = true; break; }
                }
                if (!nameHit && !idHit && !svcHit) continue;
            }
            visible.add(b);
        }
        int maxPage = Math.max(0, (visible.size() - 1) / PAGE_SIZE);
        if (page > maxPage) page = maxPage;
        fillTable();
    }

    private void fillTable() {
        model.setRowCount(0);
        int start = page * PAGE_SIZE;
        int end = Math.min(start + PAGE_SIZE, visible.size());
        int n = start;
        for (int i = start; i < end; i++) {
            BookingGroup b = visible.get(i);
            n++;
            model.addRow(new Object[]{n, b.formattedId(),
                    b.patientName == null ? "-" : b.patientName,
                    b.serviceHtml(), b.totalSessions(),
                    b.dateLinesHtml(),
                    b.displayProgress(),
                    money(b.totalCost()),
                    "View Details"});
            // One line per service + two date lines: grow the row instead of
            // clipping text, so no tooltip or horizontal slide is needed.
            int lines = Math.max(2, b.serviceLines());
            table.setRowHeight(model.getRowCount() - 1, 30 + lines * 18);
        }
        int totalPages = Math.max(1, (visible.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        lblPage.setText(String.valueOf(page + 1));
        btnPrev.setEnabled(page > 0);
        btnNext.setEnabled(page + 1 < totalPages);
        lblShowing.setText("Showing " + visible.size() + " of " + cached.size() + " bookings");
        Component footer = getComponent(getComponentCount() - 1);
        if (footer instanceof JPanel) {
            Object total = ((JPanel) footer).getClientProperty("totalLabel");
            if (total instanceof JLabel) {
                int serviceRows = 0;
                for (BookingGroup b : visible) serviceRows += b.items.size();
                ((JLabel) total).setText("Total: " + visible.size() + " booking(s)");
            }
        }
    }

    private void resetFilters() {
        txtSearch.setText("");
        filterDate = null;
        refreshDateButtons();
        cbService.setSelectedIndex(0);
        syncingStatus = true;
        cbProgStatus.setSelectedIndex(0);
        cbHeaderStatus.setSelectedIndex(0);
        syncingStatus = false;
        page = 0;
        applyFilters();
    }

    // ---------- Details + progress ----------

    private Map<Integer, Patient> patientCache = null;

    private Patient findPatient(int patientId) {
        try {
            if (patientCache == null) {
                patientCache = new LinkedHashMap<>();
                for (Patient p : patientCtrl.getAllIncludingArchived()) {
                    patientCache.put(p.getId(), p);
                }
            }
            return patientCache.get(patientId);
        } catch (Exception ignored) {
            return null;
        }
    }

    /**
     * Reuses the existing per-row update: writes every service row of THIS
     * booking only, then reloads table + summary cards.
     */
    private void updateProgressForGroup(BookingGroup b) {
        final JComboBox<String> cb = new JComboBox<>(new String[]{"Ongoing", "Completed"});
        String cur = b.displayProgress();
        cb.setSelectedItem("Completed".equals(cur) ? "Completed" : "Ongoing");
        cb.setPreferredSize(new Dimension(220, 32));
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        JLabel info = new JLabel("<html><b>"
                + (b.bookingId == null ? "" : "Booking " + esc(b.formattedId()) + "  ")
                + esc(b.patientName) + "</b> - " + esc(b.serviceNames())
                + "<br><i>" + b.items.size() + " service row(s) update together.</i></html>");
        info.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        info.setForeground(UIUtil.TEXT_MAIN);
        JLabel cap = new JLabel("PROGRESS");
        cap.setFont(new Font("Segoe UI", Font.BOLD, 11));
        cap.setForeground(UIUtil.TEXT_MUTED);
        body.add(info);
        body.add(Box.createVerticalStrut(10));
        body.add(cap);
        body.add(Box.createVerticalStrut(2));
        body.add(cb);
        int r = JOptionPane.showConfirmDialog(this, body, "Update Progress",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        try {
            String picked = (String) cb.getSelectedItem();
            String store = "Completed".equals(picked) ? "Recovered" : "Ongoing";
            int ok = 0;
            for (Treatment t : b.items) {
                t.setProgress(store);
                if (ctrl.update(t)) ok++;
            }
            if (ok == b.items.size()) {
                UIUtil.showSuccess(this, "Booking "
                        + (b.bookingId == null ? "" : b.formattedId())
                        + " marked as " + picked + ".");
            } else if (ok > 0) {
                UIUtil.showSuccess(this, "Partially updated (" + ok + "/" + b.items.size() + ").");
            } else {
                UIUtil.showError(this, "Update failed.");
                return;
            }
            patientCache = null;
            reload();
        } catch (Exception ex) {
            UIUtil.showError(this, "Update failed: " + ex.getMessage());
        }
    }

    /** Footer button: progress change for the selected table row's booking only. */
    private void updateProgressSelected() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            UIUtil.showError(this, "Select a treatment first, then click Update Progress.");
            return;
        }
        int start = page * PAGE_SIZE;
        int idx = start + table.convertRowIndexToModel(viewRow);
        if (idx < 0 || idx >= visible.size()) {
            UIUtil.showError(this, "Select a treatment first, then click Update Progress.");
            return;
        }
        updateProgressForGroup(visible.get(idx));
    }

    private static String money(double v) {
        return String.format("\u20B1%,.2f", v);
    }

    /** "14:30" -> "2:30 PM". */
    private static String to12h(String hhmm) {
        try {
            String[] p = hhmm.split(":");
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            String ap = h >= 12 ? "PM" : "AM";
            int h12 = h % 12;
            if (h12 == 0) h12 = 12;
            return h12 + ":" + String.format("%02d", m) + " " + ap;
        } catch (Exception e) {
            return hhmm;
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
