package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.PaymentController;
import com.optimotion.controllers.TreatmentController;
import com.optimotion.models.Appointment;
import com.optimotion.models.Patient;
import com.optimotion.models.Payment;
import com.optimotion.models.Treatment;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class ReportPanel extends JPanel {

    private static final Color BLUE = new Color(33, 150, 243);
    private static final Color ORANGE = new Color(255, 152, 0);
    private static final Color TEAL = new Color(0, 150, 136);
    private static final Color GREEN = new Color(76, 175, 80);

    private final JPanel kpiRow = new JPanel(new GridLayout(1, 4, 12, 12));
    private final JLabel detailTitle = new JLabel("Patients");
    private final DefaultTableModel detailModel = new DefaultTableModel() {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable detailTable = new JTable(detailModel);

    private final Map<String, JPanel> kpiCards = new LinkedHashMap<>();
    private final Map<String, Color> kpiAccents = new LinkedHashMap<>();

    private List<Patient> cachedPatients = new ArrayList<>();
    private List<Appointment> cachedAppts = new ArrayList<>();
    private List<Treatment> cachedTreats = new ArrayList<>();
    private List<Payment> cachedPays = new ArrayList<>();
    private double cachedRevenue = 0;
    private String selectedKey = "Patients";

    public ReportPanel(com.optimotion.models.User user) {
        setLayout(new BorderLayout(12, 12));
        setBackground(UIUtil.BG);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

       
        if (user == null || !user.isAdmin()) {
            JPanel denied = new JPanel(new GridBagLayout());
            denied.setBackground(UIUtil.BG);
            denied.add(new JLabel("<html><center><h2>Access denied</h2>"
                    + "Reports are for administrators only.</center></html>"));
            add(denied, BorderLayout.CENTER);
            return;
        }

        
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel title = new JLabel("Clinic Reports");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Optimotion Recovery Clinic  |  " + LocalDate.now() + "  |  Click a card to view its table");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton btnRefresh = null; // removed: global Dashboard refresh
        // (actions panel kept empty: Reports reloads via the global Dashboard refresh)
        header.add(actions, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(UIUtil.BG);

        kpiRow.setBackground(UIUtil.BG);
        kpiRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 105));
        center.add(kpiRow);
        center.add(Box.createVerticalStrut(12));

        
        JPanel detailCard = UIUtil.card();
        detailCard.setLayout(new BorderLayout(0, 8));
        detailTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        detailTitle.setForeground(UIUtil.TEXT_MAIN);
        detailTitle.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));
        detailCard.add(detailTitle, BorderLayout.NORTH);

        UIUtil.styleTable(detailTable);
        detailTable.setAutoCreateRowSorter(true);
        JScrollPane tableScroll = new JScrollPane(detailTable);
        tableScroll.setBorder(null);
        tableScroll.setPreferredSize(new Dimension(0, 380));
        detailCard.add(tableScroll, BorderLayout.CENTER);
        center.add(detailCard);

        JScrollPane outer = new JScrollPane(center);
        outer.setBorder(null);
        outer.getVerticalScrollBar().setUnitIncrement(16);
        add(outer, BorderLayout.CENTER);

        generate();
    }

    /** Regenerates the report (called by the global Dashboard refresh). */
    public void refresh() {
        generate();
    }

    private void generate() {
        try {
            try { cachedPatients = new PatientController().getAll(); }
            catch (Exception e) { cachedPatients = new ArrayList<>(); }
            try { cachedAppts = new AppointmentController().getAll(); }
            catch (Exception e) { cachedAppts = new ArrayList<>(); }
            try { cachedTreats = new TreatmentController().getAll(); }
            catch (Exception e) { cachedTreats = new ArrayList<>(); }
            try { cachedPays = new PaymentController().getAll(); }
            catch (Exception e) { cachedPays = new ArrayList<>(); }
            try { cachedRevenue = new PaymentController().totalRevenue(); }
            catch (Exception ignored) { cachedRevenue = 0; }

            
            kpiRow.removeAll();
            kpiCards.clear();
            kpiAccents.clear();
            kpiRow.add(makeKpiCard("Patients", String.valueOf(cachedPatients.size()), BLUE, "Patients"));
            kpiRow.add(makeKpiCard("Appointments", String.valueOf(cachedAppts.size()), ORANGE, "Appointments"));
            kpiRow.add(makeKpiCard("Treatments", String.valueOf(cachedTreats.size()), TEAL, "Treatments"));
            kpiRow.add(makeKpiCard("Revenue", String.format("\u20B1 %.0f", cachedRevenue), GREEN, "Revenue"));
            updateSelectionHighlight();
            kpiRow.revalidate();
            kpiRow.repaint();

            showDetail(selectedKey);

        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to generate report: " + ex.getMessage());
        }
    }

    private JPanel makeKpiCard(String label, String value, Color accent, String key) {
        JPanel card = UIUtil.statCard(label, value, accent);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setToolTipText("Click to view " + label + " table");
        card.putClientProperty("reportKey", key);
        card.putClientProperty("reportAccent", accent);
        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                selectedKey = key;
                updateSelectionHighlight();
                showDetail(key);
            }
            @Override public void mouseEntered(MouseEvent e) {
                card.setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
        });
        kpiCards.put(key, card);
        kpiAccents.put(key, accent);
        return card;
    }

    private void updateSelectionHighlight() {
        for (Map.Entry<String, JPanel> e : kpiCards.entrySet()) {
            String key = e.getKey();
            JPanel card = e.getValue();
            Color accent = kpiAccents.getOrDefault(key, UIUtil.PRIMARY);
            if (key.equals(selectedKey)) {
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(accent, 2, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)));
            } else {
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UIUtil.BORDER, 1, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)));
            }
        }
        kpiRow.revalidate();
        kpiRow.repaint();
    }

    private void showDetail(String key) {
        if (key == null) key = "Patients";
        selectedKey = key;
        detailModel.setRowCount(0);
        switch (key) {
            case "Appointments" -> {
                detailModel.setColumnIdentifiers(new String[]{"ID", "Date", "Patient", "Status"});
                for (Appointment a : cachedAppts) {
                    detailModel.addRow(new Object[]{
                            a.getId(), nz(a.getAppointmentDate()), nz(a.getPatientName()),
                            nz(a.getStatus())});
                }
                detailTitle.setText("Appointments (" + cachedAppts.size() + " records)");
            }
            case "Treatments" -> {
                detailModel.setColumnIdentifiers(new String[]{"ID", "Session Date", "Patient", "Type", "Progress", "Cost"});
                for (Treatment t : cachedTreats) {
                    detailModel.addRow(new Object[]{
                            t.getId(), nz(t.getSessionDate()), nz(t.getPatientName()),
                            nz(t.getTreatmentType()), nz(t.getProgress()),
                            String.format("\u20B1 %.2f", t.getCost())});
                }
                detailTitle.setText("Treatments (" + cachedTreats.size() + " records)");
            }
            case "Revenue" -> {
                detailModel.setColumnIdentifiers(new String[]{"ID", "Payment Date", "Patient", "Amount", "Method", "Status"});
                for (Payment p : cachedPays) {
                    detailModel.addRow(new Object[]{
                            p.getId(), nz(p.getPaymentDate()), nz(p.getPatientName()),
                            String.format("\u20B1 %.2f", p.getAmount()),
                            nz(p.getMethod()), nz(p.getStatus())});
                }
                detailTitle.setText("Revenue â€” Payments (" + cachedPays.size() + " records"
                        + "  |  Total Paid: \u20B1 " + String.format("%.2f", cachedRevenue) + ")");
            }
            default -> { // Patients
                detailModel.setColumnIdentifiers(new String[]{"ID", "Full Name", "Gender", "DOB", "Phone", "Email"});
                for (Patient p : cachedPatients) {
                    detailModel.addRow(new Object[]{
                            p.getId(), nz(p.getFullName()), nz(p.getGender()),
                            nz(p.getDob()), nz(p.getPhone()), nz(p.getEmail())});
                }
                detailTitle.setText("Patients (" + cachedPatients.size() + " records)");
            }
        }
        detailTable.clearSelection();
    }

    private String nz(String s) { return s == null ? "" : s; }
}
