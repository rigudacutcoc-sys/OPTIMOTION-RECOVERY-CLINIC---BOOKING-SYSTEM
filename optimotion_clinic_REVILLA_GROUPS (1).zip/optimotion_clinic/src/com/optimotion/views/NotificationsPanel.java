package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.models.Appointment;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;

public class NotificationsPanel extends JPanel {

    private static final Color BG_LIGHT = new Color(245, 247, 250);
    private static final Color ACCENT_TEAL = new Color(0, 150, 136);
    private static final Color ACCENT_ORANGE = new Color(255, 152, 0);
    private static final Color ACCENT_BLUE = new Color(33, 150, 243);
    private static final Color ACCENT_RED = new Color(211, 47, 47);
    private static final Color TEXT_DARK = new Color(38, 50, 56);

    private final JComboBox<String> cbFilter = new JComboBox<>(
            new String[]{"All", "Today", "Pending", "Upcoming", "Cancelled"});
    private final JPanel statsPanel = new JPanel(new GridLayout(1, 4, 12, 12));
    private final javax.swing.JList<String> alertList;
    private final DefaultListModel<String> listModel;
    private final JScrollPane listScroll;

    public NotificationsPanel() {
        setLayout(new BorderLayout(12, 12));
        setBackground(UIUtil.BG);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ---- North wrapper: header + filter + stats stacked vertically ----
        // (Previously header, filterBar and statsPanel were each added to
        // BorderLayout.NORTH, so each replaced the last and only the stats
        // row was visible — header and filter appeared "broken"/missing.)
        JPanel northWrapper = new JPanel(new BorderLayout(0, 8));
        northWrapper.setBackground(UIUtil.BG);

        // ---- Header ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel title = new JLabel("Notifications");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Booking alerts  |  " + LocalDate.now());
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        JPanel titleBox = new JPanel(new GridLayout(2, 1));
        titleBox.setOpaque(false);
        titleBox.add(title);
        titleBox.add(sub);
        header.add(titleBox, BorderLayout.WEST);
        northWrapper.add(header, BorderLayout.NORTH);

        // ---- Filter bar ----
        JPanel filterBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 8));
        filterBar.setBackground(UIUtil.BG);
        filterBar.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        JLabel lblFilter = new JLabel("Filter:");
        lblFilter.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFilter.setForeground(UIUtil.TEXT_MAIN);
        cbFilter.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cbFilter.setBackground(Color.WHITE);
        cbFilter.setForeground(TEXT_DARK);
        cbFilter.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER, 10));
        filterBar.add(lblFilter);
        filterBar.add(cbFilter);
        // Changing the filter must refresh immediately (previously it did
        // nothing until "Refresh" was pressed, looking like a broken filter).
        cbFilter.addActionListener(e -> refresh());
        northWrapper.add(filterBar, BorderLayout.CENTER);

        // ---- Stats row ----
        statsPanel.setBackground(UIUtil.BG);
        statsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 95));
        statsPanel.setMinimumSize(new Dimension(0, 95));
        statsPanel.setPreferredSize(new Dimension(0, 95));
        northWrapper.add(statsPanel, BorderLayout.SOUTH);

        add(northWrapper, BorderLayout.NORTH);

        // ---- Alert list area ----
        listModel = new DefaultListModel<>();
        alertList = new javax.swing.JList<>(listModel);
        alertList.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        alertList.setBackground(BG_LIGHT);
        alertList.setSelectionBackground(ACCENT_BLUE);
        alertList.setSelectionForeground(Color.WHITE);
        alertList.setCellRenderer(new javax.swing.ListCellRenderer<String>() {
            @Override
            public java.awt.Component getListCellRendererComponent(
                    javax.swing.JList<? extends String> list, String value, int index,
                    boolean isSelected, boolean cellHasFocus) {
                JPanel panel = new JPanel(new BorderLayout());
                panel.setBackground(isSelected ? ACCENT_BLUE : BG_LIGHT);
                panel.setForeground(isSelected ? Color.WHITE : TEXT_DARK);
                panel.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 225, 230)),
                    BorderFactory.createEmptyBorder(10, 16, 10, 16)));
                
                if (value != null && !value.isEmpty()) {
                    JLabel lbl = new JLabel(value);
                    lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    lbl.setForeground(isSelected ? Color.WHITE : TEXT_DARK);
                    lbl.setOpaque(false);
                    panel.add(lbl, BorderLayout.CENTER);
                }
                return panel;
            }
        });
        listScroll = new JScrollPane(alertList);
        listScroll.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER, 14));
        listScroll.setBackground(BG_LIGHT);
        listScroll.getViewport().setBackground(BG_LIGHT);
        add(listScroll, BorderLayout.CENTER);

        refresh();
    }

    /** Reloads alerts (called by the global Bookings refresh). */
    public void refresh() {
        try {
            List<Appointment> all;
            try {
                all = new AppointmentController().getAll();
            } catch (Exception e) {
                all = new ArrayList<>();
            }
            String today = LocalDate.now().toString();

            List<Appointment> todays = new ArrayList<>();
            List<Appointment> pendings = new ArrayList<>();
            List<Appointment> upcoming = new ArrayList<>();
            List<Appointment> cancelled = new ArrayList<>();
            for (Appointment a : all) {
                String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
                String day = dt.length() >= 10 ? dt.substring(0, 10) : "";
                String st = a.getStatus() == null ? "" : a.getStatus();
                if (day.equals(today) && !"Cancelled".equals(st)) todays.add(a);
                if ("Pending".equals(st)) pendings.add(a);
                if (day.compareTo(today) > 0
                        && !"Cancelled".equals(st) && !"Completed".equals(st)) upcoming.add(a);
                if ("Cancelled".equals(st)) cancelled.add(a);
            }

            // Update stats cards
            statsPanel.removeAll();
            statsPanel.add(createStatCard("Today", todays.size(), ACCENT_TEAL, "TODAY"));
            statsPanel.add(createStatCard("Pending", pendings.size(), ACCENT_ORANGE, "ACTION"));
            statsPanel.add(createStatCard("Upcoming", upcoming.size(), ACCENT_BLUE, "UPCOMING"));
            statsPanel.add(createStatCard("Cancelled", cancelled.size(), ACCENT_RED, "CANCELLED"));
            statsPanel.revalidate();
            statsPanel.repaint();

            // Update alert list
            listModel.clear();
            String filter = (String) cbFilter.getSelectedItem();
            
            // Build combined visible list respecting filter
            java.util.List<Appointment> visible = new java.util.ArrayList<>();
            for (Appointment a : all) {
                String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
                String day = dt.length() >= 10 ? dt.substring(0, 10) : "";
                String st = a.getStatus() == null ? "" : a.getStatus();
                
                boolean show = false;
                if ("All".equals(filter)) show = true;
                else if ("Today".equals(filter) && day.equals(today) && !"Cancelled".equals(st)) show = true;
                else if ("Pending".equals(filter) && "Pending".equals(st)) show = true;
                else if ("Upcoming".equals(filter) && day.compareTo(today) > 0 
                        && !"Cancelled".equals(st) && !"Completed".equals(st)) show = true;
                else if ("Cancelled".equals(filter) && "Cancelled".equals(st)) show = true;
                
                if (show) visible.add(a);
            }

            // Sort: Today first, then Pending, then Upcoming, then Cancelled
            visible.sort((a, b) -> {
                String da = dayOf(a);
                String db = dayOf(b);
                boolean aToday = da.equals(today) && !"Cancelled".equals(a.getStatus());
                boolean bToday = db.equals(today) && !"Cancelled".equals(b.getStatus());
                if (aToday && !bToday) return -1;
                if (!aToday && bToday) return 1;
                return da.compareTo(db);
            });

            for (Appointment a : visible) {
                String dt = a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
                String patient = a.getPatientName() == null ? "Unknown" : a.getPatientName();
                String status = a.getStatus() == null ? "Unknown" : a.getStatus();
                String display = String.format("%s | %s | %s", dt, patient, status);
                listModel.addElement(display);
            }
            if (visible.isEmpty()) {
                listModel.addElement("No notifications for filter \"" + filter + "\".");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Failed to load notifications: " + ex.getMessage());
        }
    }

    /** Safe yyyy-MM-dd prefix; never throws on null/short dates. */
    private static String dayOf(Appointment a) {
        String dt = a == null || a.getAppointmentDate() == null ? "" : a.getAppointmentDate();
        return dt.length() >= 10 ? dt.substring(0, 10) : "";
    }

    private javax.swing.JPanel createStatCard(String label, int value, Color accent, String tag) {
        // Compact card: small tag on top, big count, muted label.
        // (UIUtil.statCard renders its 4th arg as a large 20pt icon, which
        // overflows for long words like "CANCELLED" - so we build the
        // small-tag layout directly here.)
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                new javax.swing.border.EmptyBorder(6, 8, 6, 8)));
        JPanel accentBar = new JPanel();
        accentBar.setBackground(accent);
        accentBar.setPreferredSize(new Dimension(0, 4));
        p.add(accentBar, BorderLayout.NORTH);
        JLabel t = new JLabel(tag, SwingConstants.CENTER);
        t.setFont(new Font("Segoe UI", Font.BOLD, 10));
        t.setForeground(accent);
        JLabel v = new JLabel(String.valueOf(value), SwingConstants.CENTER);
        v.setFont(new Font("Segoe UI", Font.BOLD, 20));
        v.setForeground(UIUtil.TEXT_MAIN);
        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(UIUtil.TEXT_MUTED);
        JPanel c = new JPanel(new GridLayout(3, 1, 0, 0));
        c.setBackground(Color.WHITE);
        c.add(t); c.add(v); c.add(l);
        p.add(c, BorderLayout.CENTER);
        return p;
    }
}