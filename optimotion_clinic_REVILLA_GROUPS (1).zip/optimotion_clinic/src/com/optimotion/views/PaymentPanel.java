package com.optimotion.views;

import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.PaymentController;
import com.optimotion.models.Patient;
import com.optimotion.models.Payment;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;


public class PaymentPanel extends JPanel {

    private static final Color ACCENT = new Color(76, 175, 80); // green

    private final PaymentController ctrl = new PaymentController();
    private final PatientController patientCtrl = new PatientController();

    private final DefaultTableModel model = new DefaultTableModel(
            new String[]{"ID", "Patient", "Treatment ID", "Amount", "Date", "Method", "Status"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable table = new JTable(model);
    private final JTextField txtSearch = new JTextField(18);
    private final JLabel lblCount = new JLabel();
    private final JLabel lblTotal = new JLabel();

    public PaymentPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("\u20B1  Payment Management");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        lblTotal.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblTotal.setForeground(new Color(232, 245, 233));
        lblTotal.setText("Track billing, methods & balances");
        left.add(title); left.add(lblTotal);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        txtSearch.setPreferredSize(new Dimension(200, 32));
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setToolTipText("Search patient, method, status...");
        JButton btnSearch = ghostBtn("\uD83D\uDD0D Search");
        searchBox.add(txtSearch); searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        JPanel centerWrap = new JPanel(new BorderLayout());
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        UIUtil.styleTable(table);
        UIUtil.enableToggleDeselect(table);
        table.getTableHeader().setBackground(ACCENT);
        stripeTable();
        card.add(new JScrollPane(table), BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JPanel btns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        btns.setBackground(UIUtil.BG);
        JButton btnAdd = solidBtn("+ Record", new Color(76, 175, 80));
        JButton btnEdit = solidBtn("\u270E Update", new Color(33, 150, 243));
        JButton btnDelete = solidBtn("\uD83D\uDDD1 Delete", new Color(211, 47, 47));
        btns.add(btnAdd); btns.add(btnEdit); btns.add(btnDelete);
        footer.add(btns, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        txtSearch.addActionListener(e -> loadSearch());
        btnAdd.addActionListener(e -> showForm(null));
        btnEdit.addActionListener(e -> editSelected());
        btnDelete.addActionListener(e -> deleteSelected());

        loadAll();
    }

    private JButton ghostBtn(String t) {
        return UIUtil.ghostButton(t, ACCENT.darker());
    }

    private JButton solidBtn(String t, Color bg) {
        return UIUtil.solidButton(t, bg);
    }

    private void stripeTable() {
        DefaultTableCellRenderer center = new DefaultTableCellRenderer() {
            { setHorizontalAlignment(javax.swing.SwingConstants.CENTER); }
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel,
                                                           boolean focus, int r, int c) {
                Component comp = super.getTableCellRendererComponent(t, v, sel, focus, r, c);
                ((DefaultTableCellRenderer) comp).setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                if (!sel) {
                    comp.setBackground(r % 2 == 0 ? Color.WHITE : new Color(248,250,252));
                    if (c == 6 && v != null) {
                        String s = v.toString();
                        if ("Paid".equals(s)) comp.setForeground(new Color(46, 125, 50));
                        else if ("Pending".equals(s)) comp.setForeground(new Color(230, 126, 0));
                        else comp.setForeground(new Color(33, 150, 243));
                    } else if (c == 3) {
                        comp.setFont(comp.getFont().deriveFont(Font.BOLD));
                        comp.setForeground(new Color(46, 125, 50));
                    } else comp.setForeground(Color.BLACK);
                }
                return comp;
            }
        };
        table.setDefaultRenderer(Object.class, center);
        table.setDefaultRenderer(Number.class, center);
    }

    /** Reloads the list (called by the global Bookings refresh). */
    public void refresh() {
        txtSearch.setText("");
        loadAll();
    }

    private void loadAll() {
        try {
            fillTable(ctrl.getAll());
            try {
                double rev = ctrl.totalRevenue();
                lblTotal.setText("Total paid revenue: \u20B1 " + String.format("%.2f", rev));
            } catch (Exception ignored) {}
        } catch (Exception ex) { UIUtil.showError(this, "Failed to load payments: " + ex.getMessage()); }
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try { fillTable(ctrl.search(k)); }
        catch (Exception ex) { UIUtil.showError(this, "Search failed: " + ex.getMessage()); }
    }

    private void fillTable(List<Payment> list) {
        model.setRowCount(0);
        for (Payment p : list) {
            model.addRow(new Object[]{p.getId(), p.getPatientName(),
                    p.getTreatmentId() == null ? "-" : p.getTreatmentId(),
                    String.format("%.2f", p.getAmount()), p.getPaymentDate(),
                    p.getMethod(), p.getStatus()});
        }
        lblCount.setText("Total records: " + list.size());
    }

    private void editSelected() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) { UIUtil.showError(this, "Select a payment to update."); return; }
        try {
            int modelRow = table.convertRowIndexToModel(viewRow);
            int id = toId(model.getValueAt(modelRow, 0));
            for (Payment p : ctrl.getAll()) {
                if (p.getId() == id) { showForm(p); return; }
            }
            UIUtil.showError(this, "Payment ID " + id + " no longer exists. Refreshing.");
            loadAll();
        } catch (Exception ex) { UIUtil.showError(this, "Cannot edit payment: " + ex.getMessage()); }
    }

    private void deleteSelected() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) { UIUtil.showError(this, "Select a payment to delete."); return; }
        try {
            int modelRow = table.convertRowIndexToModel(viewRow);
            int id = toId(model.getValueAt(modelRow, 0));
            if (!UIUtil.confirmDelete(this, "payment ID " + id)) return;
            if (ctrl.delete(id)) { UIUtil.showSuccess(this, "Payment deleted."); loadAll(); }
            else UIUtil.showError(this, "Delete failed: payment ID " + id + " not found. Refreshing.");
            loadAll();
        } catch (Exception ex) { UIUtil.showError(this, "Delete failed: " + ex.getMessage()); }
    }

    /** Robust ID extraction: handles Integer, Long, String (avoids ClassCastException). */
    private int toId(Object v) {
        if (v instanceof Number) return ((Number) v).intValue();
        return Integer.parseInt(String.valueOf(v).trim());
    }

    private void showForm(Payment existing) {
        final List<Patient> patients;
        try {
            patients = patientCtrl.getAll();
        } catch (Exception ex) {
            UIUtil.showError(this, "Save failed: " + ex.getMessage());
            return;
        }
        if (patients.isEmpty()) {
            UIUtil.showError(this, "Add at least one patient first.");
            return;
        }
        final JComboBox<String> cbPatient = new JComboBox<>();
        for (Patient p : patients) cbPatient.addItem(p.getId() + " - " + p.getFullName());

        // ---- Treatments of the selected patient (tick to include in total) ----
        // Amount auto-totals from ticked treatments: Total = sum(cost).
        // Booking already creates one treatment row per service, so picking
        // 2-3 treatments here totals them (e.g. 750 + 800 = 1550).
        final JPanel treatCheckPanel = new JPanel();
        treatCheckPanel.setLayout(new BoxLayout(treatCheckPanel, BoxLayout.Y_AXIS));
        treatCheckPanel.setBackground(Color.WHITE);
        final java.util.List<com.optimotion.models.Treatment> treatOptions = new java.util.ArrayList<>();
        final java.util.List<JCheckBox> treatChecks = new java.util.ArrayList<>();
        final JLabel lblTreatTotal = new JLabel("Total: \u20B10.00");
        lblTreatTotal.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTreatTotal.setForeground(new Color(22, 101, 52));
        final double[] totalHolder = new double[]{0};
        final java.util.List<Integer> totalTreatIds = new java.util.ArrayList<>();
        Runnable refreshTreatTotal = () -> {
            double sum = 0;
            int n = 0;
            totalTreatIds.clear();
            for (int i = 0; i < treatChecks.size(); i++) {
                if (treatChecks.get(i).isSelected() && i < treatOptions.size()) {
                    sum += treatOptions.get(i).getCost();
                    totalTreatIds.add(treatOptions.get(i).getId());
                    n++;
                }
            }
            totalHolder[0] = sum;
            if (n == 0) {
                lblTreatTotal.setText("Tick at least one treatment below.");
                lblTreatTotal.setForeground(new Color(211, 47, 47));
            } else {
                lblTreatTotal.setText("Total: \u20B1" + String.format("%,.2f", sum)
                        + "  (" + n + " treatment(s))");
                lblTreatTotal.setForeground(new Color(22, 101, 52));
            }
        };
        // Rebuilt every time the patient picker changes (see patient listener below).
        Runnable reloadTreatments = () -> {
            treatCheckPanel.removeAll();
            treatOptions.clear();
            treatChecks.clear();
            int pid = -1;
            try {
                String sel = (String) cbPatient.getSelectedItem();
                if (sel != null) pid = parseId(sel);
            } catch (Exception ignored) {}
            if (pid > 0) {
                try {
                    for (com.optimotion.models.Treatment t
                            : new com.optimotion.controllers.TreatmentController().getAll()) {
                        if (t.getPatientId() == pid) treatOptions.add(t);
                    }
                } catch (Exception ignored) {}
            }
            if (treatOptions.isEmpty()) {
                JLabel none = new JLabel("No treatments found for this patient yet - add a booking first.");
                none.setFont(new Font("Segoe UI", Font.ITALIC, 12));
                none.setForeground(UIUtil.TEXT_MUTED);
                treatCheckPanel.add(none);
            } else {
                for (com.optimotion.models.Treatment t : treatOptions) {
                    // Surface each session's status so staff can see at a glance
                    // which rows are payable (Completed) and which are blocked.
                    // Not started (Pending) and running (Ongoing) both block payment.
                    String state;
                    if ("Ongoing".equals(t.getProgress())) state = "Ongoing";
                    else if ("Pending".equals(t.getProgress())) state = "Pending";
                    else state = "Completed";
                    String lbl = "#" + t.getId() + "  " + t.getTreatmentType()
                            + "  (\u20B1" + String.format("%.2f", t.getCost()) + ")  - " + state;
                    JCheckBox cb = new JCheckBox(lbl);
                    cb.setBackground(Color.WHITE);
                    cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                    cb.setForeground(UIUtil.TEXT_MAIN);
                    cb.setFocusable(false);
                    cb.setSelected(true);
                    cb.addActionListener(e2 -> refreshTreatTotal.run());
                    treatCheckPanel.add(cb);
                    treatChecks.add(cb);
                }
            }
            refreshTreatTotal.run();
            treatCheckPanel.revalidate();
            treatCheckPanel.repaint();
        };
        cbPatient.addActionListener(e -> reloadTreatments.run());
        JScrollPane treatScroll = new JScrollPane(treatCheckPanel,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        treatScroll.setPreferredSize(new Dimension(0, 110));
        treatScroll.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                BorderFactory.createEmptyBorder(4, 4, 4, 4)));
        treatScroll.getVerticalScrollBar().setUnitIncrement(12);
        // ---- Payment date picker: no typing needed ----
        String[] monthNames = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        final JComboBox<String> cbMonth = new JComboBox<>(monthNames);
        final JComboBox<Integer> cbDay = new JComboBox<>();
        final JComboBox<Integer> cbYear = new JComboBox<>();
        int payYear = java.time.LocalDate.now().getYear();
        for (int y = payYear + 1; y >= 2000; y--) cbYear.addItem(y);
        Runnable refillDays = () -> {
            Object keep = cbDay.getSelectedItem();
            int max = java.time.YearMonth.of((Integer) cbYear.getSelectedItem(),
                    cbMonth.getSelectedIndex() + 1).lengthOfMonth();
            cbDay.removeAllItems();
            for (int d = 1; d <= max; d++) cbDay.addItem(d);
            if (keep instanceof Integer && (Integer) keep <= max) cbDay.setSelectedItem(keep);
        };
        cbMonth.addActionListener(e -> refillDays.run());
        cbYear.addActionListener(e -> refillDays.run());
        refillDays.run();
        java.time.LocalDate todayLd = java.time.LocalDate.now();
        cbYear.setSelectedItem(todayLd.getYear());
        cbMonth.setSelectedIndex(todayLd.getMonthValue() - 1);
        refillDays.run();
        cbDay.setSelectedItem(todayLd.getDayOfMonth());
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 2));
        datePanel.setBackground(Color.WHITE);
        datePanel.add(new JLabel("Month:"));
        datePanel.add(cbMonth);
        datePanel.add(new JLabel("Day:"));
        datePanel.add(cbDay);
        datePanel.add(new JLabel("Year:"));
        datePanel.add(cbYear);
        // Fixed widths so the year is never clipped.
        cbMonth.setPreferredSize(new Dimension(78, 32));
        cbDay.setPreferredSize(new Dimension(64, 32));
        cbYear.setPreferredSize(new Dimension(86, 32));
        final JComboBox<String> fMethod = new JComboBox<>(
                new String[]{"Cash", "Card", "Bank Transfer", "Insurance", "E-Wallet"});
        final JComboBox<String> fStatus = new JComboBox<>(
                new String[]{"Paid", "Pending", "Partial"});

        // ---- Assigned Staff: LOCKED to the logged-in account ----
        // No picker - whoever logs in (Staff Member, etc.) owns the sale.
        // This is what the Admin Sales Report filter groups by.
        com.optimotion.models.User me = com.optimotion.utils.Session.current();
        final int lockedStaffId = (me == null) ? -1 : me.getId();
        final String lockedStaffName = (me == null)
                ? "Not logged in"
                : me.getId() + " - " + me.getFullName();
        final JTextField txtStaffLocked = new JTextField(lockedStaffName);
        txtStaffLocked.setEditable(false);
        txtStaffLocked.setFocusable(false);
        txtStaffLocked.setBackground(new Color(243, 246, 249));
        txtStaffLocked.setFont(new Font("Segoe UI", Font.BOLD, 13));
        txtStaffLocked.setForeground(UIUtil.TEXT_MAIN);

        if (existing != null) {
            selectById(cbPatient, existing.getPatientId());
            String pd = existing.getPaymentDate() == null ? "" : existing.getPaymentDate();
            if (pd.matches("\\d{4}-\\d{2}-\\d{2}")) {
                cbYear.setSelectedItem(Integer.parseInt(pd.substring(0, 4)));
                cbMonth.setSelectedIndex(Integer.parseInt(pd.substring(5, 7)) - 1);
                refillDays.run();
                cbDay.setSelectedItem(Integer.parseInt(pd.substring(8, 10)));
            }
            fMethod.setSelectedItem(existing.getMethod());
            fStatus.setSelectedItem(existing.getStatus());
            // Note: saving re-locks staff to the current login (see btnSave).
        }
        // Load treatments for the initially selected patient (pre-ticks all).
        reloadTreatments.run();
        // On edit, keep only the previously linked treatment ticked if still present.
        if (existing != null && existing.getTreatmentId() != null) {
            boolean found = false;
            for (int i = 0; i < treatOptions.size(); i++) {
                boolean match = treatOptions.get(i).getId() == existing.getTreatmentId();
                treatChecks.get(i).setSelected(match);
                if (match) found = true;
            }
            if (found) refreshTreatTotal.run();
        }

        java.awt.Window owner = javax.swing.SwingUtilities.getWindowAncestor(this);
        final JDialog dlg = new JDialog(owner,
                existing == null ? "Record Payment" : "Update Payment",
                java.awt.Dialog.ModalityType.APPLICATION_MODAL);

        JPanel banner = new JPanel(new BorderLayout(0, 2));
        banner.setBackground(ACCENT);
        banner.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        JLabel hTitle = new JLabel(existing == null ? "RECORD PAYMENT" : "UPDATE PAYMENT");
        hTitle.setFont(new Font("Segoe UI", Font.BOLD, 16));
        hTitle.setForeground(Color.WHITE);
        JLabel hSub = new JLabel("Save a patient payment");
        hSub.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        hSub.setForeground(new Color(232, 245, 233));
        banner.add(hTitle, BorderLayout.NORTH);
        banner.add(hSub, BorderLayout.SOUTH);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(Color.WHITE);
        body.setBorder(BorderFactory.createEmptyBorder(14, 16, 14, 16));
        body.add(payCap("PATIENT"));
        body.add(Box.createVerticalStrut(2));
        body.add(fullWidth(cbPatient));
        body.add(Box.createVerticalStrut(8));
        body.add(payCap("TREATMENTS (tick to include in total)"));
        body.add(Box.createVerticalStrut(2));
        JLabel lblPayRule = new JLabel("Payments are allowed only for completed therapy sessions.");
        lblPayRule.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblPayRule.setForeground(new Color(0, 105, 92));
        lblPayRule.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        body.add(lblPayRule);
        body.add(Box.createVerticalStrut(2));
        body.add(treatScroll);
        body.add(Box.createVerticalStrut(4));
        body.add(lblTreatTotal);
        body.add(Box.createVerticalStrut(8));
        body.add(payCap("PAYMENT DATE"));
        body.add(Box.createVerticalStrut(2));
        datePanel.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        body.add(datePanel);
        body.add(Box.createVerticalStrut(8));
        body.add(payCap("METHOD"));
        body.add(Box.createVerticalStrut(2));
        body.add(fullWidth(fMethod));
        body.add(Box.createVerticalStrut(8));
        body.add(payCap("STATUS"));
        body.add(Box.createVerticalStrut(2));
        body.add(fullWidth(fStatus));
        body.add(Box.createVerticalStrut(8));
        body.add(payCap("ASSIGNED STAFF (locked to your login)"));
        body.add(Box.createVerticalStrut(2));
        body.add(fullWidth(txtStaffLocked));

        datePanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 48));
        stylePayInputs(body);

        JPanel btnBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 12));
        btnBar.setBackground(Color.WHITE);
        btnBar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIUtil.BORDER));
        JButton btnSave = UIUtil.solidButton("Save Payment", new Color(46, 125, 50));
        btnSave.setPreferredSize(new Dimension(170, 38));
        JButton btnCancel = neutralButton("Cancel");
        btnBar.add(btnCancel);
        btnBar.add(btnSave);

        JScrollPane scroll = new JScrollPane(body,
                JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        int maxH;
        try {
            maxH = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height - 120;
        } catch (Exception ex2) { maxH = 640; }
        scroll.setPreferredSize(new Dimension(560, Math.min(540, Math.max(420, maxH))));
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        dlg.getContentPane().setLayout(new BorderLayout());
        dlg.getContentPane().add(banner, BorderLayout.NORTH);
        dlg.getContentPane().add(scroll, BorderLayout.CENTER);
        dlg.getContentPane().add(btnBar, BorderLayout.SOUTH);

        btnCancel.addActionListener(e -> dlg.dispose());
        btnSave.addActionListener(e -> {
            if (lockedStaffId < 0) {
                UIUtil.showError(dlg, "No logged-in user. Please log in again.");
                return;
            }
            if (totalTreatIds.isEmpty() || totalHolder[0] <= 0) {
                UIUtil.showError(dlg, "Tick at least one treatment for this patient first.");
                return;
            }
            // Therapy gate: every ticked session must be completed, otherwise
            // stay on this page so staff can review the appointment details.
            try {
                com.optimotion.controllers.PaymentController.requireTherapiesCompleted(totalTreatIds);
            } catch (IllegalArgumentException ex2) {
                UIUtil.showError(dlg, ex2.getMessage());
                return;
            } catch (Exception ex2) {
                UIUtil.showError(dlg, "Could not verify therapy status: " + ex2.getMessage());
                return;
            }
            double amount = totalHolder[0];
            // Composed from dropdowns, so the date is always a real calendar date.
            String payDate = String.format("%04d-%02d-%02d",
                    (Integer) cbYear.getSelectedItem(),
                    cbMonth.getSelectedIndex() + 1,
                    (Integer) cbDay.getSelectedItem());

            Payment p = existing == null ? new Payment() : existing;
            try {
                p.setPatientId(parseId((String) cbPatient.getSelectedItem()));
            } catch (Exception ex2) {
                UIUtil.showError(dlg, "Please select a valid patient."); return;
            }
            p.setTreatmentId(totalTreatIds.isEmpty() ? null : totalTreatIds.get(0));
            p.setStaffUserId(lockedStaffId);
            p.setAmount(amount);
            p.setPaymentDate(payDate);
            p.setMethod((String) fMethod.getSelectedItem());
            p.setStatus((String) fStatus.getSelectedItem());

            try {
                boolean ok = (existing == null) ? ctrl.create(p) : ctrl.update(p);
                if (ok) {
                    dlg.dispose();
                    UIUtil.showSuccess(PaymentPanel.this, "Payment saved.");
                    loadAll();
                } else UIUtil.showError(dlg, "Save failed.");
            } catch (Exception ex2) {
                String msg = ex2.getMessage() == null ? "" : ex2.getMessage();
                if (msg.equals(com.optimotion.controllers.PaymentController.THERAPY_ONGOING_MSG)) {
                    // Therapy gate (controller final check): show verbatim, stay on page.
                    UIUtil.showError(dlg, msg);
                } else if (msg.toLowerCase().contains("foreign key")
                        || msg.toLowerCase().contains("cannot add or update")) {
                    UIUtil.showError(dlg, "Save failed: linked patient no longer exists.\n"
                            + "Refresh and try again.");
                } else {
                    UIUtil.showError(dlg, "Save failed: " + ex2.getMessage());
                }
            }
        });

        dlg.pack();
        dlg.setLocationRelativeTo(null);
        dlg.setVisible(true);
    }

    /** Small muted caption placed above payment fields. */
    private JLabel payCap(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 11));
        l.setForeground(UIUtil.TEXT_MUTED);
        l.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        return l;
    }

    /** Full-width white wrapper (BorderLayout stretches the control edge to edge). */
    private JPanel fullWidth(JComponent c) {
        JPanel w = new JPanel(new BorderLayout(0, 0));
        w.setBackground(Color.WHITE);
        w.setAlignmentX(java.awt.Component.LEFT_ALIGNMENT);
        w.add(c, BorderLayout.CENTER);
        // Cap height so BoxLayout never stretches it (and its control) vertically.
        w.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        return w;
    }

    /** Neutral secondary button (matches the booking dialog style). */
    private JButton neutralButton(String text) {
        JButton b = new JButton(text);
        b.setBackground(Color.WHITE);
        b.setForeground(new Color(51, 65, 85));
        b.setFont(new Font("Segoe UI", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setBorder(new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10));
        b.setPreferredSize(new Dimension(140, 38));
        final Color base = Color.WHITE;
        final Color hover = new Color(241, 245, 249);
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            @Override public void mouseExited(java.awt.event.MouseEvent e) { b.setBackground(base); }
        });
        return b;
    }

    /**
     * Uniform modern inputs: rounded borders, comfortable heights, white
     * background. Combos are non-focusable so no dotted focus rectangle shows.
     */
    private void stylePayInputs(java.awt.Container root) {
        for (java.awt.Component c : root.getComponents()) {
            if (c instanceof JTextField) {
                JTextField f = (JTextField) c;
                f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                f.setBackground(Color.WHITE);
                f.setBorder(BorderFactory.createCompoundBorder(
                        new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                        BorderFactory.createEmptyBorder(2, 8, 2, 8)));
                Dimension d = f.getPreferredSize();
                f.setPreferredSize(new Dimension(d.width, 32));
            } else if (c instanceof JComboBox) {
                JComboBox<?> cb = (JComboBox<?>) c;
                cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                cb.setBackground(Color.WHITE);
                cb.setFocusable(false);
                cb.setBorder(BorderFactory.createCompoundBorder(
                        new UIUtil.RoundedBorder(UIUtil.BORDER_DARK, 10),
                        BorderFactory.createEmptyBorder(2, 4, 2, 4)));
            } else if (c instanceof JTextArea) {
                JTextArea a = (JTextArea) c;
                a.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                a.setBackground(Color.WHITE);
            }
            if (c instanceof java.awt.Container) stylePayInputs((java.awt.Container) c);
        }
    }

    /** Extracts the numeric ID from a "ID - name" combo item. */
    private int parseId(String item) {
        int dash = item.indexOf(" - ");
        String idPart = (dash < 0) ? item.trim() : item.substring(0, dash).trim();
        return Integer.parseInt(idPart);
    }

    /** Selects the combo entry whose ID prefix matches, or index 0 if not found. */
    private void selectById(JComboBox<String> cb, int id) {
        String prefix = id + " - ";
        for (int i = 0; i < cb.getItemCount(); i++) {
            String item = cb.getItemAt(i);
            if (item != null && item.startsWith(prefix)) {
                cb.setSelectedIndex(i);
                return;
            }
        }
        if (cb.getItemCount() > 0) cb.setSelectedIndex(0);
    }
}
