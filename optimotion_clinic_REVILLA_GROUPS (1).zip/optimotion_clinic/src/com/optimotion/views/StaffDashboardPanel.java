package com.optimotion.views;

import com.optimotion.controllers.PaymentController;
import com.optimotion.models.Payment;
import com.optimotion.models.User;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;


public class StaffDashboardPanel extends JPanel {

    private static final Color BLUE = new Color(33, 150, 243);
    private static final Color ORANGE = new Color(255, 152, 0);
    private static final Color TEAL = new Color(0, 150, 136);
    private static final Color RED = new Color(211, 47, 47);

    private final JPanel statsRow = new JPanel(new GridLayout(1, 4, 12, 12));
    private final DefaultTableModel recentModel = new DefaultTableModel(
            new String[]{"ID", "Date", "Patient", "Method", "Status", "Amount"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final DefaultTableModel methodModel = new DefaultTableModel(
            new String[]{"Method", "Transactions", "Total"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };

    public StaffDashboardPanel(User user) {
        setLayout(new BorderLayout(12, 12));
        setBackground(UIUtil.BG);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // ---- Header banner ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(UIUtil.PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JLabel title = new JLabel("Sales Dashboard");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Hello, " + user.getFullName() + "  |  " + LocalDate.now()
                + "  |  Clinic sales at a glance");
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(220, 240, 238));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);
        add(header, BorderLayout.NORTH);

        // ---- Center ----
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center, BoxLayout.Y_AXIS));
        center.setBackground(UIUtil.BG);

        statsRow.setBackground(UIUtil.BG);
        statsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 115));
        center.add(statsRow);
        center.add(Box.createVerticalStrut(12));

        JPanel tablesRow = new JPanel(new GridLayout(1, 2, 12, 12));
        tablesRow.setBackground(UIUtil.BG);
        tablesRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 340));

        JTable recentTable = new JTable(recentModel);
        UIUtil.styleTable(recentTable);
        UIUtil.enableToggleDeselect(recentTable);
        JPanel recentCard = tableCard("Recent Payments", recentTable);

        JTable methodTable = new JTable(methodModel);
        UIUtil.styleTable(methodTable);
        UIUtil.enableToggleDeselect(methodTable);
        JPanel methodCard = tableCard("Sales by Payment Method (Paid)", methodTable);

        tablesRow.add(recentCard);
        tablesRow.add(methodCard);
        center.add(tablesRow);

        JScrollPane scroll = new JScrollPane(center);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        add(scroll, BorderLayout.CENTER);

        loadData();
    }

    private JPanel tableCard(String title, JTable table) {
        JPanel p = UIUtil.cardWrapper(title);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(null);
        p.add(sp, BorderLayout.CENTER);
        return p;
    }

    /** Reloads sales figures (called by the global Bookings refresh). */
    public void refresh() {
        loadData();
    }

    private void loadData() {
        try {
            PaymentController pc = new PaymentController();
            List<Payment> all;
            try {
                all = pc.getAll();
            } catch (Exception e) {
                all = new ArrayList<>();
            }
            String today = LocalDate.now().toString();
            String month = YearMonth.now().toString(); // yyyy-MM

            double total = 0, todaySum = 0, monthSum = 0, outstanding = 0;
            Map<String, double[]> byMethod = new LinkedHashMap<>(); // method -> [count, sum]

            recentModel.setRowCount(0);
            int shown = 0;
            for (Payment p : all) {
                double amt = p.getAmount();
                String st = p.getStatus() == null ? "" : p.getStatus();
                String pd = p.getPaymentDate() == null ? "" : p.getPaymentDate();
                if ("Paid".equals(st)) {
                    total += amt;
                    if (pd.equals(today)) todaySum += amt;
                    if (pd.startsWith(month)) monthSum += amt;
                    String m = p.getMethod() == null || p.getMethod().isEmpty() ? "-" : p.getMethod();
                    double[] agg = byMethod.get(m);
                    if (agg == null) { agg = new double[2]; byMethod.put(m, agg); }
                    agg[0] += 1;
                    agg[1] += amt;
                } else if ("Pending".equals(st) || "Partial".equals(st)) {
                    outstanding += amt;
                }
                if (shown < 12) {
                    recentModel.addRow(new Object[]{p.getId(), pd, nz(p.getPatientName()),
                            nz(p.getMethod()), st, peso(amt)});
                    shown++;
                }
            }

            methodModel.setRowCount(0);
            for (Map.Entry<String, double[]> e : byMethod.entrySet()) {
                methodModel.addRow(new Object[]{e.getKey(),
                        String.valueOf((int) e.getValue()[0]), peso(e.getValue()[1])});
            }

            statsRow.removeAll();
            statsRow.add(statCard("Total Revenue", peso(total), TEAL));
            statsRow.add(statCard("Today's Sales", peso(todaySum), ORANGE));
            statsRow.add(statCard("This Month's Sales", peso(monthSum), BLUE));
            statsRow.add(statCard("Outstanding Balance", peso(outstanding), RED));
            statsRow.revalidate();
            statsRow.repaint();
        } catch (Exception ex) {
            UIUtil.showError(this, "Dashboard load failed: " + ex.getMessage());
        }
    }

    private String peso(double v) {
        return String.format("₱%,.2f", v);
    }

    private String nz(String s) { return s == null ? "" : s; }

    private JPanel statCard(String label, String value, Color accent) {
        return UIUtil.statCard(label, value, accent);
    }
}
