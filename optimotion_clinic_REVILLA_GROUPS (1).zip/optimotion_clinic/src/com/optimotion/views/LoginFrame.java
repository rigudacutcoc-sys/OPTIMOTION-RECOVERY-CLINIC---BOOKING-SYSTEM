package com.optimotion.views;

import com.optimotion.controllers.AuthController;
import com.optimotion.database.DBConnection;
import com.optimotion.models.User;
import com.optimotion.utils.FloatingField;
import com.optimotion.utils.Session;
import com.optimotion.utils.UIUtil;
import com.optimotion.utils.ValidationUtil;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class LoginFrame extends JFrame {

    private final FloatingField.HintTextField txtUser = new FloatingField.HintTextField("Username", 20);
    private final FloatingField.HintPasswordField txtPass = new FloatingField.HintPasswordField("Password", 20);
    private final JCheckBox chkShow = new JCheckBox("Show password");
    private final AuthController auth = new AuthController();

    public LoginFrame() {
        setTitle("Optimotion Recovery Clinic - Login");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(880, 560);
        setMinimumSize(new Dimension(780, 500));
        setLocationRelativeTo(null);
        setResizable(false);
        UIUtil.setWindowIcon(this);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        // ---------- Left branding panel (gradient, same content) ----------
        JPanel brand = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, UIUtil.PRIMARY,
                        0, getHeight(), UIUtil.PRIMARY_DARK);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                // soft decorative circle
                g2.setColor(new Color(255, 255, 255, 22));
                g2.fillOval(-90, -90, 260, 260);
                g2.setColor(new Color(255, 255, 255, 14));
                g2.fillOval(180, 330, 280, 280);
                g2.dispose();
            }
        };
        brand.setPreferredSize(new Dimension(370, 0));
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));
        brand.setBorder(new EmptyBorder(44, 38, 30, 38));

        // Logo (if found) else text brand
        ImageIcon logo = UIUtil.loadLogo(220, 64);
        if (logo != null) {
            JLabel logoLbl = new JLabel(logo);
            logoLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            brand.add(logoLbl);
            brand.add(Box.createVerticalStrut(10));
        }
        JLabel name = new JLabel("OPTIMOTION");
        name.setFont(new Font("Segoe UI", Font.BOLD, 30));
        name.setForeground(Color.WHITE);
        name.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub1 = new JLabel("R E C O V E R Y   C L I N I C");
        sub1.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        sub1.setForeground(new Color(224, 242, 241));
        sub1.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel tagline = new JLabel("Care. Recovery. Motion.");
        tagline.setFont(new Font("Segoe UI", Font.ITALIC, 14));
        tagline.setForeground(Color.WHITE);
        tagline.setAlignmentX(Component.LEFT_ALIGNMENT);

        brand.add(Box.createVerticalStrut(4));
        brand.add(name);
        brand.add(sub1);
        brand.add(Box.createVerticalStrut(10));
        brand.add(tagline);
        brand.add(Box.createVerticalStrut(26));

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setForeground(new Color(178, 223, 219));
        sep.setBackground(new Color(178, 223, 219));
        brand.add(sep);
        brand.add(Box.createVerticalStrut(20));

        for (String f : new String[]{"\u2022  Patient records & history",
                                     "\u2022  Appointments & treatments",
                                     "\u2022  Billing, services & reports"}) {
            JLabel b = new JLabel(f);
            b.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            b.setForeground(Color.WHITE);
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            // soft pill background for a modern touch
            brand.add(b);
            brand.add(Box.createVerticalStrut(10));
        }

        brand.add(Box.createVerticalGlue());

        root.add(brand, BorderLayout.WEST);

        // ---------- Right sign-in card ----------
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(new Color(248, 250, 252));
        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 16),
                new EmptyBorder(28, 34, 28, 34)));

        JLabel welcome = new JLabel("Welcome back");
        welcome.setFont(new Font("Segoe UI", Font.BOLD, 26));
        welcome.setForeground(UIUtil.TEXT_MAIN);
        welcome.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel hint = new JLabel("Log in to your clinic account");
        hint.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        hint.setForeground(UIUtil.TEXT_MUTED);
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);

        card.add(welcome);
        card.add(Box.createVerticalStrut(4));
        card.add(hint);
        card.add(Box.createVerticalStrut(24));

        txtPass.setEchoChar('\u2022');
        FloatingField userFloat = new FloatingField(txtUser, "Username");
        userFloat.setAlignmentX(Component.LEFT_ALIGNMENT);
        FloatingField passFloat = new FloatingField(txtPass, "Password");
        passFloat.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(userFloat);
        card.add(Box.createVerticalStrut(12));
        card.add(passFloat);
        chkShow.setBackground(Color.WHITE);
        chkShow.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        chkShow.setForeground(UIUtil.TEXT_MUTED);
        chkShow.setAlignmentX(Component.LEFT_ALIGNMENT);
        chkShow.addActionListener(e -> txtPass.setEchoChar(chkShow.isSelected() ? (char) 0 : '\u2022'));
        card.add(Box.createVerticalStrut(6));
        card.add(chkShow);
        card.add(Box.createVerticalStrut(18));

        JButton btnLogin = new JButton("Log In  \u2192");
        UIUtil.styleButton(btnLogin);
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogin.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        btnLogin.setPreferredSize(new Dimension(0, 46));
        card.add(btnLogin);

        right.add(card);
        root.add(right, BorderLayout.CENTER);

        btnLogin.addActionListener(e -> doLogin());
        txtPass.addActionListener(e -> doLogin());
        txtUser.addActionListener(e -> doLogin());

        enableClickToDeselect(root);
        setContentPane(root);
    }

    /** Clicking empty background deselects / blurs the floating fields. */
    private void enableClickToDeselect(java.awt.Container parent) {
        parent.setFocusable(true);
        java.awt.event.MouseAdapter defocus = new java.awt.event.MouseAdapter() {
            @Override public void mousePressed(java.awt.event.MouseEvent e) {
                java.awt.Component owner = java.awt.KeyboardFocusManager
                        .getCurrentKeyboardFocusManager().getFocusOwner();
                if (owner == txtUser || owner == txtPass) {
                    java.awt.Component clicked = e.getComponent();
                    if (clicked != null && clicked.isFocusable()
                            && !(clicked instanceof javax.swing.text.JTextComponent)) {
                        clicked.requestFocusInWindow();
                    } else {
                        parent.requestFocusInWindow();
                    }
                    txtUser.select(0, 0);
                    txtPass.select(0, 0);
                }
            }
        };
        addDefocusListener(parent, defocus);
    }

    private void addDefocusListener(java.awt.Container parent,
            java.awt.event.MouseAdapter defocus) {
        parent.addMouseListener(defocus);
        for (java.awt.Component child : parent.getComponents()) {
            if (child instanceof javax.swing.text.JTextComponent
                    || child instanceof FloatingField
                    || child instanceof JButton
                    || child instanceof JCheckBox) {
                continue; // text / buttons keep their own focus behaviour
            }
            if (child instanceof java.awt.Container) {
                addDefocusListener((java.awt.Container) child, defocus);
            } else {
                child.addMouseListener(defocus);
            }
        }
    }

    private void doLogin() {
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword());

        if (ValidationUtil.isEmpty(user) || ValidationUtil.isEmpty(pass)) {
            UIUtil.showError(this, "Please enter both username and password.");
            return;
        }
        if (!DBConnection.testConnection()) {
            UIUtil.showError(this, "Cannot connect to MySQL.\n1. Start MySQL in XAMPP\n2. Import database/optimotion_db.sql");
            return;
        }
        try {
            User u = auth.login(user, pass);
            if (u != null) {
                Session.login(u); // role comes from the database here
                UIUtil.showSuccess(this, "Welcome, " + u.getFullName() + "!");
                dispose();
                new DashboardFrame(u).setVisible(true);
            } else {
                UIUtil.showError(this, "Invalid username or password.");
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Login failed: " + ex.getMessage());
        }
    }
}
