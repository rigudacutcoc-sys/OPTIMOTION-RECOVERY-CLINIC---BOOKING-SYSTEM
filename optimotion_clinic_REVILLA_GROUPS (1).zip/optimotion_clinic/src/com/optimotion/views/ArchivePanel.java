package com.optimotion.views;

import com.optimotion.controllers.AppointmentController;
import com.optimotion.controllers.PatientController;
import com.optimotion.controllers.PaymentController;
import com.optimotion.controllers.TreatmentController;
import com.optimotion.models.Appointment;
import com.optimotion.models.Patient;
import com.optimotion.models.Payment;
import com.optimotion.models.Treatment;
import com.optimotion.utils.UIUtil;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/**
 * ArchivePanel - READ-ONLY archived records view (ADMINISTRATORS ONLY).
 * Anything staff archives (bookings + cascaded customers/treatments/
 * payments) appears here automatically. Admin cannot archive, restore
 * or delete from this screen - archiving is staff's job.
 */
public class ArchivePanel extends JPanel {

    private static final Color ACCENT = new Color(69, 90, 100); // blue-grey
    private static final Color BLUE = new Color(33, 150, 243);
    private static final Color ORANGE = new Color(255, 152, 0);
    private static final Color TEAL = new Color(0, 150, 136);
    private static final Color GREEN = new Color(76, 175, 80);

    private final JPanel cardsRow = new JPanel(new GridLayout(1, 4, 12, 12));
    private final JLabel detailTitle = new JLabel("Archived Bookings");
    private final JLabel lblCount = new JLabel();
    private final DefaultTableModel detailModel = new DefaultTableModel() {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JTable detailTable = new JTable(detailModel);
    private final JTextField txtSearch = new JTextField(18);

    private final Map<String, JPanel> cards = new LinkedHashMap<>();
    private final Map<String, Color> accents = new LinkedHashMap<>();

    private List<Appointment> cachedBookings = new ArrayList<>();
    private List<Patient> cachedCustomers = new ArrayList<>();
    private List<Treatment> cachedTreatments = new ArrayList<>();
    private List<Payment> cachedPayments = new ArrayList<>();
    private String selectedKey = "Bookings";

    public ArchivePanel(com.optimotion.models.User user) {
        setLayout(new BorderLayout(0, 0));
        setBackground(UIUtil.BG);

        // Defense in depth: archive viewing is administrator-only.
        if (user == null || !user.isAdmin()) {
            JPanel denied = new JPanel(new GridBagLayout());
            denied.setBackground(UIUtil.BG);
            denied.add(new JLabel("<html><center><h2>Access denied</h2>"
                    + "The archive is for administrators only.</center></html>"));
            add(denied, BorderLayout.CENTER);
            return;
        }

        // ---- Header banner ----
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ACCENT);
        header.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        JPanel left = new JPanel(new GridLayout(2, 1));
        left.setOpaque(false);
        JLabel title = new JLabel("\uD83D\uDCC1  Archive");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Read-only  |  Staff-archived records appear here  |  " + LocalDate.now());
        sub.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        sub.setForeground(new Color(224, 242, 241));
        left.add(title);
        left.add(sub);
        header.add(left, BorderLayout.WEST);

        JPanel searchBox = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        searchBox.setOpaque(false);
        txtSearch.setPreferredSize(new Dimension(200, 32));
        UIUtil.styleSearchField(txtSearch);
        txtSearch.setToolTipText("Search within the selected archive...");
        JButton btnSearch = UIUtil.ghostButton("\uD83D\uDD0D Search", ACCENT.darker());
        // No Refresh button here: Archive reloads via the Dashboard Refresh
        // (global admin refresh in DashboardFrame).
        searchBox.add(txtSearch);
        searchBox.add(btnSearch);
        header.add(searchBox, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // ---- Center: cards + table ----
        JPanel centerWrap = new JPanel(new BorderLayout(0, 10));
        centerWrap.setBackground(UIUtil.BG);
        centerWrap.setBorder(BorderFactory.createEmptyBorder(14, 14, 10, 14));

        JPanel top = new JPanel();
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
        top.setBackground(UIUtil.BG);
        cardsRow.setBackground(UIUtil.BG);
        cardsRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 105));
        top.add(cardsRow);
        centerWrap.add(top, BorderLayout.NORTH);

        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new UIUtil.RoundedBorder(UIUtil.BORDER, 14),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        detailTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        detailTitle.setForeground(UIUtil.TEXT_MAIN);
        card.add(detailTitle, BorderLayout.NORTH);
        UIUtil.styleTable(detailTable);
        UIUtil.enableToggleDeselect(detailTable);
        detailTable.getTableHeader().setBackground(ACCENT);
        detailTable.setAutoCreateRowSorter(true);
        JScrollPane tableScroll = new JScrollPane(detailTable);
        tableScroll.setBorder(null);
        card.add(tableScroll, BorderLayout.CENTER);
        centerWrap.add(card, BorderLayout.CENTER);
        add(centerWrap, BorderLayout.CENTER);

        // ---- Footer: read-only note + count ----
        JPanel footer = new JPanel(new BorderLayout());
        footer.setBackground(UIUtil.BG);
        footer.setBorder(BorderFactory.createEmptyBorder(0, 14, 14, 14));
        JLabel ro = new JLabel("Read-only: archiving and restoring are done by staff under Bookings.");
        ro.setFont(new Font("Segoe UI", Font.ITALIC, 12));
        ro.setForeground(UIUtil.TEXT_MUTED);
        footer.add(ro, BorderLayout.WEST);
        lblCount.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblCount.setForeground(UIUtil.TEXT_MUTED);
        footer.add(lblCount, BorderLayout.EAST);
        add(footer, BorderLayout.SOUTH);

        btnSearch.addActionListener(e -> loadSearch());
        txtSearch.addActionListener(e -> loadSearch());

        loadAll();
    }

    /** Reloads archived records (called by the global Dashboard refresh). */
    public void refresh() {
        txtSearch.setText("");
        loadAll();
    }

    // ================= DATA + RENDER =================

    private void loadAll() {
        try { cachedBookings = new AppointmentController().getArchived(); }
        catch (Exception e) { cachedBookings = new ArrayList<>(); }
        try { cachedCustomers = new PatientController().getArchived(); }
        catch (Exception e) { cachedCustomers = new ArrayList<>(); }
        try { cachedTreatments = new TreatmentController().getArchived(); }
        catch (Exception e) { cachedTreatments = new ArrayList<>(); }
        try { cachedPayments = new PaymentController().getArchived(); }
        catch (Exception e) { cachedPayments = new ArrayList<>(); }

        cardsRow.removeAll();
        cards.clear();
        accents.clear();
        cardsRow.add(makeCard("Bookings", String.valueOf(cachedBookings.size()), ORANGE));
        cardsRow.add(makeCard("Customers", String.valueOf(cachedCustomers.size()), BLUE));
        cardsRow.add(makeCard("Treatments", String.valueOf(cachedTreatments.size()), TEAL));
        cardsRow.add(makeCard("Payments", String.valueOf(cachedPayments.size()), GREEN));
        highlightSelection();
        cardsRow.revalidate();
        cardsRow.repaint();

        showDetail(selectedKey);
    }

    private void loadSearch() {
        String k = txtSearch.getText().trim();
        if (k.isEmpty()) { loadAll(); return; }
        try {
            switch (selectedKey) {
                case "Customers" -> {
                    try { cachedCustomers = new PatientController().searchArchived(k); }
                    catch (Exception e) { cachedCustomers = new ArrayList<>(); }
                }
                case "Treatments" -> {
                    try { cachedTreatments = new TreatmentController().searchArchived(k); }
                    catch (Exception e) { cachedTreatments = new ArrayList<>(); }
                }
                case "Payments" -> {
                    try { cachedPayments = new PaymentController().searchArchived(k); }
                    catch (Exception e) { cachedPayments = new ArrayList<>(); }
                }
                default -> {
                    try { cachedBookings = new AppointmentController().searchArchived(k); }
                    catch (Exception e) { cachedBookings = new ArrayList<>(); }
                }
            }
        } catch (Exception ex) {
            UIUtil.showError(this, "Search failed: " + ex.getMessage());
        }
        showDetail(selectedKey);
    }

    private JPanel makeCard(String key, String value, Color accent) {
        JPanel card = UIUtil.statCard(key, value, accent);
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));
        card.setToolTipText("Click to view archived " + key.toLowerCase());
        card.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                selectedKey = key;
                txtSearch.setText("");
                loadAll();
            }
        });
        cards.put(key, card);
        accents.put(key, accent);
        return card;
    }

    private void highlightSelection() {
        for (Map.Entry<String, JPanel> e : cards.entrySet()) {
            String key = e.getKey();
            JPanel card = e.getValue();
            Color accent = accents.getOrDefault(key, UIUtil.PRIMARY);
            if (key.equals(selectedKey)) {
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(accent, 2, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)));
            } else {
                card.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(UIUtil.BORDER, 1, true),
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)));
            }
        }
        cardsRow.revalidate();
        cardsRow.repaint();
    }

    private void showDetail(String key) {
        if (key == null) key = "Bookings";
        selectedKey = key;
        highlightSelection();
        detailModel.setRowCount(0);
        switch (key) {
            case "Customers" -> {
                detailModel.setColumnIdentifiers(
                        new String[]{"ID", "Full Name", "Gender", "Date of Birth", "Phone", "Email", "Address"});
                for (Patient p : cachedCustomers) {
                    detailModel.addRow(new Object[]{p.getId(), nz(p.getFullName()), nz(p.getGender()),
                            nz(p.getDob()), nz(p.getPhone()), nz(p.getEmail()), nz(p.getAddress())});
                }
                detailTitle.setText("Archived Customers (" + cachedCustomers.size() + " records)");
                lblCount.setText("Total records: " + cachedCustomers.size());
            }
            case "Treatments" -> {
                detailModel.setColumnIdentifiers(
                        new String[]{"ID", "Patient", "Type", "Sessions", "Date", "Progress", "Cost"});
                for (Treatment t : cachedTreatments) {
                    detailModel.addRow(new Object[]{t.getId(), nz(t.getPatientName()),
                            nz(t.getTreatmentType()), t.getSessionCount(), nz(t.getSessionDate()),
                            nz(t.getProgress()), String.format("\u20B1 %.2f", t.getCost())});
                }
                detailTitle.setText("Archived Treatments (" + cachedTreatments.size() + " records)");
                lblCount.setText("Total records: " + cachedTreatments.size());
            }
            case "Payments" -> {
                detailModel.setColumnIdentifiers(
                        new String[]{"ID", "Patient", "Treatment ID", "Amount", "Date", "Method", "Status"});
                for (Payment p : cachedPayments) {
                    detailModel.addRow(new Object[]{p.getId(), nz(p.getPatientName()),
                            p.getTreatmentId() == null ? "-" : p.getTreatmentId(),
                            String.format("\u20B1 %.2f", p.getAmount()), nz(p.getPaymentDate()),
                            nz(p.getMethod()), nz(p.getStatus())});
                }
                detailTitle.setText("Archived Payments (" + cachedPayments.size() + " records)");
                lblCount.setText("Total records: " + cachedPayments.size());
            }
            default -> {
                detailModel.setColumnIdentifiers(
                        new String[]{"ID", "Patient", "Date & Time", "Status"});
                for (Appointment a : cachedBookings) {
                    detailModel.addRow(new Object[]{a.getId(), nz(a.getPatientName()),
                            nz(a.getAppointmentDate()), nz(a.getStatus())});
                }
                detailTitle.setText("Archived Bookings (" + cachedBookings.size() + " records)");
                lblCount.setText("Total records: " + cachedBookings.size());
            }
        }
        detailTable.clearSelection();
    }

    private String nz(String s) { return s == null ? "" : s; }
}
