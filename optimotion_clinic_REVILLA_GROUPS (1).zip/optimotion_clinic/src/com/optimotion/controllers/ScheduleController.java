package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Schedule;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ScheduleController - staff schedules and availability.
 * Reading is open to all logged-in users (staff view their schedule);
 * creating, editing and deleting entries is ADMINISTRATORS ONLY.
 */
public class ScheduleController extends BaseController implements Manageable<Schedule> {

    private static final String BASE =
        "SELECT s.*, u.full_name AS sname FROM schedules s "
      + "LEFT JOIN users u ON s.staff_user_id = u.id ";

    // ================= Admin-only writes =================

    public boolean create(Schedule s) throws SQLException {
        Session.requireAdmin();
        validate(s);
        String sql = "INSERT INTO schedules (staff_user_id, sched_date, start_time, end_time, status, notes)"
                   + " VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, s);
            return ps.executeUpdate() == 1;
        }
    }

    public boolean update(Schedule s) throws SQLException {
        Session.requireAdmin();
        validate(s);
        String sql = "UPDATE schedules SET staff_user_id=?, sched_date=?, start_time=?, end_time=?, status=?, notes=?"
                   + " WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, s);
            ps.setInt(7, s.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(int id) throws SQLException {
        Session.requireAdmin();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM schedules WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    // ================= Reads (all logged-in users) =================

    public List<Schedule> getAll() throws SQLException {
        Session.requireLogin();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(BASE + "ORDER BY s.sched_date DESC, s.start_time");
             ResultSet rs = ps.executeQuery()) {
            return mapAll(rs);
        }
    }

    /** Schedules assigned to one staff user (or unassigned to anyone). */
    public List<Schedule> forStaff(int staffUserId) throws SQLException {
        Session.requireLogin();
        String sql = BASE + "WHERE s.staff_user_id IS NULL OR s.staff_user_id=? "
                   + "ORDER BY s.sched_date DESC, s.start_time";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, staffUserId);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    public List<Schedule> search(String keyword) throws SQLException {
        Session.requireLogin();
        String sql = BASE + "WHERE s.sched_date LIKE ? OR s.status LIKE ? OR u.full_name LIKE ? "
                   + "ORDER BY s.sched_date DESC, s.start_time";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    public int count() throws SQLException {
        Session.requireLogin();
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM schedules")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    // ================= Helpers =================

    private void validate(Schedule s) {
        if (s.getSchedDate() == null || !s.getSchedDate().matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("Date must be yyyy-MM-dd.");
        }
        if (s.getStartTime() == null || !s.getStartTime().matches("\\d{2}:\\d{2}")
                || s.getEndTime() == null || !s.getEndTime().matches("\\d{2}:\\d{2}")) {
            throw new IllegalArgumentException("Start/end must be HH:mm.");
        }
        if (s.getStartTime().compareTo(s.getEndTime()) >= 0) {
            throw new IllegalArgumentException("Start time must be before end time.");
        }
    }

    private void bind(PreparedStatement ps, Schedule s) throws SQLException {
        if (s.getStaffUserId() == null) ps.setNull(1, Types.INTEGER);
        else ps.setInt(1, s.getStaffUserId());
        ps.setString(2, s.getSchedDate());
        ps.setString(3, s.getStartTime());
        ps.setString(4, s.getEndTime());
        ps.setString(5, s.getStatus());
        ps.setString(6, s.getNotes());
    }

    private List<Schedule> mapAll(ResultSet rs) throws SQLException {
        List<Schedule> list = new ArrayList<>();
        while (rs.next()) {
            Schedule s = new Schedule();
            s.setId(rs.getInt("id"));
            int uid = rs.getInt("staff_user_id");
            s.setStaffUserId(rs.wasNull() ? null : uid);
            String nm = rs.getString("sname");
            s.setStaffName(nm == null ? "All staff" : nm);
            Date d = rs.getDate("sched_date");
            s.setSchedDate(d == null ? "" : d.toString());
            s.setStartTime(rs.getString("start_time").substring(0, 5));
            s.setEndTime(rs.getString("end_time").substring(0, 5));
            s.setStatus(rs.getString("status"));
            s.setNotes(rs.getString("notes") == null ? "" : rs.getString("notes"));
            list.add(s);
        }
        return list;
    }
}
