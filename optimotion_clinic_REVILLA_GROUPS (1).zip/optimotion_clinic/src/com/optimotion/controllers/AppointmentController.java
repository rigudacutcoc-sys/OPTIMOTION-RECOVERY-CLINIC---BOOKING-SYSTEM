package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Appointment;
import com.optimotion.models.Patient;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * AppointmentController - schedule / update / archive appointments.
 * <p>
 * Deleting from the UI is now ARCHIVING (is_archived=1) so booking history
 * is preserved. Archived bookings are hidden from the normal list but can
 * be viewed and restored via "Show archived". No permanent delete in UI.
 */
public class AppointmentController extends BaseController implements Manageable<Appointment> {

    /**
     * Booking workflow statuses. Each booking keeps its own independent status;
     * creating a new booking never modifies another booking's status.
     * "Scheduled" is kept for backward compatibility with existing rows.
     * "In Progress" marks a started session - additional bookings are still
     * allowed while another booking is Pending/Confirmed/Scheduled/In Progress,
     * as long as times do not overlap.
     */
    public static final String[] STATUSES = {"Pending", "Scheduled", "Confirmed", "In Progress", "Completed", "Cancelled"};

    private static final String BASE =
        "SELECT a.*, p.full_name AS pname, u.full_name AS sname FROM appointments a "
      + "JOIN patients p ON a.patient_id = p.id "
      + "LEFT JOIN users u ON a.staff_user_id = u.id ";

    private static volatile boolean archiveColChecked = false;
    private static volatile boolean staffColChecked = false;

    /** Best-effort migration: adds appointments.is_archived if missing (old DBs). */
    private static synchronized void ensureArchiveColumn() {
        if (archiveColChecked) return;
        archiveColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "appointments", "is_archived")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "APPOINTMENTS", "IS_ARCHIVED")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE appointments ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0");
                } catch (SQLException ignored) {
                    archiveColChecked = false;
                }
            }
        } catch (SQLException ignored) {
            archiveColChecked = false;
        }
    }

    private static boolean archiveReady() {
        ensureArchiveColumn();
        return archiveColChecked;
    }

    /**
     * Best-effort migration for staff data separation:
     * adds appointments.staff_user_id (nullable FK to users) if missing.
     * New bookings lock to Session.current().getId(); legacy NULL rows are
     * visible to administrators only.
     */
    static synchronized void ensureStaffColumn() {
        if (staffColChecked) return;
        staffColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "appointments", "staff_user_id")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "APPOINTMENTS", "STAFF_USER_ID")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE appointments ADD COLUMN staff_user_id INT NULL");
                } catch (SQLException ignored) {
                    staffColChecked = false;
                    return;
                }
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE appointments ADD CONSTRAINT fk_appt_staff "
                            + "FOREIGN KEY (staff_user_id) REFERENCES users(id) "
                            + "ON DELETE SET NULL ON UPDATE CASCADE");
                } catch (SQLException ignored) {}
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("CREATE INDEX idx_appt_staff ON appointments (staff_user_id)");
                } catch (SQLException ignored) {}
            }
        } catch (SQLException ignored) {
            staffColChecked = false;
        }
    }

    private static volatile boolean statusEnumChecked = false;

    /**
     * Best-effort migration: widens appointments.status ENUM to include
     * 'In Progress' on old databases. Fresh installs already have it
     * (see database/optimotion_db.sql). Safe to call repeatedly; failures
     * are ignored so old DBs keep working with the original 5 values.
     */
    static synchronized void ensureStatusEnum() {
        if (statusEnumChecked) return;
        statusEnumChecked = true;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {
            try {
                st.executeUpdate("ALTER TABLE appointments MODIFY COLUMN status "
                        + "ENUM('Pending','Scheduled','Confirmed','In Progress','Completed','Cancelled') "
                        + "NOT NULL DEFAULT 'Scheduled'");
            } catch (SQLException ignored) {
                // Old MySQL/MariaDB without the value or no ALTER privilege - code-side
                // STATUSES already accepts 'In Progress'; DB will reject only that value.
            }
        } catch (SQLException ignored) {}
    }

    /**
     * Staff isolation: administrators see all rows (null = no filter).
     * Staff see only their own rows (WHERE a.staff_user_id = ?).
     * Filtering happens in SQL - other staff rows are never loaded.
     */
    private static Integer staffScopeId() {
        try {
            if (Session.current() != null && Session.current().isAdmin()) return null;
            if (Session.current() != null) return Session.current().getId();
        } catch (Exception ignored) {}
        return null;
    }

    private static String staffClause(String alias, List<Object> params) {
        Integer sid = staffScopeId();
        if (sid == null) return "";
        params.add(sid);
        return " AND " + alias + ".staff_user_id=? ";
    }

    /** Blocks staff from touching another staff member's booking. */
    private static void requireOwnership(int appointmentId) throws SQLException {
        Integer sid = staffScopeId();
        if (sid == null) return; // admin or unknown session: no extra check
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT staff_user_id FROM appointments WHERE id=?")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new IllegalArgumentException(
                        "Appointment no longer exists. Please refresh.");
                int owner = rs.getInt(1);
                boolean hasOwner = !rs.wasNull();
                if (!hasOwner || owner != sid) throw new SecurityException(
                        "Access denied: this booking belongs to another staff member.");
            }
        } catch (SecurityException | IllegalArgumentException e) {
            throw e;
        } catch (SQLException e) {
            // Old DB without staff_user_id: fall back to allowing (column missing).
            try {
                ensureStaffColumn();
            } catch (Exception ignored) {}
        }
    }

    private static String activeFilter(String alias) {
        return "COALESCE(" + alias + ".is_archived,0)=0";
    }

    public boolean create(int patientId, String dateTime, String status, String notes) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        ensureStatusEnum();
        validateSlot(dateTime, -1);
        Integer owner = staffScopeId();
        // Multiple bookings per day are allowed for the same patient as long as
        // times do not overlap. Each INSERT creates its own unique Booking ID.
        validateSameDayOverlaps(null, patientId, owner, dateTime,
                defaultSlotMinutes(), -1);
        // Admin creating directly: keep unassigned unless explicitly set elsewhere.
        String sql = "INSERT INTO appointments (patient_id, staff_user_id, appointment_date, status, notes) VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
              PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, patientId);
            if (owner == null) ps.setNull(2, Types.INTEGER);
            else ps.setInt(2, owner);
            ps.setString(3, dateTime); // "yyyy-MM-dd HH:mm"
            ps.setString(4, status);
            ps.setString(5, notes);
            return ps.executeUpdate() == 1;
        }
    }

    /** Scoped select: staff get WHERE staff_user_id=? in SQL, admin gets all. */
    private List<Appointment> scopedList(String whereNoStaff, List<Object> extraParams,
                                        String orderBy) throws SQLException {
        ensureStaffColumn();
        List<Object> staffParam = new ArrayList<>();
        String staff = staffClause("a", staffParam);
        String sql = BASE + "WHERE " + whereNoStaff + staff + orderBy;
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            int i = 1;
            for (Object p : extraParams) ps.setString(i++, String.valueOf(p));
            for (Object p : staffParam) ps.setInt(i++, (Integer) p);
            try (ResultSet rs = ps.executeQuery()) { return attachServiceInfo(mapAll(rs)); }
        }
    }

    /** Active bookings only (default list). Staff see only their own (SQL-filtered). */
    public List<Appointment> getAll() throws SQLException {        if (!archiveReady()) {
            ensureStaffColumn();
            List<Object> sp = new ArrayList<>();
            String staff = staffClause("a", sp);
            String sql = BASE + (staff.isEmpty()
                    ? "ORDER BY a.appointment_date DESC"
                    : "WHERE 1=1" + staff + "ORDER BY a.appointment_date DESC");
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                for (int i = 0; i < sp.size(); i++) ps.setInt(i + 1, (Integer) sp.get(i));
                try (ResultSet rs = ps.executeQuery()) { return attachServiceInfo(mapAll(rs)); }
            }
        }
        return scopedList(activeFilter("a"), new ArrayList<>(), " ORDER BY a.appointment_date DESC");
    }

    /** Archived bookings only. Staff see only their own (SQL-filtered). */
    public List<Appointment> getArchived() throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        return scopedList("COALESCE(a.is_archived,0)=1", new ArrayList<>(),
                " ORDER BY a.appointment_date DESC");
    }

    /** All bookings regardless of archive status (for edit lookup, still staff-scoped). */
    public List<Appointment> getAllIncludingArchived() throws SQLException {
        ensureStaffColumn();
        List<Object> sp = new ArrayList<>();
        String staff = staffClause("a", sp);
        String sql = BASE + (staff.isEmpty()
                ? "ORDER BY a.appointment_date DESC"
                : "WHERE 1=1" + staff + "ORDER BY a.appointment_date DESC");
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            for (int i = 0; i < sp.size(); i++) ps.setInt(i + 1, (Integer) sp.get(i));
            try (ResultSet rs = ps.executeQuery()) { return attachServiceInfo(mapAll(rs)); }
        }
    }

    /**
     * Shared clinic-wide view for the Schedule calendar: all active bookings
     * regardless of owner (used by SchedulePanel so every staff sees the same
     * calendar). Bookings/Treatments/Payments lists stay staff-scoped.
     */
    public List<Appointment> getAllShared() throws SQLException {
        ensureStaffColumn();
        if (!archiveReady()) {
            return query(BASE + "ORDER BY a.appointment_date DESC");
        }
        return query(BASE + "WHERE " + activeFilter("a") + " ORDER BY a.appointment_date DESC");
    }

    public List<Appointment> search(String keyword) throws SQLException {
        String svcExists = "EXISTS (SELECT 1 FROM treatments t WHERE t.appointment_id=a.id AND t.treatment_type LIKE ?)";
        String where = "(p.full_name LIKE ? OR a.status LIKE ? OR a.notes LIKE ? OR u.full_name LIKE ? OR " + svcExists + ")";
        if (archiveReady()) {
            where = activeFilter("a") + " AND (p.full_name LIKE ? OR a.status LIKE ? OR a.notes LIKE ? OR u.full_name LIKE ? OR " + svcExists + ")";
        }
        String k = "%" + keyword.trim() + "%";
        List<Object> params = new ArrayList<>();
        params.add(k); params.add(k); params.add(k); params.add(k); params.add(k);
        return scopedList(where, params, " ORDER BY a.appointment_date DESC");
    }

    public List<Appointment> searchArchived(String keyword) throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        String k = "%" + keyword.trim() + "%";
        List<Object> params = new ArrayList<>();
        params.add(k); params.add(k); params.add(k); params.add(k); params.add(k);
        return scopedList("COALESCE(a.is_archived,0)=1 AND (p.full_name LIKE ? OR a.status LIKE ? OR a.notes LIKE ? OR u.full_name LIKE ?"
                + " OR EXISTS (SELECT 1 FROM treatments t WHERE t.appointment_id=a.id AND t.treatment_type LIKE ?))",
                params, " ORDER BY a.appointment_date DESC");
    }

    /**
     * All active appointments for one patient (staff-scoped), newest first.
     * Used to display multiple same-day bookings for the selected patient.
     * Same-day repeats are all returned - each row is a separate Booking ID.
     */
    public List<Appointment> getByPatient(int patientId) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        List<Object> params = new ArrayList<>();
        params.add(String.valueOf(patientId));
        String where = "a.patient_id=? ";
        if (archiveReady()) {
            where = activeFilter("a") + " AND a.patient_id=? ";
        }
        return scopedList(where, params, " ORDER BY a.appointment_date DESC");
    }

    /**
     * All active appointments for one patient on one calendar day
     * (yyyy-MM-dd). Multiple rows = multiple same-day bookings.
     */
    public List<Appointment> getByPatientAndDate(int patientId, String yyyyMMdd) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        if (yyyyMMdd == null || !yyyyMMdd.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("Date must be yyyy-MM-dd.");
        }
        List<Object> params = new ArrayList<>();
        params.add(String.valueOf(patientId));
        params.add(yyyyMMdd + "%");
        String where = "a.patient_id=? AND a.appointment_date LIKE ? ";
        if (archiveReady()) {
            where = activeFilter("a") + " AND a.patient_id=? AND a.appointment_date LIKE ? ";
        }
        return scopedList(where, params, " ORDER BY a.appointment_date ASC");
    }

    public boolean update(int id, int patientId, String dateTime, String status, String notes) throws SQLException {
        ensureStaffColumn();
        ensureStatusEnum();
        requireOwnership(id);
        validateSlot(dateTime, id);
        // Duration-aware overlap check for reschedules: reuse the appointment's
        // current treatment-based duration so a long session cannot be moved
        // on top of another booking for the same patient or staff member.
        // Different times on the same day remain allowed when they do not overlap.
        int duration = defaultSlotMinutes();
        Integer ownerForCheck = null;
        try (Connection c = DBConnection.getConnection()) {
            ownerForCheck = findStaffUserId(c, id);
            try {
                int est = estimateDurationForAppointment(c, id, duration);
                if (est > 0) duration = est;
            } catch (SQLException ignored) {}
        } catch (SQLException ignored) {}
        validateSameDayOverlaps(null, patientId, ownerForCheck, dateTime, duration, id);
        String sql = "UPDATE appointments SET patient_id=?, appointment_date=?, status=?, notes=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, patientId);
            ps.setString(2, dateTime); ps.setString(3, status); ps.setString(4, notes);
            ps.setInt(5, id);
            return ps.executeUpdate() == 1;
        }
    }

    /**
     * Status-only change (Pending / Start / Complete / Cancel workflow).
     * Each booking keeps its own independent status - touching one row never
     * modifies any other booking, even for the same patient.
     * Skips slot re-validation: the slot was already validated when booked,
     * and confirming must never fail because of the clock.
     * <p>
     * Booking/treatment coupling: moving a booking to {@code In Progress}
     * starts its sessions - not-started ({@code Pending}) treatments of THIS
     * booking flip to {@code Ongoing}. Other statuses leave treatments alone.
     */
    public boolean updateStatus(int id, String status) throws SQLException {
        boolean known = false;
        for (String s : STATUSES) {
            if (s.equals(status)) { known = true; break; }
        }
        if (!known) throw new IllegalArgumentException("Unknown status: " + status);
        ensureStaffColumn();
        ensureStatusEnum();
        TreatmentController.ensureProgressEnum();
        requireOwnership(id);
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE appointments SET status=? WHERE id=?")) {
            ps.setString(1, status);
            ps.setInt(2, id);
            if (ps.executeUpdate() != 1) return false;
        }
        if ("In Progress".equals(status)) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "UPDATE treatments SET progress='Ongoing' WHERE appointment_id=? "
                         + "AND progress='Pending' AND COALESCE(is_archived,0)=0")) {
                ps.setInt(1, id);
                ps.executeUpdate();
            } catch (SQLException ignored) {}
        }
        return true;
    }

    /**
     * Archives a booking AND cascades to its customer + treatments + payments.
     * <ul>
     *   <li>Booking is archived.</li>
     *   <li>Treatments linked to this booking (appointment_id) are archived.</li>
     *   <li>Payments linked to those treatments are archived too.</li>
     *   <li>If the patient has no other active bookings left, the patient,
     *       their remaining active treatments AND payments are archived too.</li>
     * </ul>
     * All steps run in one transaction.
     */
    public boolean archive(int id) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        requireOwnership(id);
        TreatmentController.archiveReady();
        PatientController.archiveReady();
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int patientId = findPatientId(c, id);
                if (patientId < 0) {
                    c.rollback();
                    return false;
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE appointments SET is_archived=1 WHERE id=?")) {
                    ps.setInt(1, id);
                    if (ps.executeUpdate() != 1) {
                        c.rollback();
                        return false;
                    }
                }
                TreatmentController.archiveByAppointment(c, id);
                PaymentController.archiveByAppointment(c, id);
                if (!hasOtherActiveBookings(c, patientId, id)) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "UPDATE patients SET is_archived=1 WHERE id=?")) {
                        ps.setInt(1, patientId);
                        ps.executeUpdate();
                    } catch (SQLException ignored) {
                        // Old DB without patients.is_archived - treatments still cascade.
                    }
                    TreatmentController.archiveByPatient(c, patientId);
                    PaymentController.archiveByPatient(c, patientId);
                }
                c.commit();
                return true;
            } catch (SQLException ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    /**
     * Restores a booking AND its cascaded customer + treatments + payments.
     * Patient is always restored (a booking needs a visible patient) plus
     * all of that patient's archived treatments and payments.
     */
    public boolean restore(int id) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        requireOwnership(id);
        TreatmentController.archiveReady();
        PatientController.archiveReady();
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int patientId = findPatientId(c, id);
                if (patientId < 0) {
                    c.rollback();
                    return false;
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE appointments SET is_archived=0 WHERE id=?")) {
                    ps.setInt(1, id);
                    if (ps.executeUpdate() != 1) {
                        c.rollback();
                        return false;
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "UPDATE patients SET is_archived=0 WHERE id=?")) {
                    ps.setInt(1, patientId);
                    ps.executeUpdate();
                } catch (SQLException ignored) {
                    // Old DB without patients.is_archived - ignore.
                }
                TreatmentController.restoreByPatient(c, patientId);
                TreatmentController.restoreByAppointment(c, id);
                PaymentController.restoreByPatient(c, patientId);
                PaymentController.restoreByAppointment(c, id);
                c.commit();
                return true;
            } catch (SQLException ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    private int findPatientId(Connection c, int appointmentId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT patient_id FROM appointments WHERE id=?")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : -1;
            }
        }
    }

    private boolean hasOtherActiveBookings(Connection c, int patientId, int excludeId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT 1 FROM appointments WHERE patient_id=? AND id<>? AND COALESCE(is_archived,0)=0 LIMIT 1")) {
            ps.setInt(1, patientId);
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            // Old DB without appointments.is_archived - fall back to plain check.
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT 1 FROM appointments WHERE patient_id=? AND id<>? LIMIT 1")) {
                ps.setInt(1, patientId);
                ps.setInt(2, excludeId);
                try (ResultSet rs = ps.executeQuery()) {
                    return rs.next();
                }
            }
        }
    }

    /**
     * Permanent hard delete of an ARCHIVED booking, including its linked
     * treatments and their payments (one transaction). If the patient has no
     * bookings left afterwards, the orphan patient row plus any leftover
     * standalone treatments/payments are also hard-deleted so nothing lingers
     * in phpMyAdmin. Refuses to delete active (non-archived) bookings -
     * archive them first.
     */
    public boolean delete(int id) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        requireOwnership(id);
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int patientId = -1;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT patient_id, COALESCE(is_archived,0) FROM appointments WHERE id=?")) {
                    ps.setInt(1, id);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) {
                            c.rollback();
                            return false;
                        }
                        if (rs.getInt(2) == 0) {
                            throw new IllegalArgumentException(
                                    "Only archived bookings can be permanently deleted. Archive it first.");
                        }
                        patientId = rs.getInt(1);
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "DELETE FROM payments WHERE treatment_id IN "
                        + "(SELECT id FROM treatments WHERE appointment_id=?)")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                } catch (SQLException ignored) {
                    // Old DB without treatments.appointment_id - fall through.
                }
                try (PreparedStatement ps = c.prepareStatement(
                        "DELETE FROM treatments WHERE appointment_id=?")) {
                    ps.setInt(1, id);
                    ps.executeUpdate();
                } catch (SQLException ignored) {
                    // Old DB without treatments.appointment_id - ignore.
                }
                int removed;
                try (PreparedStatement ps = c.prepareStatement(
                        "DELETE FROM appointments WHERE id=?")) {
                    ps.setInt(1, id);
                    removed = ps.executeUpdate();
                }
                if (removed != 1) {
                    c.rollback();
                    return false;
                }
                // True purge: no bookings left for this patient -> hard-delete
                // the orphan patient plus leftover standalone rows so phpMyAdmin
                // shows nothing (previously the patient was only re-archived).
                // If bookings remain and any are active, make sure the patient
                // is visible in Customers (un-archive).
                if (patientId > 0) {
                    int remaining = -1;
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT COUNT(*) FROM appointments WHERE patient_id=?")) {
                        ps.setInt(1, patientId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) remaining = rs.getInt(1);
                        }
                    }
                    if (remaining == 0) {
                        try (PreparedStatement ps = c.prepareStatement(
                                "DELETE FROM payments WHERE patient_id=?")) {
                            ps.setInt(1, patientId);
                            ps.executeUpdate();
                        } catch (SQLException ignored) {}
                        try (PreparedStatement ps = c.prepareStatement(
                                "DELETE FROM treatments WHERE patient_id=?")) {
                            ps.setInt(1, patientId);
                            ps.executeUpdate();
                        } catch (SQLException ignored) {}
                        try (PreparedStatement ps = c.prepareStatement(
                                "DELETE FROM patients WHERE id=?")) {
                            ps.setInt(1, patientId);
                            ps.executeUpdate();
                        } catch (SQLException ignored) {}
                    } else if (remaining > 0) {
                        try (PreparedStatement ps = c.prepareStatement(
                                "SELECT COUNT(*) FROM appointments WHERE patient_id=? AND COALESCE(is_archived,0)=0")) {
                            ps.setInt(1, patientId);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next() && rs.getInt(1) > 0) {
                                    try (PreparedStatement up = c.prepareStatement(
                                            "UPDATE patients SET is_archived=0 WHERE id=?")) {
                                        up.setInt(1, patientId);
                                        up.executeUpdate();
                                    } catch (SQLException ignored) {}
                                }
                            }
                        } catch (SQLException ignored) {
                            // Old DB without is_archived - nothing to un-archive.
                        }
                    }
                }
                c.commit();
                return true;
            } catch (SQLException | IllegalArgumentException ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    /** Counts active bookings only (staff-scoped). */
    public int count() throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        if (!archiveReady()) {
            if (sid == null) return countAll("appointments");
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT COUNT(*) FROM appointments WHERE staff_user_id=?")) {
                ps.setInt(1, sid);
                try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
            }
        }
        String sql = "SELECT COUNT(*) FROM appointments WHERE COALESCE(is_archived,0)=0";
        if (sid != null) sql += " AND staff_user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (sid != null) ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    public int countArchived() throws SQLException {
        if (!archiveReady()) return 0;
        ensureStaffColumn();
        Integer sid = staffScopeId();
        String sql = "SELECT COUNT(*) FROM appointments WHERE COALESCE(is_archived,0)=1";
        if (sid != null) sql += " AND staff_user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (sid != null) ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    public int countByStatus(String status) throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        String sql = "SELECT COUNT(*) FROM appointments WHERE status=?";
        if (archiveReady()) {
            sql = "SELECT COUNT(*) FROM appointments WHERE COALESCE(is_archived,0)=0 AND status=?";
        }
        if (sid != null) sql += " AND staff_user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            if (sid != null) ps.setInt(2, sid);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }


    private List<Appointment> query(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return attachServiceInfo(mapAll(rs));
        }
    }

    /**
     * Fills Service Type (comma-separated treatment_type) + Amount (SUM cost)
     * for each booking in one batched query. All treatments linked by
     * treatments.appointment_id are included so both active and archived
     * views show their totals. Bookings with no treatments get "-" / 0.00.
     * Failures (e.g. old DB without appointment_id) fall back to defaults
     * so the bookings list never breaks.
     */
    private List<Appointment> attachServiceInfo(List<Appointment> list) {
        if (list == null || list.isEmpty()) return list;
        for (Appointment a : list) {
            if (a.getServiceTypes() == null) a.setServiceTypes("-");
        }
        try (Connection c = DBConnection.getConnection()) {
            StringBuilder ph = new StringBuilder();
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) ph.append(",");
                ph.append("?");
            }
            String sql = "SELECT appointment_id, "
                    + "GROUP_CONCAT(treatment_type SEPARATOR ', ') AS svc, "
                    + "COALESCE(SUM(cost),0) AS amt FROM treatments "
                    + "WHERE appointment_id IN (" + ph + ") GROUP BY appointment_id";
            try (PreparedStatement ps = c.prepareStatement(sql)) {
                for (int i = 0; i < list.size(); i++) ps.setInt(i + 1, list.get(i).getId());
                try (ResultSet rs = ps.executeQuery()) {
                    java.util.Map<Integer, String> svcMap = new java.util.HashMap<>();
                    java.util.Map<Integer, Double> amtMap = new java.util.HashMap<>();
                    while (rs.next()) {
                        int aid = rs.getInt("appointment_id");
                        String svc = rs.getString("svc");
                        double amt = 0;
                        try { amt = rs.getDouble("amt"); } catch (SQLException ignored) {}
                        svcMap.put(aid, svc);
                        amtMap.put(aid, amt);
                    }
                    for (Appointment a : list) {
                        String svc = svcMap.get(a.getId());
                        if (svc != null && !svc.trim().isEmpty()) a.setServiceTypes(svc.trim());
                        else a.setServiceTypes("-");
                        Double amt = amtMap.get(a.getId());
                        a.setTotalAmount(amt == null ? 0 : amt);
                    }
                }
            }
        } catch (Exception ignored) {
            for (Appointment a : list) {
                if (a.getServiceTypes() == null || a.getServiceTypes().trim().isEmpty()) {
                    a.setServiceTypes("-");
                }
            }
        }
        return list;
    }

    /** Result of the unified booking transaction. */
    public static class BookingResult {
        public int patientId;
        public int appointmentId;
        public int treatmentId; // first treatment (kept for backward compat)
        public java.util.List<Integer> treatmentIds = new java.util.ArrayList<>();
        public boolean reusedPatient;
    }

    /**
     * Multi-service booking transaction: same as single-service below but
     * creates ONE treatment row per selected service (all linked to the same
     * appointment_id). No schema change needed - treatments.appointment_id
     * is already one-to-many.
     *
     * @param serviceIds active services.id list (at least 1)
     */
    public BookingResult createFullBooking(Patient newPatient, Integer existingPatientId,
                                           java.util.List<Integer> serviceIds, String dateTime,
                                           String status, String notes) throws Exception {
        return createFullBooking(newPatient, existingPatientId, serviceIds, dateTime, status, notes, false);
    }

    /**
     * Same as above but honors an explicit "create as NEW separate client"
     * choice from the UI. When {@code forceNewPatient} is true (user clicked
     * "No" on the possible-duplicate prompt), the phone-dedupe reuse is
     * skipped and a new patient row is always inserted — allowing two
     * different people to share the same name (even the same phone).
     */
    public BookingResult createFullBooking(Patient newPatient, Integer existingPatientId,
                                           java.util.List<Integer> serviceIds, String dateTime,
                                           String status, String notes,
                                           boolean forceNewPatient) throws Exception {
        if (serviceIds == null || serviceIds.isEmpty()) {
            throw new IllegalArgumentException("Select at least one treatment/service.");
        }
        // De-duplicate while keeping order (user may double-tick).
        java.util.LinkedHashSet<Integer> uniq = new java.util.LinkedHashSet<>(serviceIds);
        java.util.List<Integer> svcIds = new java.util.ArrayList<>(uniq);
        boolean known = false;
        String st = (status == null || status.trim().isEmpty()) ? "Scheduled" : status.trim();
        for (String s : STATUSES) {
            if (s.equals(st)) { known = true; break; }
        }
        if (!known) throw new IllegalArgumentException("Unknown status: " + status);
        ensureStaffColumn();
        ensureStatusEnum();
        TreatmentController.ensureProgressEnum();
        validateSlot(dateTime, -1);

        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                // ---- 1) Resolve patient (reuse existing, no duplicates) ----
                // Additional bookings reuse the same patient row (by id or phone);
                // a new row is inserted for a genuinely new client OR when the
                // user explicitly chose "Create as NEW separate client"
                // (forceNewPatient=true) — same name, even same phone, allowed.
                // Existing bookings are never overwritten and their statuses untouched.
                int patientId;
                boolean reused = false;
                if (existingPatientId != null) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT id, COALESCE(is_archived,0) FROM patients WHERE id=?")) {
                        ps.setInt(1, existingPatientId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) throw new IllegalArgumentException(
                                    "Selected patient no longer exists. Please refresh and try again.");
                            if (rs.getInt(2) == 1) {
                                try (PreparedStatement up = c.prepareStatement(
                                        "UPDATE patients SET is_archived=0 WHERE id=?")) {
                                    up.setInt(1, existingPatientId);
                                    up.executeUpdate();
                                }
                            }
                        }
                    }
                    patientId = existingPatientId;
                    reused = true;
                } else {
                    if (newPatient == null) throw new IllegalArgumentException("Patient information is required.");
                    String nm = newPatient.getFullName() == null ? "" : newPatient.getFullName().trim();
                    String ph = newPatient.getPhone() == null ? "" : newPatient.getPhone().trim();
                    if (nm.isEmpty()) throw new IllegalArgumentException("Patient name cannot be empty.");
                    if (ph.isEmpty()) throw new IllegalArgumentException("Contact number cannot be empty.");
                    Integer dupId = null;
                    boolean dupArchived = false;
                    if (!forceNewPatient) {
                        try (PreparedStatement ps = c.prepareStatement(
                                "SELECT id, COALESCE(is_archived,0) FROM patients WHERE phone=? LIMIT 1")) {
                            ps.setString(1, ph);
                            try (ResultSet rs = ps.executeQuery()) {
                                if (rs.next()) {
                                    dupId = rs.getInt(1);
                                    dupArchived = rs.getInt(2) == 1;
                                }
                            }
                        }
                    }
                    if (dupId != null && !forceNewPatient) {
                        if (dupArchived) {
                            try (PreparedStatement up = c.prepareStatement(
                                    "UPDATE patients SET is_archived=0 WHERE id=?")) {
                                up.setInt(1, dupId);
                                up.executeUpdate();
                            }
                        }
                        patientId = dupId;
                        reused = true;
                    } else {
                        // Same name with different phone is allowed: it may be a
                        // different person (e.g. two "Maria Santos") or the same
                        // person with a new number. Phone is the dedupe key above;
                        // the UI already asks "Use existing / Create new" so the
                        // backend must not hard-block here.
                        String gender = newPatient.getGender();
                        if (!"Male".equals(gender) && !"Female".equals(gender) && !"Other".equals(gender)) {
                            gender = "Male";
                        }
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setString(1, nm);
                            ps.setString(2, gender);
                            ps.setString(3, emptyToNullDate(newPatient.getDob()));
                            ps.setString(4, ph);
                            ps.setString(5, emptyToNull(newPatient.getEmail()));
                            ps.setString(6, emptyToNull(newPatient.getAddress()));
                            ps.setString(7, emptyToNull(newPatient.getEmergencyContact()));
                            ps.setString(8, emptyToNull(newPatient.getMedicalHistory()));
                            if (ps.executeUpdate() != 1) throw new SQLException("Patient insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Patient insert failed (no id).");
                                patientId = keys.getInt(1);
                            }
                        }
                        reused = false;
                    }
                }

                // ---- 2) Load + validate every selected service (must still be Active) ----
                // Multi-booking rule: same patient may book again the same day with
                // different services/times. Each booking keeps its own Booking ID.
                // Overlap (not same-day) is what gets blocked - see step 2b.
                // service_id is stored on treatments.service_id (FK -> services.id).
                TreatmentController.ensureServiceColumn();
                class Svc { int id; String name; String desc; double price; int minutes; }
                java.util.List<Svc> svcs = new java.util.ArrayList<>();
                for (int sid : svcIds) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT name, description, price, duration_minutes, status FROM services WHERE id=?")) {
                        ps.setInt(1, sid);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) throw new IllegalArgumentException(
                                    "Selected treatment/service (ID " + sid + ") no longer exists. Please refresh.");
                            if (!"Active".equals(rs.getString("status"))) throw new IllegalArgumentException(
                                    "Selected service is no longer active. Please pick another.");
                            Svc s = new Svc();
                            s.id = sid;
                            s.name = rs.getString("name");
                            s.desc = rs.getString("description");
                            s.price = rs.getDouble("price");
                            try { s.minutes = rs.getInt("duration_minutes"); }
                            catch (SQLException ignored) { s.minutes = 0; }
                            if (s.minutes <= 0) s.minutes = defaultSlotMinutes();
                            svcs.add(s);
                        }
                    }
                }

                // ---- 2b) Same-day overlap validation (patient + assigned staff) ----
                // Different services/times on the same day are allowed; only
                // overlapping intervals are rejected. Uses summed service
                // durations so back-to-back bookings stay bookable.
                int newDuration = 0;
                for (Svc s : svcs) newDuration += s.minutes;
                if (newDuration <= 0) newDuration = defaultSlotMinutes();
                Integer ownerForCheck = staffScopeId();
                validateSameDayOverlaps(c, patientId, ownerForCheck, dateTime,
                        newDuration, -1);

                // ---- 3) Insert appointment (owner locked to logged-in staff) ----
                int appointmentId;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO appointments (patient_id, staff_user_id, appointment_date, status, notes)"
                        + " VALUES (?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, patientId);
                    Integer owner = staffScopeId();
                    if (owner == null) ps.setNull(2, Types.INTEGER);
                    else ps.setInt(2, owner);
                    ps.setString(3, dateTime);
                    ps.setString(4, st);
                    String n = (notes == null) ? null : notes.trim();
                    ps.setString(5, (n == null || n.isEmpty()) ? null : n);
                    if (ps.executeUpdate() != 1) throw new SQLException("Appointment insert failed.");
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("Appointment insert failed (no id).");
                        appointmentId = keys.getInt(1);
                    }
                }

                // ---- 4) One treatment row per selected service ----
                // New sessions start Pending (not started); they flip to Ongoing
                // when the booking moves to In Progress (see updateStatus).
                java.util.List<Integer> tIds = new java.util.ArrayList<>();
                for (Svc s : svcs) {
                    try {
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO treatments (patient_id, appointment_id, service_id, treatment_type, description,"
                                + " session_count, session_date, progress, cost)"
                                + " VALUES (?, ?, ?, ?, ?, 1, ?, 'Pending', ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setInt(1, patientId);
                            ps.setInt(2, appointmentId);
                            ps.setInt(3, s.id);
                            ps.setString(4, s.name);
                            ps.setString(5, (s.desc == null || s.desc.trim().isEmpty()) ? null : s.desc.trim());
                            ps.setString(6, dateTime);
                            ps.setDouble(7, s.price);
                            if (ps.executeUpdate() != 1) throw new SQLException("Treatment insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Treatment insert failed (no id).");
                                tIds.add(keys.getInt(1));
                            }
                        }
                    } catch (SQLException e) {
                        // Old DB without service_id: legacy insert (type/cost copy only).
                        if (e.getMessage() == null || !e.getMessage().toLowerCase().contains("service_id")) throw e;
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO treatments (patient_id, appointment_id, treatment_type, description,"
                                + " session_count, session_date, progress, cost)"
                                + " VALUES (?, ?, ?, ?, 1, ?, 'Pending', ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setInt(1, patientId);
                            ps.setInt(2, appointmentId);
                            ps.setString(3, s.name);
                            ps.setString(4, (s.desc == null || s.desc.trim().isEmpty()) ? null : s.desc.trim());
                            ps.setString(5, dateTime);
                            ps.setDouble(6, s.price);
                            if (ps.executeUpdate() != 1) throw new SQLException("Treatment insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Treatment insert failed (no id).");
                                tIds.add(keys.getInt(1));
                            }
                        }
                    }
                }

                c.commit();
                BookingResult r = new BookingResult();
                r.patientId = patientId;
                r.appointmentId = appointmentId;
                r.treatmentIds = tIds;
                r.treatmentId = tIds.isEmpty() ? 0 : tIds.get(0);
                r.reusedPatient = reused;
                return r;
            } catch (Exception ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    /**
     * Unified booking transaction: resolve patient (reuse by id or phone,
     * else insert), insert appointment, auto-create linked treatment from
     * the selected service catalogue row. All steps use prepared statements
     * on ONE connection; any failure rolls everything back.
     *
     * <p>Note on schema: {@code appointments} has NO treatment_id column.
     * The link is {@code treatments.appointment_id -> appointments.id},
     * so this method creates the treatment row pointing at the new
     * appointment and returns its id (no invented columns).
     *
     * @param newPatient        patient data when booking a NEW patient (null if existing selected)
     * @param existingPatientId id when an existing patient is picked (null for new)
     * @param serviceId         active services.id to base the treatment on
     * @param dateTime          "yyyy-MM-dd HH:mm"
     * @param status            one of STATUSES
     * @param notes             optional (may be null/empty)
     */
    public BookingResult createFullBooking(Patient newPatient, Integer existingPatientId,
                                           int serviceId, String dateTime,
                                           String status, String notes) throws Exception {
        return createFullBooking(newPatient, existingPatientId,
                java.util.Collections.singletonList(serviceId), dateTime, status, notes);
    }

    /**
     * Lists active treatment names already linked to one booking.
     * Used by the "Add Service" dialog to hide/disable duplicates.
     */
    public java.util.List<String> listTreatmentTypes(int appointmentId) throws SQLException {
        ensureStaffColumn();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT treatment_type FROM treatments WHERE appointment_id=? AND COALESCE(is_archived,0)=0 ORDER BY id")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                java.util.List<String> out = new java.util.ArrayList<>();
                while (rs.next()) {
                    String t = rs.getString(1);
                    if (t != null && !t.trim().isEmpty()) out.add(t.trim());
                }
                return out;
            }
        } catch (SQLException e) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT treatment_type FROM treatments WHERE appointment_id=? ORDER BY id")) {
                ps.setInt(1, appointmentId);
                try (ResultSet rs = ps.executeQuery()) {
                    java.util.List<String> out = new java.util.ArrayList<>();
                    while (rs.next()) {
                        String t = rs.getString(1);
                        if (t != null && !t.trim().isEmpty()) out.add(t.trim());
                    }
                    return out;
                }
            }
        }
    }

    /**
     * Adds one or more additional services to an EXISTING booking.
     * <ul>
     *   <li>Creates one new {@code treatments} row per service, all pointing at
     *       the same {@code appointment_id} - the booking keeps its Booking ID
     *       and independent status (never modified here).</li>
     *   <li>Blocked when the booking is archived/Cancelled/Completed - create
     *       an additional booking instead.</li>
     *   <li>Rejects services already linked to this booking (pick a different
     *       service or create an additional booking).</li>
     *   <li>Re-validates the extended duration against same-patient and
     *       same-staff overlaps, plus existing operating-hours rules.</li>
     * </ul>
     *
     * @param appointmentId existing booking id
     * @param serviceIds    active services.id list (at least 1)
     * @return generated treatment ids
     */
    public java.util.List<Integer> addServicesToBooking(int appointmentId,
                                                        java.util.List<Integer> serviceIds) throws Exception {
        if (serviceIds == null || serviceIds.isEmpty()) {
            throw new IllegalArgumentException("Select at least one service to add.");
        }
        java.util.LinkedHashSet<Integer> uniq = new java.util.LinkedHashSet<>(serviceIds);
        java.util.List<Integer> svcIds = new java.util.ArrayList<>(uniq);
        ensureStaffColumn();
        ensureStatusEnum();
        requireOwnership(appointmentId);
        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                int patientId;
                String apptDateTime;
                String apptStatus;
                Integer apptStaff;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT patient_id, appointment_date, status, staff_user_id, COALESCE(is_archived,0) FROM appointments WHERE id=?")) {
                    ps.setInt(1, appointmentId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new IllegalArgumentException(
                                "Booking no longer exists. Please refresh.");
                        if (rs.getInt(5) == 1) throw new IllegalArgumentException(
                                "Cannot add services to an archived booking. Restore it first.");
                        patientId = rs.getInt(1);
                        String raw = rs.getString(2);
                        apptDateTime = (raw == null || raw.length() < 16) ? "" : raw.substring(0, 16);
                        apptStatus = rs.getString(3);
                        int su = rs.getInt(4);
                        apptStaff = rs.wasNull() ? null : su;
                    }
                }
                if ("Cancelled".equals(apptStatus) || "Completed".equals(apptStatus)) {
                    throw new IllegalArgumentException(
                            "Cannot add services to a " + apptStatus + " booking. "
                            + "Create an additional booking instead - each keeps its own Booking ID.");
                }
                java.util.List<String> existing = new java.util.ArrayList<>();
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT treatment_type FROM treatments WHERE appointment_id=? AND COALESCE(is_archived,0)=0")) {
                    ps.setInt(1, appointmentId);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String t = rs.getString(1);
                            if (t != null && !t.trim().isEmpty()) existing.add(t.trim());
                        }
                    }
                } catch (SQLException e) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT treatment_type FROM treatments WHERE appointment_id=?")) {
                        ps.setInt(1, appointmentId);
                        try (ResultSet rs = ps.executeQuery()) {
                            while (rs.next()) {
                                String t = rs.getString(1);
                                if (t != null && !t.trim().isEmpty()) existing.add(t.trim());
                            }
                        }
                    }
                }
                java.util.Set<String> existingLower = new java.util.HashSet<>();
                for (String t : existing) existingLower.add(t.toLowerCase());
                TreatmentController.ensureServiceColumn();
                class Svc2 { int id; String name; String desc; double price; int minutes; }
                java.util.List<Svc2> svcs = new java.util.ArrayList<>();
                for (int sid : svcIds) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT name, description, price, duration_minutes, status FROM services WHERE id=?")) {
                        ps.setInt(1, sid);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) throw new IllegalArgumentException(
                                    "Selected service (ID " + sid + ") no longer exists. Please refresh.");
                            if (!"Active".equals(rs.getString("status"))) throw new IllegalArgumentException(
                                    "Selected service is no longer active. Please pick another.");
                            String nm = rs.getString("name");
                            if (nm != null && existingLower.contains(nm.trim().toLowerCase())) {
                                throw new IllegalArgumentException(
                                        "Service \"" + nm.trim() + "\" is already linked to Booking #"
                                        + appointmentId + ". Pick a different service, or create an "
                                        + "additional booking for a separate time.");
                            }
                            Svc2 s = new Svc2();
                            s.id = sid;
                            s.name = rs.getString("name");
                            s.desc = rs.getString("description");
                            s.price = rs.getDouble("price");
                            try { s.minutes = rs.getInt("duration_minutes"); }
                            catch (SQLException ignored) { s.minutes = 0; }
                            if (s.minutes <= 0) s.minutes = defaultSlotMinutes();
                            svcs.add(s);
                        }
                    }
                }
                int oldTotal = 0;
                for (String t : existing) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT duration_minutes FROM services WHERE name=? LIMIT 1")) {
                        ps.setString(1, t);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next() && rs.getInt(1) > 0) oldTotal += rs.getInt(1);
                        }
                    } catch (SQLException ignored) {}
                }
                if (oldTotal <= 0) oldTotal = defaultSlotMinutes();
                int addTotal = 0;
                for (Svc2 s : svcs) addTotal += s.minutes;
                int newTotal = oldTotal + addTotal;
                validateSameDayOverlaps(c, patientId, apptStaff, apptDateTime, newTotal, appointmentId);
                // Added sessions follow the booking: Ongoing when already running,
                // otherwise Pending (not started).
                String addProgress = "In Progress".equals(apptStatus) ? "Ongoing" : "Pending";
                java.util.List<Integer> tIds = new java.util.ArrayList<>();
                for (Svc2 s : svcs) {
                    try {
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO treatments (patient_id, appointment_id, service_id, treatment_type, description,"
                                + " session_count, session_date, progress, cost)"
                                + " VALUES (?, ?, ?, ?, ?, 1, ?, ?, ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setInt(1, patientId);
                            ps.setInt(2, appointmentId);
                            ps.setInt(3, s.id);
                            ps.setString(4, s.name);
                            ps.setString(5, (s.desc == null || s.desc.trim().isEmpty()) ? null : s.desc.trim());
                            ps.setString(6, apptDateTime);
                            ps.setString(7, addProgress);
                            ps.setDouble(8, s.price);
                            if (ps.executeUpdate() != 1) throw new SQLException("Treatment insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Treatment insert failed (no id).");
                                tIds.add(keys.getInt(1));
                            }
                        }
                    } catch (SQLException e) {
                        if (e.getMessage() == null || !e.getMessage().toLowerCase().contains("service_id")) throw e;
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO treatments (patient_id, appointment_id, treatment_type, description,"
                                + " session_count, session_date, progress, cost)"
                                + " VALUES (?, ?, ?, ?, 1, ?, ?, ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setInt(1, patientId);
                            ps.setInt(2, appointmentId);
                            ps.setString(3, s.name);
                            ps.setString(4, (s.desc == null || s.desc.trim().isEmpty()) ? null : s.desc.trim());
                            ps.setString(5, apptDateTime);
                            ps.setString(6, addProgress);
                            ps.setDouble(7, s.price);
                            if (ps.executeUpdate() != 1) throw new SQLException("Treatment insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Treatment insert failed (no id).");
                                tIds.add(keys.getInt(1));
                            }
                        }
                    }
                }
                c.commit();
                return tIds;
            } catch (Exception ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }

    /* LEGACY single-service impl moved to multi-service overload above - kept for reference:
        boolean known = false;
        String st = (status == null || status.trim().isEmpty()) ? "Scheduled" : status.trim();
        for (String s : STATUSES) {
            if (s.equals(st)) { known = true; break; }
        }
        if (!known) throw new IllegalArgumentException("Unknown status: " + status);
        // Format + operating-hours + slot-conflict check (throws IllegalArgumentException).
        validateSlot(dateTime, -1);

        try (Connection c = DBConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                // ---- 1) Resolve patient ----
                int patientId;
                boolean reused = false;
                if (existingPatientId != null) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT id, COALESCE(is_archived,0) FROM patients WHERE id=?")) {
                        ps.setInt(1, existingPatientId);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) throw new IllegalArgumentException(
                                    "Selected patient no longer exists. Please refresh and try again.");
                            if (rs.getInt(2) == 1) {
                                try (PreparedStatement up = c.prepareStatement(
                                        "UPDATE patients SET is_archived=0 WHERE id=?")) {
                                    up.setInt(1, existingPatientId);
                                    up.executeUpdate();
                                }
                            }
                        }
                    }
                    patientId = existingPatientId;
                    reused = true;
                } else {
                    if (newPatient == null) throw new IllegalArgumentException("Patient information is required.");
                    String nm = newPatient.getFullName() == null ? "" : newPatient.getFullName().trim();
                    String ph = newPatient.getPhone() == null ? "" : newPatient.getPhone().trim();
                    if (nm.isEmpty()) throw new IllegalArgumentException("Patient name cannot be empty.");
                    if (ph.isEmpty()) throw new IllegalArgumentException("Contact number cannot be empty.");
                    // Duplicate prevention: exact phone match (phone is indexed).
                    Integer dupId = null;
                    boolean dupArchived = false;
                    try (PreparedStatement ps = c.prepareStatement(
                            "SELECT id, COALESCE(is_archived,0) FROM patients WHERE phone=? LIMIT 1")) {
                        ps.setString(1, ph);
                        try (ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                dupId = rs.getInt(1);
                                dupArchived = rs.getInt(2) == 1;
                            }
                        }
                    }
                    if (dupId != null) {
                        if (dupArchived) {
                            try (PreparedStatement up = c.prepareStatement(
                                    "UPDATE patients SET is_archived=0 WHERE id=?")) {
                                up.setInt(1, dupId);
                                up.executeUpdate();
                            }
                        }
                        patientId = dupId;
                        reused = true;
                    } else {
                        String gender = newPatient.getGender();
                        if (!"Male".equals(gender) && !"Female".equals(gender) && !"Other".equals(gender)) {
                            gender = "Male";
                        }
                        try (PreparedStatement ps = c.prepareStatement(
                                "INSERT INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history)"
                                + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                Statement.RETURN_GENERATED_KEYS)) {
                            ps.setString(1, nm);
                            ps.setString(2, gender);
                            ps.setString(3, emptyToNullDate(newPatient.getDob()));
                            ps.setString(4, ph);
                            ps.setString(5, emptyToNull(newPatient.getEmail()));
                            ps.setString(6, emptyToNull(newPatient.getAddress()));
                            ps.setString(7, emptyToNull(newPatient.getEmergencyContact()));
                            ps.setString(8, emptyToNull(newPatient.getMedicalHistory()));
                            if (ps.executeUpdate() != 1) throw new SQLException("Patient insert failed.");
                            try (ResultSet keys = ps.getGeneratedKeys()) {
                                if (!keys.next()) throw new SQLException("Patient insert failed (no id).");
                                patientId = keys.getInt(1);
                            }
                        }
                        reused = false;
                    }
                }

                // ---- 2) Load service (must still be active) ----
                String svcName;
                String svcDesc;
                double svcPrice;
                try (PreparedStatement ps = c.prepareStatement(
                        "SELECT name, description, price, status FROM services WHERE id=?")) {
                    ps.setInt(1, serviceId);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new IllegalArgumentException(
                                "Selected treatment/service no longer exists. Please refresh.");
                        if (!"Active".equals(rs.getString("status"))) throw new IllegalArgumentException(
                                "Selected service is no longer active. Please pick another.");
                        svcName = rs.getString("name");
                        svcDesc = rs.getString("description");
                        svcPrice = rs.getDouble("price");
                    }
                }

                // ---- 3) Insert appointment ----
                int appointmentId;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO appointments (patient_id, appointment_date, status, notes)"
                        + " VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, patientId);
                    ps.setString(2, dateTime);
                    ps.setString(3, st);
                    String n = (notes == null) ? null : notes.trim();
                    ps.setString(4, (n == null || n.isEmpty()) ? null : n);
                    if (ps.executeUpdate() != 1) throw new SQLException("Appointment insert failed.");
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("Appointment insert failed (no id).");
                        appointmentId = keys.getInt(1);
                    }
                }

                // ---- 4) Auto-create linked treatment (no duplicate services: one row per booking) ----
                int treatmentId;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO treatments (patient_id, appointment_id, treatment_type, description,"
                        + " session_count, session_date, progress, cost)"
                        + " VALUES (?, ?, ?, ?, 1, ?, 'Ongoing', ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, patientId);
                    ps.setInt(2, appointmentId);
                    ps.setString(3, svcName);
                    ps.setString(4, (svcDesc == null || svcDesc.trim().isEmpty()) ? null : svcDesc.trim());
                    ps.setString(5, dateTime);
                    ps.setDouble(6, svcPrice);
                    if (ps.executeUpdate() != 1) throw new SQLException("Treatment insert failed.");
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("Treatment insert failed (no id).");
                        treatmentId = keys.getInt(1);
                    }
                }

                c.commit();
                BookingResult r = new BookingResult();
                r.patientId = patientId;
                r.appointmentId = appointmentId;
                r.treatmentId = treatmentId;
                r.reusedPatient = reused;
                return r;
            } catch (Exception ex) {
                try { c.rollback(); } catch (SQLException ignored) {}
                throw ex;
            } finally {
                try { c.setAutoCommit(true); } catch (SQLException ignored) {}
            }
        }
    }
    */

    private static String emptyToNull(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }

    private static String emptyToNullDate(String s) {
        if (s == null || s.trim().isEmpty()) return null;
        String t = s.trim();
        if (!t.matches("\\d{4}-\\d{2}-\\d{2}")) throw new IllegalArgumentException(
                "Date of birth must be yyyy-MM-dd or empty.");
        return t;
    }

    /**
     * Base slot validation: format + operating hours only. The old
     * clinic-wide "one booking per exact timestamp" rule was removed on
     * request - different patients may share the same day AND the same time
     * (multi-service / parallel sessions). Same-patient conflicts are still
     * blocked by {@link #validateSameDayOverlaps}.
     */
    private void validateSlot(String dateTime, int excludeId) throws SQLException {
        if (dateTime == null || !dateTime.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
            throw new IllegalArgumentException("Date must be yyyy-MM-dd HH:mm.");
        }
        String time = dateTime.substring(11, 16);
        SettingsController settings = new SettingsController();
        String open = settings.openTime();
        String close = settings.closeTime();
        if (time.compareTo(open) < 0 || time.compareTo(close) > 0) {
            throw new IllegalArgumentException(
                    "Outside operating hours (" + open + " - " + close + ").");
        }
    }

    /**
     * Default appointment length in minutes (settings.slot_minutes, else 60).
     * Reuses the existing duration/availability configuration.
     */
    private static int defaultSlotMinutes() {
        try {
            String v = new SettingsController().get("slot_minutes", "60");
            int m = Integer.parseInt(v.trim());
            if (m > 0 && m <= 720) return m;
        } catch (Exception ignored) {}
        return 60;
    }

    /** staff_user_id currently stored for one appointment (null = unassigned/legacy). */
    private static Integer findStaffUserId(Connection c, int appointmentId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT staff_user_id FROM appointments WHERE id=?")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                int v = rs.getInt(1);
                return rs.wasNull() ? null : v;
            }
        } catch (SQLException e) {
            return null; // old DB without staff_user_id
        }
    }

    /**
     * Estimates how long an existing appointment lasts by summing the
     * durations of the catalogue services its treatments were built from
     * (matched by treatment_type = services.name). Falls back to
     * {@code fallbackMinutes} when no match is found.
     */
    private static int estimateDurationForAppointment(Connection c, int appointmentId,
                                                      int fallbackMinutes) throws SQLException {
        int total = 0;
        java.util.List<String> types = new java.util.ArrayList<>();
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT treatment_type FROM treatments WHERE appointment_id=? AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, appointmentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String t = rs.getString(1);
                    if (t != null && !t.trim().isEmpty()) types.add(t.trim());
                }
            }
        } catch (SQLException e) {
            // Old DB without treatments.is_archived - retry without the filter.
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT treatment_type FROM treatments WHERE appointment_id=?")) {
                ps.setInt(1, appointmentId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        String t = rs.getString(1);
                        if (t != null && !t.trim().isEmpty()) types.add(t.trim());
                    }
                }
            }
        }
        for (String t : types) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT duration_minutes FROM services WHERE name=? LIMIT 1")) {
                ps.setString(1, t);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int d = rs.getInt(1);
                        if (d > 0) total += d;
                    }
                }
            } catch (SQLException ignored) {}
        }
        if (total > 0) return total;
        return fallbackMinutes > 0 ? fallbackMinutes : defaultSlotMinutes();
    }

    /**
     * Multiple-bookings-per-day validation (overlap-aware).
     * <ul>
     *   <li>Same patient may book several times on the same day - only
     *       overlapping intervals are rejected, never the mere fact that a
     *       booking already exists that day. Different patients may always
     *       book the same day at different times.</li>
     *   <li>No interval check on staff: {@code staff_user_id} records which
     *       account created the booking (there is no therapist role - only
     *       Staff and Administrator), so one login routinely books the whole
     *       day. Blocking overlapping times per creator would wrongly make a
     *       day "taken" after the first booking.</li>
     *   <li>Different patients may share the exact same timestamp - only the
     *       SAME patient is conflict-checked. Same-patient overlaps (including
     *       the identical slot) are still rejected.</li>
     *   <li>Applies existing duration rules (summed service minutes) and
     *       availability rules (operating-hours end + Blocked schedules).</li>
     * </ul>
     *
     * @param c             open connection to reuse (may be null = open a new one)
     * @param patientId     booking patient
     * @param staffUserId   booking creator (used only for Blocked-schedule scope)
     * @param dateTime      "yyyy-MM-dd HH:mm" of the new/updated booking
     * @param newDurationMinutes length of the new booking in minutes
     * @param excludeId     appointment id to ignore (-1 for new bookings)
     */
    private void validateSameDayOverlaps(Connection c, int patientId, Integer staffUserId,
                                         String dateTime, int newDurationMinutes,
                                         int excludeId) throws SQLException {
        if (dateTime == null || !dateTime.matches("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}")) {
            throw new IllegalArgumentException("Date must be yyyy-MM-dd HH:mm.");
        }
        int newDuration = newDurationMinutes > 0 ? newDurationMinutes : defaultSlotMinutes();
        java.time.LocalDateTime newStart;
        try {
            newStart = java.time.LocalDateTime.parse(dateTime,
                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        } catch (Exception e) {
            throw new IllegalArgumentException("Date must be yyyy-MM-dd HH:mm.");
        }
        java.time.LocalDateTime newEnd = newStart.plusMinutes(newDuration);

        // Availability: appointment must finish within operating hours.
        try {
            SettingsController sc = new SettingsController();
            String close = sc.closeTime();
            String endHm = newEnd.format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
            // Allow ending exactly at close; only strictly-after is blocked.
            if (endHm.compareTo(close) > 0) {
                throw new IllegalArgumentException(
                        "Appointment would end at " + endHm + ", after closing (" + close + "). "
                        + "Multiple bookings per day are allowed - please pick an earlier time or shorter service.");
            }
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception ignored) {}

        boolean ownConnection = (c == null);
        Connection conn = c;
        try {
            if (ownConnection) conn = DBConnection.getConnection();
            final Connection cc = conn;

            // Availability: Blocked schedules (clinic-wide or per-staff) overlap check.
            try {
                String day = dateTime.substring(0, 10);
                try (PreparedStatement ps = cc.prepareStatement(
                        "SELECT start_time, end_time, staff_user_id FROM schedules "
                        + "WHERE sched_date=? AND status='Blocked'")) {
                    ps.setString(1, day);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            String sStart = rs.getString(1);
                            String sEnd = rs.getString(2);
                            int su = rs.getInt(3);
                            Integer blockedStaff = rs.wasNull() ? null : su;
                            if (sStart == null || sEnd == null) continue;
                            if (sStart.length() > 5) sStart = sStart.substring(0, 5);
                            if (sEnd.length() > 5) sEnd = sEnd.substring(0, 5);
                            boolean applies = (blockedStaff == null)
                                    || (staffUserId != null && blockedStaff.equals(staffUserId));
                            if (!applies) continue;
                            java.time.LocalTime bS;
                            java.time.LocalTime bE;
                            try {
                                bS = java.time.LocalTime.parse(sStart);
                                bE = java.time.LocalTime.parse(sEnd);
                            } catch (Exception ignored2) { continue; }
                            java.time.LocalTime nS = newStart.toLocalTime();
                            java.time.LocalTime nE = newEnd.toLocalTime();
                            if (nS.isBefore(bE) && bS.isBefore(nE)) {
                                throw new IllegalArgumentException(
                                        "Selected time conflicts with a blocked schedule ("
                                        + sStart + "-" + sEnd + " on " + day + "). "
                                        + "Please choose another slot.");
                            }
                        }
                    }
                }
            } catch (IllegalArgumentException e) {
                throw e;
            } catch (SQLException ignored) {
                // Old DB without schedules / status values - availability check skipped.
            }

            // Load same-day active bookings (excluding Cancelled + archived + self).
            // Only the SAME patient is overlap-checked: different patients may
            // freely share the day, and staff overlap is not checked because
            // staff_user_id is the booking creator, not a therapist.
            String dayPrefix = dateTime.substring(0, 10) + "%";
            String sql = "SELECT id, patient_id, appointment_date FROM appointments "
                    + "WHERE appointment_date LIKE ? AND status<>'Cancelled' AND id<>?";
            if (archiveReady()) {
                sql = "SELECT id, patient_id, appointment_date FROM appointments "
                    + "WHERE appointment_date LIKE ? AND status<>'Cancelled' "
                    + "AND COALESCE(is_archived,0)=0 AND id<>?";
            }
            try (PreparedStatement ps = cc.prepareStatement(sql)) {
                ps.setString(1, dayPrefix);
                ps.setInt(2, excludeId);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        int otherId = rs.getInt("id");
                        int otherPatient = rs.getInt("patient_id");
                        String raw = rs.getString("appointment_date");
                        String otherDt = (raw == null || raw.length() < 16) ? "" : raw.substring(0, 16);
                        java.time.LocalDateTime otherStart;
                        try {
                            otherStart = java.time.LocalDateTime.parse(otherDt,
                                    java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
                        } catch (Exception ignored2) { continue; }
                        int otherDuration = defaultSlotMinutes();
                        try {
                            otherDuration = estimateDurationForAppointment(cc, otherId, otherDuration);
                        } catch (SQLException ignored2) {}
                        java.time.LocalDateTime otherEnd = otherStart.plusMinutes(otherDuration);
                        boolean overlaps = newStart.isBefore(otherEnd) && otherStart.isBefore(newEnd);
                        if (!overlaps) continue;
                        if (otherPatient == patientId) {
                            throw new IllegalArgumentException(
                                    "This patient already has an overlapping appointment "
                                    + "(Booking ID " + otherId + " at " + otherDt + "). "
                                    + "Multiple bookings per day are allowed - please choose a non-overlapping time.");
                        }
                    }
                }
            }
        } finally {
            if (ownConnection && conn != null) {
                try { conn.close(); } catch (SQLException ignored) {}
            }
        }
    }
    private List<Appointment> mapAll(ResultSet rs) throws SQLException {
        List<Appointment> list = new ArrayList<>();
        while (rs.next()) {
            Appointment a = new Appointment();
            a.setId(rs.getInt("id"));
            a.setPatientId(rs.getInt("patient_id"));
            try {
                int su = rs.getInt("staff_user_id");
                a.setStaffUserId(rs.wasNull() ? null : su);
            } catch (SQLException ignored) {
                a.setStaffUserId(null);
            }
            try {
                a.setStaffName(rs.getString("sname"));
            } catch (SQLException ignored) {
                a.setStaffName(null);
            }
            a.setPatientName(rs.getString("pname"));
            // Read as raw string (yyyy-MM-dd HH:mm:ss): getTimestamp() would
            // shift the hour when JVM and MySQL timezones differ.
            String raw = rs.getString("appointment_date");
            a.setAppointmentDate(raw == null || raw.length() < 16 ? "" : raw.substring(0, 16));
            a.setStatus(rs.getString("status"));
            a.setNotes(rs.getString("notes") == null ? "" : rs.getString("notes"));
            try {
                a.setArchived(rs.getInt("is_archived") == 1);
            } catch (SQLException ignored) {
                a.setArchived(false);
            }
            // Service Type + Amount are filled by attachServiceInfo(); defaults
            // keep the table stable if the treatments lookup fails.
            a.setServiceTypes("-");
            a.setTotalAmount(0);
            list.add(a);
        }
        return list;
    }
}
