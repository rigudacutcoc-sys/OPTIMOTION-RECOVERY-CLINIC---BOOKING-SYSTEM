package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Service;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceController extends BaseController implements Manageable<Service> {

    public boolean create(Service s) throws SQLException {
        Session.requireAdmin();
        String sql = "INSERT INTO services (name, description, price, duration_minutes, status)"
                   + " VALUES (?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, s);
            return ps.executeUpdate() == 1;
        }
    }

    public List<Service> getAll() throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM services ORDER BY id DESC");
             ResultSet rs = ps.executeQuery()) {
            List<Service> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        }
    }

    /** Only active services (for dropdowns in Treatment form). */
    public List<Service> getActive() throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT * FROM services WHERE status='Active' ORDER BY name")) {
            try (ResultSet rs = ps.executeQuery()) {
                List<Service> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        }
    }

    public List<Service> search(String keyword) throws SQLException {
        String sql = "SELECT * FROM services WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k);
            try (ResultSet rs = ps.executeQuery()) {
                List<Service> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        }
    }

    public boolean update(Service s) throws SQLException {
        Session.requireAdmin();
        String sql = "UPDATE services SET name=?, description=?, price=?, duration_minutes=?, status=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, s);
            ps.setInt(6, s.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(int id) throws SQLException {
        Session.requireAdmin();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM services WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    public int count() throws SQLException {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM services")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public double averagePrice() throws SQLException {
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COALESCE(AVG(price),0) FROM services WHERE status='Active'")) {
            return rs.next() ? rs.getDouble(1) : 0;
        }
    }

    private void bind(PreparedStatement ps, Service s) throws SQLException {
        ps.setString(1, s.getName());
        ps.setString(2, emptyToNull(s.getDescription()));
        ps.setDouble(3, s.getPrice());
        ps.setInt(4, s.getDurationMinutes());
        ps.setString(5, s.getStatus());
    }

    private Service map(ResultSet rs) throws SQLException {
        Service s = new Service();
        s.setId(rs.getInt("id"));
        s.setName(rs.getString("name"));
        s.setDescription(nullToEmpty(rs.getString("description")));
        s.setPrice(rs.getDouble("price"));
        s.setDurationMinutes(rs.getInt("duration_minutes"));
        s.setStatus(rs.getString("status"));
        return s;
    }

    private String emptyToNull(String s) { return (s == null || s.trim().isEmpty()) ? null : s.trim(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }
}
