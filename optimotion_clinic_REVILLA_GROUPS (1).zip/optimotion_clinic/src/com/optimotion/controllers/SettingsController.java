package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.LinkedHashMap;
import java.util.Map;


public class SettingsController {

    private static volatile boolean colsChecked = false;

    /**
     * Best-effort migration: connects SETTINGS -> USERS.
     * Adds settings.updated_by INT NULL + FK to users(id) + updated_at.
     * Nullable so old rows keep working (NULL = seeded/default).
     */
    public static synchronized void ensureSettingsColumns() {
        if (colsChecked) return;
        colsChecked = true;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {
            boolean hasUpdatedBy = false;
            boolean hasUpdatedAt = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "settings", "updated_by")) {
                if (rs.next()) hasUpdatedBy = true;
            } catch (SQLException ignored) {}
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "settings", "updated_at")) {
                if (rs.next()) hasUpdatedAt = true;
            } catch (SQLException ignored) {}
            if (!hasUpdatedBy) {
                try { st.executeUpdate("ALTER TABLE settings ADD COLUMN updated_by INT NULL"); }
                catch (SQLException ignored) { colsChecked = false; return; }
            }
            if (!hasUpdatedAt) {
                try { st.executeUpdate("ALTER TABLE settings ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"); }
                catch (SQLException ignored) {}
            }
            try { st.executeUpdate("ALTER TABLE settings ADD INDEX idx_settings_user (updated_by)"); }
            catch (SQLException ignored) {}
            try {
                st.executeUpdate("ALTER TABLE settings ADD CONSTRAINT fk_settings_user "
                        + "FOREIGN KEY (updated_by) REFERENCES users(id) "
                        + "ON DELETE SET NULL ON UPDATE CASCADE");
            } catch (SQLException ignored) {}
        } catch (SQLException ignored) {
            colsChecked = false;
        }
    }

    public String get(String key, String def) throws SQLException {
        ensureSettingsColumns();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT svalue FROM settings WHERE skey=?")) {
            ps.setString(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : def;
            }
        }
    }

    public Map<String, String> getAll() throws SQLException {
        ensureSettingsColumns();
        Map<String, String> map = new LinkedHashMap<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT skey, svalue FROM settings ORDER BY skey");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) map.put(rs.getString(1), rs.getString(2));
        }
        return map;
    }

    /** Administrators only. Records which user last saved the setting. */
    public void save(String key, String value) throws SQLException {
        Session.requireAdmin();
        if (key == null || key.trim().isEmpty()) {
            throw new IllegalArgumentException("Setting key is required.");
        }
        ensureSettingsColumns();
        Integer updater = (Session.current() == null) ? null : Session.current().getId();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "INSERT INTO settings (skey, svalue, updated_by) VALUES (?, ?, ?)"
                   + " ON DUPLICATE KEY UPDATE svalue=VALUES(svalue), updated_by=VALUES(updated_by)")) {
            ps.setString(1, key.trim());
            ps.setString(2, value == null ? "" : value.trim());
            if (updater == null) ps.setNull(3, java.sql.Types.INTEGER);
            else ps.setInt(3, updater);
            ps.executeUpdate();
        } catch (SQLException e) {
            // Old DB without updated_by: legacy save (key/value only).
            if (e.getMessage() == null || !e.getMessage().toLowerCase().contains("updated_by")) throw e;
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "INSERT INTO settings (skey, svalue) VALUES (?, ?)"
                       + " ON DUPLICATE KEY UPDATE svalue=VALUES(svalue)")) {
                ps.setString(1, key.trim());
                ps.setString(2, value == null ? "" : value.trim());
                ps.executeUpdate();
            }
        }
    }

    public String openTime() {
        try { return get("open_time", "08:00"); }
        catch (SQLException e) { return "08:00"; }
    }

    public String closeTime() {
        try { return get("close_time", "17:00"); }
        catch (SQLException e) { return "17:00"; }
    }
}
