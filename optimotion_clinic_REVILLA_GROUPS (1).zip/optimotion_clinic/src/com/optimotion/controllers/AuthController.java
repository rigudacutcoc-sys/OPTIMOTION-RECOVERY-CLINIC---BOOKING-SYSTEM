package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.User;
import com.optimotion.utils.PasswordUtil;
import java.sql.*;


public class AuthController {

    /**
     * Public self-registration. Always creates an ACTIVE STAFF account.
     * Returns true on success, false if username taken.
     */
    public boolean register(String username, String plainPassword, String fullName) throws SQLException {
        String check = "SELECT id FROM users WHERE username = ?";
        String insert = "INSERT INTO users (username, password_hash, full_name, role, is_active)"
                      + " VALUES (?, ?, ?, 'staff', 1)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(check)) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return false; // username exists
            }
            try (PreparedStatement ins = c.prepareStatement(insert)) {
                ins.setString(1, username.trim());
                ins.setString(2, PasswordUtil.hash(plainPassword));
                ins.setString(3, fullName.trim());
                return ins.executeUpdate() == 1;
            }
        }
    }

    /**
     * Returns the User on valid credentials, else null.
     * Throws SecurityException when the account exists but is deactivated.
     */
    public User login(String username, String plainPassword) throws SQLException {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String stored = rs.getString("password_hash");
                    if (PasswordUtil.verify(plainPassword, stored)) {
                        boolean active = readActive(rs);
                        if (!active) {
                            throw new SecurityException(
                                    "This account has been deactivated. Contact an administrator.");
                        }
                        User u = new User(rs.getInt("id"), rs.getString("username"),
                                stored, rs.getString("full_name"),
                                rs.getString("role").toLowerCase());
                        u.setActive(true);
                        return u;
                    }
                }
            }
        }
        return null;
    }

    /** Reads is_active tolerantly (column may not exist on very old databases). */
    private boolean readActive(ResultSet rs) {
        try {
            return rs.getBoolean("is_active");
        } catch (SQLException e) {
            return true;
        }
    }
}
