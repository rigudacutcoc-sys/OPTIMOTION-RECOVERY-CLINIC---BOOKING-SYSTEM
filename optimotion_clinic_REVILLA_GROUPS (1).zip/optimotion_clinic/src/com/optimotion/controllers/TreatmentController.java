package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Treatment;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * TreatmentController - assign treatments & track recovery sessions.
 * Active-only lists (archived rows hidden). Archiving is driven by
 * booking cascade - no manual archive button in the Treatments panel.
 */
public class TreatmentController extends BaseController implements Manageable<Treatment> {

    private static final String BASE =
        "SELECT tr.*, p.full_name AS pname FROM treatments tr "
      + "JOIN patients p ON tr.patient_id = p.id ";

    private static volatile boolean archiveColChecked = false;

    /** Best-effort migration: adds treatments.is_archived if missing (old DBs). */
    private static synchronized void ensureArchiveColumn() {
        if (archiveColChecked) return;
        archiveColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "treatments", "is_archived")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "TREATMENTS", "IS_ARCHIVED")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE treatments ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0");
                } catch (SQLException ignored) {
                    archiveColChecked = false;
                }
            }
        } catch (SQLException ignored) {
            archiveColChecked = false;
        }
    }

    static boolean archiveReady() {
        ensureArchiveColumn();
        return archiveColChecked;
    }

    private static volatile boolean serviceColChecked = false;

    /**
     * Best-effort migration: connects SERVICES -> TREATMENTS.
     * Adds treatments.service_id INT NULL + FK to services(id).
     * Nullable so legacy/custom-typed rows keep working (NULL = custom).
     * Safe to call repeatedly; failures are ignored.
     */
    public static synchronized void ensureServiceColumn() {
        if (serviceColChecked) return;
        serviceColChecked = true;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "treatments", "service_id")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "TREATMENTS", "SERVICE_ID")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try {
                    st.executeUpdate("ALTER TABLE treatments ADD COLUMN service_id INT NULL");
                } catch (SQLException ignored) {
                    serviceColChecked = false;
                    return;
                }
            }
            // FK + index (best effort: may already exist on fresh DBs).
            try { st.executeUpdate("ALTER TABLE treatments ADD INDEX idx_treat_service (service_id)"); }
            catch (SQLException ignored) {}
            try {
                st.executeUpdate("ALTER TABLE treatments ADD CONSTRAINT fk_treat_service "
                        + "FOREIGN KEY (service_id) REFERENCES services(id) "
                        + "ON DELETE SET NULL ON UPDATE CASCADE");
            } catch (SQLException ignored) {}
        } catch (SQLException ignored) {
            serviceColChecked = false;
        }
    }

    private static volatile boolean progressEnumChecked = false;

    /**
     * Best-effort migration for the booking/treatment status coupling: widens
     * treatments.progress ENUM with 'Pending' (not started) and one-time
     * backfills Ongoing rows of still Pending/Scheduled bookings to Pending,
     * so old data follows the same rule as new bookings. Safe to call
     * repeatedly; failures are ignored.
     */
    static synchronized void ensureProgressEnum() {
        if (progressEnumChecked) return;
        progressEnumChecked = true;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement()) {
            try {
                st.executeUpdate("ALTER TABLE treatments MODIFY COLUMN progress "
                        + "ENUM('Pending','Ongoing','Improved','Recovered','No Change') "
                        + "NOT NULL DEFAULT 'Pending'");
            } catch (SQLException ignored) {}
            try {
                st.executeUpdate("UPDATE treatments SET progress='Pending' WHERE progress='Ongoing' "
                        + "AND COALESCE(is_archived,0)=0 AND appointment_id IN "
                        + "(SELECT id FROM appointments WHERE status IN ('Pending','Scheduled'))");
            } catch (SQLException ignored) {}
        } catch (SQLException ignored) {}
    }

    /** Staff see only treatments of their own bookings (via appointment owner). Admin sees all. */
    private static Integer staffScopeId() {
        try {
            if (Session.current() != null && Session.current().isAdmin()) return null;
            if (Session.current() != null) return Session.current().getId();
        } catch (Exception ignored) {}
        return null;
    }

    private static String ownerJoin() {
        return "LEFT JOIN appointments a ON tr.appointment_id = a.id ";
    }

    private static String ownerClause(List<Object> params) {
        Integer sid = staffScopeId();
        if (sid == null) return "";
        params.add(sid);
        return " AND a.staff_user_id=? ";
    }

    public boolean create(Treatment t) throws SQLException {
        ensureArchiveColumn();
        ensureProgressEnum();
        ensureServiceColumn();
        String sql = "INSERT INTO treatments (patient_id, appointment_id, service_id, treatment_type, description, session_count, session_date, progress, cost)"
                   + " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, t);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            // Old DB without service_id column: fall back to legacy insert.
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("service_id")) {
                String legacy = "INSERT INTO treatments (patient_id, appointment_id, treatment_type, description, session_count, session_date, progress, cost)"
                        + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (Connection c = DBConnection.getConnection();
                     PreparedStatement ps = c.prepareStatement(legacy)) {
                    bindLegacy(ps, t);
                    return ps.executeUpdate() == 1;
                }
            }
            throw e;
        }
    }

    /** Active treatments only (staff-scoped to own bookings). */
    public List<Treatment> getAll() throws SQLException {
        Integer sid = staffScopeId();
        if (!archiveReady()) {
            if (sid == null) return query(BASE + "ORDER BY tr.id DESC");
            String sql = BASE + ownerJoin() + "ORDER BY tr.id DESC";
            // No archive column: still scope by owner.
            sql = BASE + ownerJoin() + "WHERE 1=1 AND a.staff_user_id=? ORDER BY tr.id DESC";
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, sid);
                try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
            }
        }
        if (sid == null) return query(BASE + "WHERE COALESCE(tr.is_archived,0)=0 ORDER BY tr.id DESC");
        String sql = BASE + ownerJoin()
                + "WHERE COALESCE(tr.is_archived,0)=0 AND a.staff_user_id=? ORDER BY tr.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    /** Archived treatments only (used by booking cascade / debugging). */
    public List<Treatment> getArchived() throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        return query(BASE + "WHERE COALESCE(tr.is_archived,0)=1 ORDER BY tr.id DESC");
    }

    /**
     * Unscoped list for the shared Schedule calendar (all active treatments).
     * TreatmentPanel stays staff-scoped via getAll().
     */
    public List<Treatment> getAllUnscoped() throws SQLException {
        if (!archiveReady()) {
            return query(BASE + "ORDER BY tr.id DESC");
        }
        return query(BASE + "WHERE COALESCE(tr.is_archived,0)=0 ORDER BY tr.id DESC");
    }

    public List<Treatment> search(String keyword) throws SQLException {
        Integer sid = staffScopeId();
        String k = "%" + keyword.trim() + "%";
        String where = "WHERE p.full_name LIKE ? OR treatment_type LIKE ? OR progress LIKE ?";
        if (archiveReady()) {
            where = "WHERE COALESCE(tr.is_archived,0)=0 AND (p.full_name LIKE ? OR treatment_type LIKE ? OR progress LIKE ?)";
        }
        String join = (sid == null) ? "" : ownerJoin();
        if (sid != null) where += " AND a.staff_user_id=?";
        String sql = BASE + join + where + " ORDER BY tr.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            if (sid != null) ps.setInt(4, sid);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    /** Archived-only keyword search (used by the admin Archive view). */
    public List<Treatment> searchArchived(String keyword) throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        String sql = BASE + "WHERE COALESCE(tr.is_archived,0)=1 AND "
                + "(p.full_name LIKE ? OR treatment_type LIKE ? OR progress LIKE ?) ORDER BY tr.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    public boolean update(Treatment t) throws SQLException {
        ensureProgressEnum();
        ensureServiceColumn();
        Integer sid = staffScopeId();
        if (sid != null && t.getAppointmentId() != null) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT staff_user_id FROM appointments WHERE id=?")) {
                ps.setInt(1, t.getAppointmentId());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int owner = rs.getInt(1);
                        if (!rs.wasNull() && owner != sid) throw new SecurityException(
                                "Access denied: this treatment belongs to another staff member.");
                        if (rs.wasNull()) throw new SecurityException(
                                "Access denied: this treatment belongs to another staff member.");
                    }
                }
            } catch (SecurityException e) {
                throw e;
            } catch (SQLException e) {
                // Old DB without appointments.staff_user_id: allow (column missing).
            }
        }
        String sql = "UPDATE treatments SET patient_id=?, appointment_id=?, service_id=?, treatment_type=?, description=?, session_count=?, session_date=?, progress=?, cost=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, t);
            ps.setInt(10, t.getId());
            if (ps.executeUpdate() != 1) return false;
        } catch (SQLException e) {
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("service_id")) {
                String legacy = "UPDATE treatments SET patient_id=?, appointment_id=?, treatment_type=?, description=?, session_count=?, session_date=?, progress=?, cost=? WHERE id=?";
                try (Connection c = DBConnection.getConnection();
                     PreparedStatement ps = c.prepareStatement(legacy)) {
                    bindLegacy(ps, t);
                    ps.setInt(9, t.getId());
                    if (ps.executeUpdate() != 1) return false;
                }
            } else {
                throw e;
            }
        }
        // Treatment -> booking coupling: when the last unfinished session of a
        // booking is marked finished, the booking itself becomes Completed.
        // Cancelled bookings are never touched, and reopening a treatment does
        // not auto-reopen the booking (staff handle that in Bookings).
        if (t.getAppointmentId() != null && isFinishedProgress(t.getProgress())) {
            autoCompleteBooking(t.getAppointmentId());
        }
        return true;
    }

    private static boolean isFinishedProgress(String progress) {
        if (progress == null) return false;
        String v = progress.trim();
        return "Recovered".equalsIgnoreCase(v)
                || "Completed".equalsIgnoreCase(v)
                || "Finished".equalsIgnoreCase(v);
    }

    /** Sets the booking Completed when none of its active sessions is unfinished. */
    private static void autoCompleteBooking(int appointmentId) {
        try (Connection c = DBConnection.getConnection()) {
            try (PreparedStatement ps = c.prepareStatement(
                    "SELECT COUNT(*) FROM treatments WHERE appointment_id=? "
                    + "AND COALESCE(is_archived,0)=0 AND progress NOT IN ('Recovered','Completed','Finished')")) {
                ps.setInt(1, appointmentId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) return; // still work left
                }
            } catch (SQLException ignored) {
                return;
            }
            try (PreparedStatement ps = c.prepareStatement(
                    "UPDATE appointments SET status='Completed' WHERE id=? "
                    + "AND status NOT IN ('Completed','Cancelled')")) {
                ps.setInt(1, appointmentId);
                ps.executeUpdate();
            } catch (SQLException ignored) {}
        } catch (SQLException ignored) {}
    }

    public boolean delete(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM treatments WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    /** Archive all treatments linked to a booking (appointment_id). Returns rows affected. */
    static int archiveByAppointment(Connection c, int appointmentId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE treatments SET is_archived=1 WHERE appointment_id=? AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, appointmentId);
            return ps.executeUpdate();
        }
    }

    /** Restore all treatments linked to a booking. Returns rows affected. */
    static int restoreByAppointment(Connection c, int appointmentId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE treatments SET is_archived=0 WHERE appointment_id=? AND COALESCE(is_archived,0)=1")) {
            ps.setInt(1, appointmentId);
            return ps.executeUpdate();
        }
    }

    /** Archive all active treatments of a patient. Returns rows affected. */
    static int archiveByPatient(Connection c, int patientId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE treatments SET is_archived=1 WHERE patient_id=? AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, patientId);
            return ps.executeUpdate();
        }
    }

    /** Restore all archived treatments of a patient. Returns rows affected. */
    static int restoreByPatient(Connection c, int patientId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE treatments SET is_archived=0 WHERE patient_id=? AND COALESCE(is_archived,0)=1")) {
            ps.setInt(1, patientId);
            return ps.executeUpdate();
        }
    }

    public int count() throws SQLException {
        if (!archiveReady()) {
            return countAll("treatments");
        }
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM treatments WHERE COALESCE(is_archived,0)=0")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private List<Treatment> query(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return mapAll(rs);
        }
    }

    private void bind(PreparedStatement ps, Treatment t) throws SQLException {
        ps.setInt(1, t.getPatientId());
        if (t.getAppointmentId() == null) ps.setNull(2, Types.INTEGER);
        else ps.setInt(2, t.getAppointmentId());
        if (t.getServiceId() == null) ps.setNull(3, Types.INTEGER);
        else ps.setInt(3, t.getServiceId());
        ps.setString(4, t.getTreatmentType());
        ps.setString(5, t.getDescription());
        ps.setInt(6, t.getSessionCount());
        ps.setString(7, t.getSessionDate());
        ps.setString(8, t.getProgress());
        ps.setDouble(9, t.getCost());
    }

    /** Legacy 8-param bind for DBs without service_id (pre-migration fallback). */
    private void bindLegacy(PreparedStatement ps, Treatment t) throws SQLException {
        ps.setInt(1, t.getPatientId());
        if (t.getAppointmentId() == null) ps.setNull(2, Types.INTEGER);
        else ps.setInt(2, t.getAppointmentId());
        ps.setString(3, t.getTreatmentType());
        ps.setString(4, t.getDescription());
        ps.setInt(5, t.getSessionCount());
        ps.setString(6, t.getSessionDate());
        ps.setString(7, t.getProgress());
        ps.setDouble(8, t.getCost());
    }

    private List<Treatment> mapAll(ResultSet rs) throws SQLException {
        List<Treatment> list = new ArrayList<>();
        while (rs.next()) {
            Treatment t = new Treatment();
            t.setId(rs.getInt("id"));
            t.setPatientId(rs.getInt("patient_id"));
            int ap = rs.getInt("appointment_id");
            t.setAppointmentId(rs.wasNull() ? null : ap);
            try {
                int sv = rs.getInt("service_id");
                t.setServiceId(rs.wasNull() ? null : sv);
            } catch (SQLException ignored) {
                t.setServiceId(null);
            }
            t.setPatientName(rs.getString("pname"));
            t.setTreatmentType(rs.getString("treatment_type"));
            t.setDescription(rs.getString("description") == null ? "" : rs.getString("description"));
            t.setSessionCount(rs.getInt("session_count"));
            // Read as raw string to preserve time: "yyyy-MM-dd HH:mm:ss" or "yyyy-MM-dd".
            // Keeps backward compat with old DATE rows.
            String raw = rs.getString("session_date");
            if (raw == null) t.setSessionDate("");
            else if (raw.length() >= 16) t.setSessionDate(raw.substring(0, 16));
            else if (raw.length() >= 10) t.setSessionDate(raw.substring(0, 10));
            else t.setSessionDate(raw);
            t.setProgress(rs.getString("progress"));
            t.setCost(rs.getDouble("cost"));
            try {
                t.setArchived(rs.getInt("is_archived") == 1);
            } catch (SQLException ignored) {
                t.setArchived(false);
            }
            list.add(t);
        }
        return list;
    }
}
