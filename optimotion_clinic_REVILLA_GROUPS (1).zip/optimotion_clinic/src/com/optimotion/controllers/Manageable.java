package com.optimotion.controllers;

import java.sql.SQLException;
import java.util.List;

/**
 * OOP - ABSTRACTION: contract every manageable module must honor.
 * <p>
 * Declares WHAT each module can do (list / search / delete / count)
 * without exposing HOW it talks to the database. UI code programs
 * against this interface, so any controller can be substituted
 * (see polymorphism in DashboardPanel / ReportPanel).
 *
 * @param <T> the model type managed (Patient, Service, Payment, ...)
 */
public interface Manageable<T> {

    /** All records, newest first. */
    List<T> getAll() throws SQLException;

    /** Records matching a keyword. */
    List<T> search(String keyword) throws SQLException;

    /** Deletes one record by id. Returns true when a row was removed. */
    boolean delete(int id) throws SQLException;

    /** Total row count (used by dashboard cards and reports). */
    int count() throws SQLException;
}
