package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * OOP - INHERITANCE: common database plumbing for all controllers.
 * <p>
 * Every controller extends this class instead of duplicating connection
 * and counting code. Subclasses inherit {@link #connection()} and
 * {@link #countAll(String)} and add their own SQL for their own table.
 */
public abstract class BaseController {

    /** A fresh JDBC connection (caller closes it via try-with-resources). */
    protected Connection connection() throws SQLException {
        return DBConnection.getConnection();
    }

    /**
     * Shared row-count query. The table name always comes from code
     * constants inside subclasses, never from user input.
     */
    protected int countAll(String table) throws SQLException {
        try (Connection c = connection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
