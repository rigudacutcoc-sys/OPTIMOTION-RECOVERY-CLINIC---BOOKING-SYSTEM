package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.SalesRecord;
import com.optimotion.models.User;
import com.optimotion.utils.Session;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * SalesReportController - Administrator Sales Report data source.
 *
 * <p>Sales grain = one row per PAYMENT with status='Paid' (real money in).
 * Cancelled/Pending/Partial appointments and Pending payments are excluded
 * by the WHERE clause - no separate sales table needed.
 *
 * <p>Staff assignment comes from the additive nullable column
 * {@code payments.staff_user_id} (see PaymentController.ensureStaffColumn).
 * Old rows without assignment appear as "Unassigned" and are included
 * under "All Staff".
 */
public class SalesReportController extends BaseController {

    private static final String SALES_BASE =
        "SELECT pay.id AS sid, COALESCE(tr.treatment_type, '-') AS svc, "
      + "p.full_name AS patient, pay.staff_user_id AS staff_id, "
      + "COALESCE(u.full_name, 'Unassigned') AS staff, pay.amount AS total "
      + "FROM payments pay "
      + "JOIN patients p ON pay.patient_id = p.id "
      + "LEFT JOIN treatments tr ON pay.treatment_id = tr.id "
      + "LEFT JOIN users u ON pay.staff_user_id = u.id "
      + "WHERE pay.status='Paid' AND COALESCE(pay.is_archived,0)=0 ";

    /** Staff options for the "Filter by Staff" dropdown (login required so Staff can also record). */
    public List<User> getStaffList() throws SQLException {
        Session.requireLogin();
        PaymentController.ensureStaffColumn();
        String sql = "SELECT id, username, full_name, role FROM users "
                   + "WHERE role='staff' AND is_active=1 ORDER BY full_name";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<User> list = new ArrayList<>();
            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setUsername(rs.getString("username"));
                u.setFullName(rs.getString("full_name"));
                u.setRole(rs.getString("role"));
                u.setActive(true);
                list.add(u);
            }
            return list;
        }
    }

    /**
     * @param staffId null = All Staff, -1 = Unassigned only, else that staff's id.
     * Staff callers are always scoped to their own id (cannot view others).
     */
    public List<SalesRecord> getSales(Integer staffId) throws SQLException {
        Session.requireLogin();
        PaymentController.ensureStaffColumn();
        // Security: staff can only ever see their own sales, regardless of
        // what filter id a crafted caller passes in.
        if (Session.isStaff()) {
            staffId = Session.current().getId();
        }
        String sql = SALES_BASE;
        boolean byStaff = staffId != null && staffId >= 0;
        boolean unassignedOnly = staffId != null && staffId == -1;
        if (byStaff) sql += "AND pay.staff_user_id=? ";
        else if (unassignedOnly) sql += "AND pay.staff_user_id IS NULL ";
        sql += "ORDER BY pay.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (byStaff) ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) {
                List<SalesRecord> list = new ArrayList<>();
                while (rs.next()) {
                    SalesRecord r = new SalesRecord();
                    r.setId(rs.getInt("sid"));
                    r.setService(rs.getString("svc"));
                    r.setPatient(rs.getString("patient"));
                    int sid = rs.getInt("staff_id");
                    r.setStaffUserId(rs.wasNull() ? null : sid);
                    r.setStaffName(rs.getString("staff"));
                    r.setTotal(rs.getDouble("total"));
                    list.add(r);
                }
                return list;
            }
        }
    }
}
