package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.User;
import com.optimotion.utils.PasswordUtil;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * UserController - Staff Management (ADMINISTRATORS ONLY).
 * <p>
 * Every method except the self-service ones calls
 * {@code Session.requireAdmin()} FIRST, so a Staff user cannot perform
 * these database operations even by opening forms directly. There are only
 * two roles ('staff' | 'administrator') - therapist accounts are rejected.
 */
public class UserController {

    // ================= Admin-only operations =================

    public List<User> getAll() throws SQLException {
        Session.requireAdmin();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users ORDER BY id");
             ResultSet rs = ps.executeQuery()) {
            return mapAll(rs);
        }
    }

    public List<User> search(String keyword) throws SQLException {
        Session.requireAdmin();
        String sql = "SELECT * FROM users WHERE username LIKE ? OR full_name LIKE ? OR role LIKE ? ORDER BY id";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    /** Admin creates a staff/administrator account. Returns false if username taken. */
    public boolean createUser(String username, String plainPassword, String fullName, String role) throws SQLException {
        Session.requireAdmin();
        String r = role == null ? "" : role.trim().toLowerCase();
        if (!Session.isValidRole(r)) {
            throw new IllegalArgumentException("Role must be 'staff' or 'administrator'.");
        }
        if (username == null || username.trim().length() < 4) {
            throw new IllegalArgumentException("Username must be at least 4 characters.");
        }
        if (plainPassword == null || plainPassword.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement chk = c.prepareStatement("SELECT id FROM users WHERE username = ?")) {
            chk.setString(1, username.trim());
            try (ResultSet rs = chk.executeQuery()) {
                if (rs.next()) return false;
            }
            try (PreparedStatement ins = c.prepareStatement(
                    "INSERT INTO users (username, password_hash, full_name, role, is_active)"
                  + " VALUES (?, ?, ?, ?, 1)")) {
                ins.setString(1, username.trim());
                ins.setString(2, PasswordUtil.hash(plainPassword));
                ins.setString(3, fullName.trim());
                ins.setString(4, r);
                return ins.executeUpdate() == 1;
            }
        }
    }

    /** Admin edits another user's display name. */
    public boolean updateUserInfo(int id, String fullName) throws SQLException {
        Session.requireAdmin();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET full_name=? WHERE id=?")) {
            ps.setString(1, fullName.trim());
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        }
    }

    /**
     * Admin activates/deactivates an account. Cannot deactivate yourself or
     * the last active administrator (prevents locking everyone out).
     */
    public boolean setActive(int id, boolean active) throws SQLException {
        Session.requireAdmin();
        if (Session.current() != null && Session.current().getId() == id && !active) {
            throw new SecurityException("You cannot deactivate your own account.");
        }
        if (!active && isLastActiveAdmin(id)) {
            throw new SecurityException("Cannot deactivate the last active administrator.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET is_active=? WHERE id=?")) {
            ps.setBoolean(1, active);
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        }
    }

    /**
     * Admin changes a user's role. Cannot change your own role and cannot
     * demote the last active administrator.
     */
    public boolean changeRole(int id, String role) throws SQLException {
        Session.requireAdmin();
        String r = role == null ? "" : role.trim().toLowerCase();
        if (!Session.isValidRole(r)) {
            throw new IllegalArgumentException("Role must be 'staff' or 'administrator'.");
        }
        if (Session.current() != null && Session.current().getId() == id) {
            throw new SecurityException("You cannot change your own role.");
        }
        User target = getByIdInternal(id);
        if (target == null) return false;
        if (target.isAdmin() && !Session.ROLE_ADMIN.equals(r) && isLastActiveAdmin(id)) {
            throw new SecurityException("Cannot demote the last active administrator.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET role=? WHERE id=?")) {
            ps.setString(1, r);
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        }
    }

    /** Admin resets another user's password (min 6 chars). */
    public boolean resetPassword(int id, String newPassword) throws SQLException {
        Session.requireAdmin();
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("Password must be at least 6 characters.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET password_hash=? WHERE id=?")) {
            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setInt(2, id);
            return ps.executeUpdate() == 1;
        }
    }

    /** Admin deletes an account. Cannot delete yourself. */
    public boolean deleteUser(int id) throws SQLException {
        Session.requireAdmin();
        if (Session.current() != null && Session.current().getId() == id) {
            throw new SecurityException("You cannot delete your own account.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM users WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    public int countStaff() throws SQLException {
        Session.requireAdmin();
        return countByRole("staff");
    }

    public int countAdmins() throws SQLException {
        Session.requireAdmin();
        return countByRole("administrator");
    }

    // ================= Self-service (any logged-in user) =================

    /** Update your own display name. */
    public boolean updateOwnProfile(String fullName) throws SQLException {
        Session.requireLogin();
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new IllegalArgumentException("Full name is required.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET full_name=? WHERE id=?")) {
            ps.setString(1, fullName.trim());
            ps.setInt(2, Session.current().getId());
            boolean ok = ps.executeUpdate() == 1;
            if (ok) Session.current().setFullName(fullName.trim());
            return ok;
        }
    }

    /** Change your own password after verifying the current one. */
    public boolean changeOwnPassword(String currentPassword, String newPassword) throws SQLException {
        Session.requireLogin();
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("New password must be at least 6 characters.");
        }
        User me = Session.current();
        if (!PasswordUtil.verify(currentPassword, me.getPasswordHash())) {
            throw new SecurityException("Current password is incorrect.");
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE users SET password_hash=? WHERE id=?")) {
            String hash = PasswordUtil.hash(newPassword);
            ps.setString(1, hash);
            ps.setInt(2, me.getId());
            boolean ok = ps.executeUpdate() == 1;
            if (ok) me.setPasswordHash(hash);
            return ok;
        }
    }

    // ================= Helpers =================

    private int countByRole(String role) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM users WHERE role=?")) {
            ps.setString(1, role);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    private boolean isLastActiveAdmin(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT COUNT(*) FROM users WHERE role='administrator' AND is_active=1 AND id<>?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) == 0;
            }
        }
    }

    private User getByIdInternal(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT * FROM users WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    private List<User> mapAll(ResultSet rs) throws SQLException {
        List<User> list = new ArrayList<>();
        while (rs.next()) list.add(map(rs));
        return list;
    }

    private User map(ResultSet rs) throws SQLException {
        User u = new User(rs.getInt("id"), rs.getString("username"),
                rs.getString("password_hash"), rs.getString("full_name"),
                rs.getString("role"));
        try {
            u.setActive(rs.getBoolean("is_active"));
        } catch (SQLException ignored) {
            u.setActive(true);
        }
        return u;
    }
}
