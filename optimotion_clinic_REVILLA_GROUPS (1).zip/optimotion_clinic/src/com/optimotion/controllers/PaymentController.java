package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Payment;
import com.optimotion.utils.Session;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/** PaymentController - record & manage patient payments. */
public class PaymentController extends BaseController implements Manageable<Payment> {

    private static final String BASE =
        "SELECT pay.*, p.full_name AS pname, u.full_name AS sname FROM payments pay "
      + "JOIN patients p ON pay.patient_id = p.id "
      + "LEFT JOIN users u ON pay.staff_user_id = u.id ";

    private static volatile boolean archiveColChecked = false;
    private static volatile boolean staffColChecked = false;

    /** Best-effort migration: adds payments.is_archived if missing (old DBs). */
    private static synchronized void ensureArchiveColumn() {
        if (archiveColChecked) return;
        archiveColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "payments", "is_archived")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "PAYMENTS", "IS_ARCHIVED")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE payments ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0");
                } catch (SQLException ignored) {
                    archiveColChecked = false;
                }
            }
        } catch (SQLException ignored) {
            archiveColChecked = false;
        }
    }

    static boolean archiveReady() {
        ensureArchiveColumn();
        return archiveColChecked;
    }

    /** Staff see only their own payments (SQL-filtered). Admin sees all. */
    private static Integer staffScopeId() {
        try {
            if (Session.current() != null && Session.current().isAdmin()) return null;
            if (Session.current() != null) return Session.current().getId();
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * Best-effort migration for the Sales Report feature:
     * adds payments.staff_user_id (nullable FK to users) if missing.
     * Old databases keep working - existing rows read as "Unassigned".
     */
    static synchronized void ensureStaffColumn() {
        if (staffColChecked) return;
        staffColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "payments", "staff_user_id")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "PAYMENTS", "STAFF_USER_ID")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE payments ADD COLUMN staff_user_id INT NULL");
                } catch (SQLException ignored) {
                    staffColChecked = false;
                    return;
                }
                // FK + index (best effort - report works even without them).
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE payments ADD CONSTRAINT fk_pay_staff "
                            + "FOREIGN KEY (staff_user_id) REFERENCES users(id) "
                            + "ON DELETE SET NULL ON UPDATE CASCADE");
                } catch (SQLException ignored) {}
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("CREATE INDEX idx_pay_staff ON payments (staff_user_id)");
                } catch (SQLException ignored) {}
            }
        } catch (SQLException ignored) {
            staffColChecked = false;
        }
    }

    /** Archive payments linked to one treatment (booking cascade). */
    static int archiveByTreatment(Connection c, int treatmentId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE payments SET is_archived=1 WHERE treatment_id=? AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, treatmentId);
            return ps.executeUpdate();
        }
    }

    /** Archive payments linked to a booking's treatments (booking cascade). */
    static int archiveByAppointment(Connection c, int appointmentId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE payments SET is_archived=1 WHERE treatment_id IN "
                + "(SELECT id FROM treatments WHERE appointment_id=?) AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, appointmentId);
            return ps.executeUpdate();
        }
    }

    /** Restore payments linked to a booking's treatments. */
    static int restoreByAppointment(Connection c, int appointmentId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE payments SET is_archived=0 WHERE treatment_id IN "
                + "(SELECT id FROM treatments WHERE appointment_id=?) AND COALESCE(is_archived,0)=1")) {
            ps.setInt(1, appointmentId);
            return ps.executeUpdate();
        }
    }

    /** Archive all active payments of a patient. */
    static int archiveByPatient(Connection c, int patientId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE payments SET is_archived=1 WHERE patient_id=? AND COALESCE(is_archived,0)=0")) {
            ps.setInt(1, patientId);
            return ps.executeUpdate();
        }
    }

    /** Restore all archived payments of a patient. */
    static int restoreByPatient(Connection c, int patientId) throws SQLException {
        ensureArchiveColumn();
        try (PreparedStatement ps = c.prepareStatement(
                "UPDATE payments SET is_archived=0 WHERE patient_id=? AND COALESCE(is_archived,0)=1")) {
            ps.setInt(1, patientId);
            return ps.executeUpdate();
        }
    }

    /** Shown when the linked therapy session is not yet completed. */
    public static final String THERAPY_ONGOING_MSG =
            "Payment cannot be processed because the therapy session is still ongoing. "
            + "Please complete the therapy session before making a payment.";

    /**
     * Payment gate: the linked therapy session must be completed before a
     * payment row may be inserted. Judges the treatment row itself - only a
     * finished progress ({@code Recovered}, shown as Completed) passes.
     * Anything else - Ongoing, Scheduled, Cancelled, or any other
     * non-completed state - throws {@link IllegalArgumentException} and the
     * payment is never saved. Deliberately ignores the parent booking status:
     * staff complete the treatments first and may only confirm the booking
     * afterwards, so a finished therapy must stay payable.
     * A null treatment link means there is no session to check, so it passes.
     */
    public static void requireTherapyCompleted(Integer treatmentId) throws SQLException {
        if (treatmentId == null) return;
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     "SELECT progress FROM treatments WHERE id=?")) {
            ps.setInt(1, treatmentId);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new IllegalArgumentException(
                        "Selected therapy session no longer exists. Refresh and try again.");
                if (!isTreatmentCompleted(rs.getString(1))) {
                    throw new IllegalArgumentException(THERAPY_ONGOING_MSG);
                }
            }
        }
    }

    /** Same gate for every ticked treatment (the form totals several rows). */
    public static void requireTherapiesCompleted(java.util.List<Integer> treatmentIds) throws SQLException {
        if (treatmentIds == null) return;
        for (Integer id : treatmentIds) requireTherapyCompleted(id);
    }

    /** Only a finished treatment counts as completed (DB stores Recovered). */
    private static boolean isTreatmentCompleted(String progress) {
        if (progress == null) return false;
        String t = progress.trim();
        return "Recovered".equalsIgnoreCase(t)
                || "Completed".equalsIgnoreCase(t)
                || "Finished".equalsIgnoreCase(t);
    }

    public boolean create(Payment p) throws SQLException {
        ensureArchiveColumn();
        ensureStaffColumn();
        requireTherapyCompleted(p.getTreatmentId());
        String sql = "INSERT INTO payments (patient_id, treatment_id, staff_user_id, amount, payment_date, method, status) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            return ps.executeUpdate() == 1;
        }
    }

    /** Active payments only (staff-scoped to own). */
    public List<Payment> getAll() throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        if (!archiveReady()) {
            if (sid == null) {
                try (Connection c = DBConnection.getConnection();
                     PreparedStatement ps = c.prepareStatement(BASE + "ORDER BY pay.id DESC");
                     ResultSet rs = ps.executeQuery()) {
                    return mapAll(rs);
                }
            }
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         BASE + "WHERE pay.staff_user_id=? ORDER BY pay.id DESC")) {
                ps.setInt(1, sid);
                try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
            }
        }
        String sql = BASE + "WHERE COALESCE(pay.is_archived,0)=0";
        if (sid != null) sql += " AND pay.staff_user_id=?";
        sql += " ORDER BY pay.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (sid != null) ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    /** Archived payments only. */
    public List<Payment> getArchived() throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(
                     BASE + "WHERE COALESCE(pay.is_archived,0)=1 ORDER BY pay.id DESC");
             ResultSet rs = ps.executeQuery()) {
            return mapAll(rs);
        }
    }

    public List<Payment> search(String keyword) throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        String where = "WHERE p.full_name LIKE ? OR pay.method LIKE ? OR pay.status LIKE ?";
        if (archiveReady()) {
            where = "WHERE COALESCE(pay.is_archived,0)=0 AND (p.full_name LIKE ? OR pay.method LIKE ? OR pay.status LIKE ?)";
        }
        if (sid != null) where += " AND pay.staff_user_id=?";
        String sql = BASE + where + " ORDER BY pay.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            if (sid != null) ps.setInt(4, sid);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    public List<Payment> searchArchived(String keyword) throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        String sql = BASE + "WHERE COALESCE(pay.is_archived,0)=1 AND "
                + "(p.full_name LIKE ? OR pay.method LIKE ? OR pay.status LIKE ?) ORDER BY pay.id DESC";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k);
            try (ResultSet rs = ps.executeQuery()) { return mapAll(rs); }
        }
    }

    public boolean update(Payment p) throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        if (sid != null) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT staff_user_id FROM payments WHERE id=?")) {
                ps.setInt(1, p.getId());
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int owner = rs.getInt(1);
                        if (rs.wasNull() || owner != sid) throw new SecurityException(
                                "Access denied: this payment belongs to another staff member.");
                    }
                }
            } catch (SecurityException e) {
                throw e;
            } catch (SQLException e) {
                // Old DB without staff_user_id: allow.
            }
            // Keep owner locked to the editor (prevents stealing via forged objects).
            p.setStaffUserId(sid);
        }
        requireTherapyCompleted(p.getTreatmentId());
        String sql = "UPDATE payments SET patient_id=?, treatment_id=?, staff_user_id=?, amount=?, payment_date=?, method=?, status=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            ps.setInt(8, p.getId());
            return ps.executeUpdate() == 1;
        }
    }

    public boolean delete(int id) throws SQLException {
        Integer sid = staffScopeId();
        if (sid != null) {
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT staff_user_id FROM payments WHERE id=?")) {
                ps.setInt(1, id);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        int owner = rs.getInt(1);
                        if (rs.wasNull() || owner != sid) throw new SecurityException(
                                "Access denied: this payment belongs to another staff member.");
                    }
                }
            } catch (SecurityException e) {
                throw e;
            } catch (SQLException e) {
                // Old DB without staff_user_id: allow.
            }
        }
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM payments WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    public double totalRevenue() throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        String sql = "SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid'";
        if (archiveReady()) {
            sql = "SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Paid' AND COALESCE(is_archived,0)=0";
        }
        if (sid != null) sql += " AND staff_user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (sid != null) ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getDouble(1) : 0;
            }
        }
    }

    public int count() throws SQLException {
        ensureStaffColumn();
        Integer sid = staffScopeId();
        if (!archiveReady()) {
            if (sid == null) {
                try (Connection c = DBConnection.getConnection();
                     Statement st = c.createStatement();
                     ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM payments")) {
                    return rs.next() ? rs.getInt(1) : 0;
                }
            }
            try (Connection c = DBConnection.getConnection();
                 PreparedStatement ps = c.prepareStatement(
                         "SELECT COUNT(*) FROM payments WHERE staff_user_id=?")) {
                ps.setInt(1, sid);
                try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
            }
        }
        String sql = "SELECT COUNT(*) FROM payments WHERE COALESCE(is_archived,0)=0";
        if (sid != null) sql += " AND staff_user_id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (sid != null) ps.setInt(1, sid);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
        }
    }

    public int countArchived() throws SQLException {
        if (!archiveReady()) return 0;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM payments WHERE COALESCE(is_archived,0)=1")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    /** Restores an archived payment back to the active list. */
    public boolean restore(int id) throws SQLException {
        ensureArchiveColumn();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE payments SET is_archived=0 WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    private void bind(PreparedStatement ps, Payment p) throws SQLException {
        ps.setInt(1, p.getPatientId());
        if (p.getTreatmentId() == null) ps.setNull(2, Types.INTEGER);
        else ps.setInt(2, p.getTreatmentId());
        if (p.getStaffUserId() == null) ps.setNull(3, Types.INTEGER);
        else ps.setInt(3, p.getStaffUserId());
        ps.setDouble(4, p.getAmount());
        ps.setString(5, p.getPaymentDate());
        ps.setString(6, p.getMethod());
        ps.setString(7, p.getStatus());
    }

    private List<Payment> mapAll(ResultSet rs) throws SQLException {
        List<Payment> list = new ArrayList<>();
        while (rs.next()) {
            Payment p = new Payment();
            p.setId(rs.getInt("id"));
            p.setPatientId(rs.getInt("patient_id"));
            int tr = rs.getInt("treatment_id");
            p.setTreatmentId(rs.wasNull() ? null : tr);
            try {
                int su = rs.getInt("staff_user_id");
                p.setStaffUserId(rs.wasNull() ? null : su);
            } catch (SQLException ignored) {
                p.setStaffUserId(null);
            }
            p.setPatientName(rs.getString("pname"));
            try {
                p.setStaffName(rs.getString("sname"));
            } catch (SQLException ignored) {
                p.setStaffName(null);
            }
            p.setAmount(rs.getDouble("amount"));
            Date d = rs.getDate("payment_date");
            p.setPaymentDate(d == null ? "" : d.toString());
            p.setMethod(rs.getString("method"));
            p.setStatus(rs.getString("status"));
            list.add(p);
        }
        return list;
    }
}
