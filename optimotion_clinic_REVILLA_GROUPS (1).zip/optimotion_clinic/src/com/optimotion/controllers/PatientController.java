package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.Patient;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * PatientController - CRUD + archive + keyword search for patients.
 * <p>
 * Customers panel has no manual archive button - archiving is driven by
 * the booking cascade: archiving a booking archives its treatments and,
 * when the patient has no other active bookings, the patient as well.
 * Restoring the booking restores them.
 */
public class PatientController extends BaseController implements Manageable<Patient> {

    private static volatile boolean archiveColChecked = false;

    /** Best-effort migration: adds patients.is_archived if missing (old DBs). */
    static synchronized void ensureArchiveColumn() {
        if (archiveColChecked) return;
        archiveColChecked = true;
        try (Connection c = DBConnection.getConnection()) {
            boolean exists = false;
            try (ResultSet rs = c.getMetaData().getColumns(null, null, "patients", "is_archived")) {
                if (rs.next()) exists = true;
            } catch (SQLException ignored) {}
            // Case-insensitive fallback (some drivers store upper-case).
            if (!exists) {
                try (ResultSet rs = c.getMetaData().getColumns(null, null, "PATIENTS", "IS_ARCHIVED")) {
                    if (rs.next()) exists = true;
                } catch (SQLException ignored) {}
            }
            if (!exists) {
                try (Statement st = c.createStatement()) {
                    st.executeUpdate("ALTER TABLE patients ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0");
                } catch (SQLException ignored) {
                    // If ALTER fails the queries below fall back to unfiltered mode.
                    archiveColChecked = false;
                }
            }
        } catch (SQLException ignored) {
            archiveColChecked = false;
        }
    }

    static boolean archiveReady() {
        ensureArchiveColumn();
        return archiveColChecked;
    }

    public boolean create(Patient p) throws SQLException {
        ensureArchiveColumn();
        String sql = "INSERT INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history)"
                   + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            return ps.executeUpdate() == 1;
        }
    }

    /** Insert + return generated id (used by unified booking; caller manages tx if needed). */
    public int createReturningId(Patient p) throws SQLException {
        ensureArchiveColumn();
        String sql = "INSERT INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history)"
                   + " VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, p);
            if (ps.executeUpdate() != 1) throw new SQLException("Patient insert failed.");
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) return rs.getInt(1);
            }
            throw new SQLException("Patient insert failed (no generated id).");
        }
    }

    /** Exact phone match (including archived) for duplicate prevention in booking flow. */
    public Patient findByPhone(String phone) throws SQLException {
        if (phone == null) return null;
        String p = phone.trim();
        if (p.isEmpty()) return null;
        ensureArchiveColumn();
        String sql = "SELECT * FROM patients WHERE phone=? LIMIT 1";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Active patients only (archived via booking cascade are hidden). */
    public List<Patient> getAll() throws SQLException {
        if (!archiveReady()) {
            return queryAll("SELECT * FROM patients ORDER BY id DESC");
        }
        return queryAll("SELECT * FROM patients WHERE COALESCE(is_archived,0)=0 ORDER BY id DESC");
    }

    /** Archived patients only. */
    public List<Patient> getArchived() throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        return queryAll("SELECT * FROM patients WHERE COALESCE(is_archived,0)=1 ORDER BY id DESC");
    }

    /** All patients regardless of archive status (for edit lookup). */
    public List<Patient> getAllIncludingArchived() throws SQLException {
        if (!archiveReady()) {
            return queryAll("SELECT * FROM patients ORDER BY id DESC");
        }
        return queryAll("SELECT * FROM patients ORDER BY id DESC");
    }

    /** Active-only keyword search (name, phone, email, or patient ID). */
    public List<Patient> search(String keyword) throws SQLException {
        if (!archiveReady()) {
            return querySearch("SELECT * FROM patients WHERE full_name LIKE ? OR phone LIKE ? OR email LIKE ? OR id LIKE ? ORDER BY id DESC", keyword);
        }
        return querySearch("SELECT * FROM patients WHERE COALESCE(is_archived,0)=0 AND (full_name LIKE ? OR phone LIKE ? OR email LIKE ? OR id LIKE ?) ORDER BY id DESC", keyword);
    }

    /** Archived-only keyword search. */
    public List<Patient> searchArchived(String keyword) throws SQLException {
        if (!archiveReady()) return new ArrayList<>();
        return querySearch("SELECT * FROM patients WHERE COALESCE(is_archived,0)=1 AND (full_name LIKE ? OR phone LIKE ? OR email LIKE ? OR id LIKE ?) ORDER BY id DESC", keyword);
    }

    public boolean update(Patient p) throws SQLException {
        String sql = "UPDATE patients SET full_name=?, gender=?, dob=?, phone=?, email=?, address=?, emergency_contact=?, medical_history=? WHERE id=?";
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            bind(ps, p);
            ps.setInt(9, p.getId());
            return ps.executeUpdate() == 1;
        }
    }

    /** Soft-delete: moves the patient to archive instead of removing the row. */
    public boolean archive(int id) throws SQLException {
        ensureArchiveColumn();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE patients SET is_archived=1 WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    /** Restores an archived patient back to the active list. */
    public boolean restore(int id) throws SQLException {
        ensureArchiveColumn();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE patients SET is_archived=0 WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    /**
     * Permanent hard delete. Should only be called from the archived view
     * for cleanup - cascades to appointments/treatments/payments.
     */
    public boolean delete(int id) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM patients WHERE id=?")) {
            ps.setInt(1, id);
            return ps.executeUpdate() == 1;
        }
    }

    /** Counts active patients only (archived via booking cascade excluded). */
    public int count() throws SQLException {
        if (!archiveReady()) {
            return countAll("patients");
        }
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM patients WHERE COALESCE(is_archived,0)=0")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public int countArchived() throws SQLException {
        if (!archiveReady()) return 0;
        try (Connection c = DBConnection.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM patients WHERE COALESCE(is_archived,0)=1")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private List<Patient> queryAll(String sql) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            List<Patient> list = new ArrayList<>();
            while (rs.next()) list.add(map(rs));
            return list;
        }
    }

    private List<Patient> querySearch(String sql, String keyword) throws SQLException {
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            String k = "%" + keyword.trim() + "%";
            ps.setString(1, k); ps.setString(2, k); ps.setString(3, k); ps.setString(4, k);
            try (ResultSet rs = ps.executeQuery()) {
                List<Patient> list = new ArrayList<>();
                while (rs.next()) list.add(map(rs));
                return list;
            }
        }
    }

    private void bind(PreparedStatement ps, Patient p) throws SQLException {
        ps.setString(1, p.getFullName());
        ps.setString(2, p.getGender());
        ps.setString(3, emptyToNull(p.getDob()));       // yyyy-MM-dd or null
        ps.setString(4, p.getPhone());
        ps.setString(5, emptyToNull(p.getEmail()));
        ps.setString(6, emptyToNull(p.getAddress()));
        ps.setString(7, emptyToNull(p.getEmergencyContact()));
        ps.setString(8, emptyToNull(p.getMedicalHistory()));
    }

    private Patient map(ResultSet rs) throws SQLException {
        Patient p = new Patient();
        p.setId(rs.getInt("id"));
        p.setFullName(rs.getString("full_name"));
        p.setGender(rs.getString("gender"));
        Date d = rs.getDate("dob");
        p.setDob(d == null ? "" : d.toString());
        p.setPhone(rs.getString("phone"));
        p.setEmail(nullToEmpty(rs.getString("email")));
        p.setAddress(nullToEmpty(rs.getString("address")));
        p.setEmergencyContact(nullToEmpty(rs.getString("emergency_contact")));
        p.setMedicalHistory(nullToEmpty(rs.getString("medical_history")));
        try {
            p.setArchived(rs.getInt("is_archived") == 1);
        } catch (SQLException ignored) {
            p.setArchived(false);
        }
        return p;
    }

    private String emptyToNull(String s) { return (s == null || s.trim().isEmpty()) ? null : s.trim(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }
}
