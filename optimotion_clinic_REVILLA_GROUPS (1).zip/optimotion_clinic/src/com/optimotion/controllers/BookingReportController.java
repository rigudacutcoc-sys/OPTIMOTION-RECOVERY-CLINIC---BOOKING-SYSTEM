package com.optimotion.controllers;

import com.optimotion.database.DBConnection;
import com.optimotion.models.BookingReportRow;
import com.optimotion.utils.Session;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * BookingReportController - Administrator Booking Report data source.
 *
 * <p>One row per active booking. Service comes from the linked treatment
 * rows (GROUP_CONCAT, so multi-service bookings show all). Staff comes from
 * {@code appointments.staff_user_id}. Cancelled/archived rows are included
 * in the feed so the Cancelled card and status filter are truthful - the
 * panel decides what to display. No new tables, no mock data.
 */
public class BookingReportController extends BaseController {

    private static final String REPORT_SQL =
        "SELECT a.id AS bid, p.full_name AS patient, p.phone AS phone, "
      + "COALESCE(GROUP_CONCAT(DISTINCT tr.treatment_type SEPARATOR ', '), '-') AS svc, "
      + "DATE_FORMAT(a.appointment_date, '%Y-%m-%d') AS d, "
      + "DATE_FORMAT(a.appointment_date, '%H:%i') AS t, "
      + "a.staff_user_id AS staff_id, COALESCE(u.full_name, 'Unassigned') AS staff, "
      + "a.status AS st "
      + "FROM appointments a "
      + "JOIN patients p ON a.patient_id = p.id "
      + "LEFT JOIN users u ON a.staff_user_id = u.id "
      + "LEFT JOIN treatments tr ON tr.appointment_id = a.id AND COALESCE(tr.is_archived,0)=0 "
      + "WHERE COALESCE(a.is_archived,0)=0 "
      + "GROUP BY a.id, p.full_name, p.phone, a.appointment_date, a.staff_user_id, u.full_name, a.status "
      + "ORDER BY a.appointment_date DESC";

    /** All active bookings for the report (admin view). */
    public List<BookingReportRow> getRows() throws SQLException {
        Session.requireLogin();
        AppointmentController.ensureStaffColumn();
        try (Connection c = DBConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(REPORT_SQL);
             ResultSet rs = ps.executeQuery()) {
            List<BookingReportRow> list = new ArrayList<>();
            while (rs.next()) {
                BookingReportRow r = new BookingReportRow();
                r.setBookingId(rs.getInt("bid"));
                r.setPatientName(rs.getString("patient"));
                r.setPatientPhone(rs.getString("phone") == null ? "-" : rs.getString("phone"));
                String svc = rs.getString("svc");
                r.setService(svc == null || svc.trim().isEmpty() ? "-" : svc);
                r.setDate(rs.getString("d"));
                r.setTime(rs.getString("t"));
                int sid = rs.getInt("staff_id");
                r.setStaffUserId(rs.wasNull() ? null : sid);
                r.setStaffName(rs.getString("staff"));
                r.setStatus(rs.getString("st"));
                list.add(r);
            }
            return list;
        }
    }
}
