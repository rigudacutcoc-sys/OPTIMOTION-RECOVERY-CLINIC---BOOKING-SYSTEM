-- ============================================================
-- Optimotion Recovery Clinic System - Normalized MySQL Database
-- DBMS: MySQL / MariaDB (XAMPP)  |  Database: optimotion_db
-- Run: mysql -u root < optimotion_db.sql  OR import via phpMyAdmin
-- ============================================================

CREATE DATABASE IF NOT EXISTS optimotion_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE optimotion_db;

-- ------------------------------------------------------------
-- 1. USERS : secure login / registration (password stored hashed)
--    Roles allowed: ONLY 'staff' and 'administrator' (no therapist role).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'staff',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_users_role CHECK (role IN ('staff','administrator'))
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 2. PATIENTS
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS patients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    gender ENUM('Male','Female','Other') NOT NULL DEFAULT 'Male',
    dob DATE NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NULL,
    address VARCHAR(255) NULL,
    emergency_contact VARCHAR(20) NULL,
    medical_history TEXT NULL,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_patient_name (full_name),
    INDEX idx_patient_phone (phone),
    INDEX idx_patient_archived (is_archived)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 3. SERVICES : catalogue of offered services + pricing
--    Each TREATMENT row references one SERVICE via treatments.service_id
--    (treatment_type + cost are copied at booking time to preserve history).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    duration_minutes INT NOT NULL DEFAULT 60,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_service_name (name)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 4. APPOINTMENTS : scheduled visits for a patient
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS appointments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    appointment_date DATETIME NOT NULL,
    status ENUM('Pending','Scheduled','Confirmed','In Progress','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
    notes TEXT NULL,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_appt_patient
        FOREIGN KEY (patient_id) REFERENCES patients(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_appt_date (appointment_date),
    INDEX idx_appt_archived (is_archived)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 5. TREATMENTS : recovery sessions assigned to a patient
--    (optionally tied to one appointment + one catalogue service)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS treatments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    appointment_id INT NULL,
    service_id INT NULL,
    treatment_type VARCHAR(100) NOT NULL,
    description TEXT NULL,
    session_count INT NOT NULL DEFAULT 1,
    session_date DATETIME NOT NULL,
    progress ENUM('Pending','Ongoing','Improved','Recovered','No Change') NOT NULL DEFAULT 'Pending',
    cost DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_treat_patient
        FOREIGN KEY (patient_id) REFERENCES patients(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_treat_appointment
        FOREIGN KEY (appointment_id) REFERENCES appointments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_treat_service
        FOREIGN KEY (service_id) REFERENCES services(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_treat_type (treatment_type),
    INDEX idx_treat_service (service_id),
    INDEX idx_treat_archived (is_archived)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 6. PAYMENTS : records patient payments (optionally for treatment)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    treatment_id INT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    method ENUM('Cash','Card','Bank Transfer','Insurance','E-Wallet') NOT NULL DEFAULT 'Cash',
    status ENUM('Paid','Pending','Partial') NOT NULL DEFAULT 'Paid',
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    CONSTRAINT fk_pay_patient
        FOREIGN KEY (patient_id) REFERENCES patients(id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_pay_treatment
        FOREIGN KEY (treatment_id) REFERENCES treatments(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_pay_date (payment_date),
    INDEX idx_pay_archived (is_archived)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- Default admin user (username: admin / password: admin123)
-- password_hash = SHA-256("admin123") =
-- 240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9
-- Demo staff user (username: staff / password: staff123)
-- ------------------------------------------------------------
INSERT IGNORE INTO users (username, password_hash, full_name, role, is_active)
VALUES ('admin',
        '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9',
        'Administrator', 'administrator', 1);
INSERT IGNORE INTO users (username, password_hash, full_name, role, is_active)
VALUES ('staff',
        '10176e7b7b24d317acfcf8d2064cfd2f24e154f7b5a96603077d5ef813d6a6b6',
        'Staff Member', 'staff', 1);

-- Sample data for testing ------------------------------------------------
INSERT IGNORE INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history)
VALUES
 ('Juan Dela Cruz', 'Male', '1990-05-12', '09171234567', 'juan@example.com', 'Manila, PH', '09179998888', 'Lower back pain'),
 ('Maria Santos', 'Female', '1985-09-20', '09181234567', 'maria@example.com', 'Quezon City, PH', '09189997777', 'Knee injury');

-- Default services & pricing (real Optimotion clinic price list) --------
INSERT IGNORE INTO services (name, description, price, duration_minutes, status)
VALUES
 ('Rehab Session - Manual + Therapeutic Exercise', 'Manual therapy and therapeutic exercises to improve mobility and reduce pain.', 1000.00, 60, 'Active'),
 ('5 Rehab Sessions Package', '5 sessions of rehab therapy (Manual + Therapeutic Exercise).', 4750.00, 60, 'Active'),
 ('10 Rehab Sessions Package', '10 sessions of rehab therapy (Manual + Therapeutic Exercise).', 9500.00, 60, 'Active'),
 ('Sports Recovery (Whole Body)', 'Full body recovery therapy for athletes and active individuals.', 1100.00, 60, 'Active'),
 ('Pre-Race Recovery', 'Pre-race preparation and mobility therapy.', 1100.00, 60, 'Active'),
 ('Post-Race Recovery', 'Recovery therapy after race or intense physical activity.', 1900.00, 90, 'Active'),
 ('Dry Needling (Add-On)', 'Targeted muscle release and pain relief through dry needling.', 300.00, 45, 'Active'),
 ('5 Sports Recovery Sessions', '5 sessions of sports recovery therapy.', 4750.00, 60, 'Active'),
 ('10 Sports Recovery Sessions', '10 sessions of sports recovery therapy.', 9500.00, 60, 'Active'),
 ('Contrast Bath Session (Sauna + Ice Bath)', 'Alternating sauna and ice bath therapy for faster recovery.', 600.00, 30, 'Active'),
 ('Sauna Only', 'Infrared or traditional sauna session for muscle relaxation.', 450.00, 30, 'Active'),
 ('Ice Bath Only', 'Cold therapy to reduce inflammation and speed up recovery.', 350.00, 30, 'Active'),
 ('Runner Recovery Bundle', '3 Sports Recovery Sessions + 2 Contrast Baths.', 3000.00, 60, 'Active'),
 ('Race Week Bundle', 'Pre-Race + Post-Race + 2 Contrast Baths.', 3000.00, 60, 'Active'),
 ('Post-Injury Recovery Bundle', '5 Rehab Sessions + 2 Contrast Baths.', 6000.00, 60, 'Active');

-- ------------------------------------------------------------
-- 7. SCHEDULES : staff availability / blocked slots
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS schedules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    staff_user_id INT NULL,
    sched_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status ENUM('Available','Blocked','Booked') NOT NULL DEFAULT 'Available',
    notes VARCHAR(255) NULL,
    CONSTRAINT fk_sched_staff FOREIGN KEY (staff_user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_sched_date (sched_date)
) ENGINE=InnoDB;

-- ------------------------------------------------------------
-- 8. SETTINGS : system-wide configuration (operating hours etc.)
--    Each change is tracked to USERS via settings.updated_by
--    (which staff/admin last saved the setting).
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
    skey VARCHAR(50) PRIMARY KEY,
    svalue VARCHAR(255) NOT NULL,
    updated_by INT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_settings_user
        FOREIGN KEY (updated_by) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_settings_user (updated_by)
) ENGINE=InnoDB;

INSERT IGNORE INTO settings (skey, svalue) VALUES
 ('clinic_name','Optimotion Recovery Clinic'),
 ('open_time','08:00'),
 ('close_time','17:00'),
 ('slot_minutes','60');

-- Migration: allow time on treatment sessions (DATE -> DATETIME).
-- Safe to re-run: keeps existing dates, adds 00:00:00 time if none.
ALTER TABLE treatments MODIFY COLUMN session_date DATETIME NOT NULL;

-- Migration: archive instead of hard-delete for patients.
-- For OLD databases only (fresh CREATE TABLE above already has it).
-- Run manually if needed: ALTER TABLE patients ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0;
-- The app also auto-adds the column at startup if missing.
-- Migration: archive for bookings (same pattern as patients).
-- For OLD databases only (fresh CREATE TABLE above already has it).
-- Run manually if needed: ALTER TABLE appointments ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0;
-- The app also auto-adds the column at startup if missing.
-- Migration: archive for treatments (driven by booking cascade).
-- For OLD databases only (fresh CREATE TABLE above already has it).
-- Run manually if needed: ALTER TABLE treatments ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0;
-- The app also auto-adds the column at startup if missing.
-- Migration: assigned staff for the Administrator Sales Report.
-- Additive + nullable: old payments read as "Unassigned", nothing breaks.
-- The app also auto-adds this column at startup (PaymentController.ensureStaffColumn).
-- Run manually if needed on an existing DB:
-- ALTER TABLE payments ADD COLUMN staff_user_id INT NULL;
-- ALTER TABLE payments ADD CONSTRAINT fk_pay_staff FOREIGN KEY (staff_user_id)
--   REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE;
-- Migration: owner staff for per-staff booking isolation (Part 3).
-- Additive + nullable: legacy bookings have NULL owner (admin-only until reassigned).
-- The app auto-adds it at startup (AppointmentController.ensureStaffColumn).
-- Run manually if needed:
-- ALTER TABLE appointments ADD COLUMN staff_user_id INT NULL;
-- ALTER TABLE appointments ADD CONSTRAINT fk_appt_staff FOREIGN KEY (staff_user_id)
--   REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE;
-- Migration: 'In Progress' booking status (multiple-service / additional bookings).
-- Each booking keeps its own independent status; new bookings never touch old rows.
-- The app auto-applies it at startup (AppointmentController.ensureStatusEnum).
-- Run manually if needed on an existing DB:
-- ALTER TABLE appointments MODIFY COLUMN status
--   ENUM('Pending','Scheduled','Confirmed','In Progress','Completed','Cancelled')
--   NOT NULL DEFAULT 'Scheduled';
-- Migration: 'Pending' treatment progress (booking/treatment status coupling).
-- New treatments start Pending (not started); flipping the booking to In Progress
-- moves them to Ongoing. The app auto-applies it at startup
-- (TreatmentController.ensureProgressEnum) and backfills Ongoing rows of still
-- Pending/Scheduled bookings to Pending.
-- Run manually if needed on an existing DB:
-- ALTER TABLE treatments MODIFY COLUMN progress
--   ENUM('Pending','Ongoing','Improved','Recovered','No Change')
--   NOT NULL DEFAULT 'Pending';
-- Migration: connect SERVICES -> TREATMENTS (prof requirement: no isolated tables).
-- Additive + nullable: old treatment rows keep NULL service_id (custom typed rows).
-- The app auto-adds this at startup (TreatmentController.ensureServiceColumn).
-- Run manually if needed on an existing DB:
-- ALTER TABLE treatments ADD COLUMN service_id INT NULL;
-- ALTER TABLE treatments ADD CONSTRAINT fk_treat_service FOREIGN KEY (service_id)
--   REFERENCES services(id) ON DELETE SET NULL ON UPDATE CASCADE;
-- Migration: connect SETTINGS -> USERS (prof requirement: no isolated tables).
-- Tracks which staff/admin last saved each setting.
-- The app auto-adds this at startup (SettingsController.ensureSettingsColumns).
-- Run manually if needed on an existing DB:
-- ALTER TABLE settings ADD COLUMN updated_by INT NULL;
-- ALTER TABLE settings ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP;
-- ALTER TABLE settings ADD CONSTRAINT fk_settings_user FOREIGN KEY (updated_by)
--   REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE;
