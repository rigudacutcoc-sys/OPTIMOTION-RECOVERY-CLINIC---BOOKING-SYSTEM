-- ============================================================
-- LOCAL DEMO SEED ONLY - run on YOUR machine, do NOT commit
-- Database: optimotion_db (XAMPP, port 3307)
-- Purpose : random client data isolated per staff account
--   staff (id=2, user 'staff')  -> 6 clients
--   fely  (id=3, user 'fely')   -> 6 clients
-- Run: C:\xampp\mysql\bin\mysql.exe -h localhost -P 3307 -u root optimotion_db < seed_local_staff_demo.sql
-- Re-runnable: deletes previous seed phones first (CASCADE cleans
-- appointments/treatments/payments).
-- ============================================================

USE optimotion_db;

-- Staff isolation columns are auto-added by the app, but ensure them here
-- for fresh/old DBs (safe to re-run, ignored if already present).
-- NOTE: MariaDB/MySQL has no IF NOT EXISTS for ADD COLUMN in older
-- versions, so these are wrapped as comments - the app adds them at
-- startup via ensureStaffColumn(). Uncomment if you need them manually:
-- ALTER TABLE appointments ADD COLUMN staff_user_id INT NULL;
-- ALTER TABLE payments ADD COLUMN staff_user_id INT NULL;

-- Resolve staff ids (do NOT hardcode - lookup by username) -------------
SELECT id, username, role FROM users WHERE username IN ('staff','fely');

-- Cleanup previous seed run (phones 091730011xx + 091730022xx) ----------
-- CASCADE from patients removes their appointments/treatments/payments.
DELETE FROM patients WHERE phone IN (
  '09173001101','09173001102','09173001103','09173001104','09173001105','09173001106',
  '09173002201','09173002202','09173002203','09173002204','09173002205','09173002206'
);

-- 1) PATIENTS (clients) - 12 random Filipino clients --------------------
INSERT INTO patients (full_name, gender, dob, phone, email, address, emergency_contact, medical_history, is_archived) VALUES
-- owned logically by staff (bookings below use staff_user_id=2)
('Miguel Torres',    'Male',   '1992-03-15', '09173001101', 'miguel.torres.demo@gmail.com', 'Tondo, Manila',        '09173001111', 'Lower back pain', 0),
('Angela Reyes',     'Female', '1995-07-22', '09173001102', 'angela.reyes.demo@gmail.com',  'Caloocan City',        '09173001112', 'Knee injury (basketball)', 0),
('Kevin Mendoza',    'Male',   '1988-11-30', '09173001103', 'kevin.mendoza.demo@gmail.com', 'Malabon City',         '09173001113', 'Frozen shoulder', 0),
('Sofia Navarro',    'Female', '2000-01-08', '09173001104', 'sofia.navarro.demo@gmail.com', 'Valenzuela City',      '09173001114', 'Posture correction', 0),
('Daniel Cruz',      'Male',   '1998-05-17', '09173001105', 'daniel.cruz.demo@gmail.com',   'Navotas City',         '09173001115', 'Ankle sprain (running)', 0),
('Bianca Ramos',     'Female', '1990-09-25', '09173001106', 'bianca.ramos.demo@gmail.com',  'Meycauayan, Bulacan',  '09173001116', 'Neck stiffness (office work)', 0),
-- owned logically by fely (bookings below use staff_user_id=3)
('Marco Villanueva', 'Male',   '1985-12-03', '09173002201', 'marco.v.demo@gmail.com',       'Marikina City',        '09173002211', 'Ankle sprain', 0),
('Liza Fernandez',   'Female', '1993-04-19', '09173002202', 'liza.f.demo@gmail.com',        'Pasig City',           '09173002212', 'Chronic neck pain', 0),
('Paolo Gutierrez',  'Male',   '1997-08-11', '09173002203', 'paolo.g.demo@gmail.com',       'Cainta, Rizal',        '09173002213', 'ACL rehab Stage 2', 0),
('Kara Aquino',      'Female', '1991-02-27', '09173002204', 'kara.a.demo@gmail.com',        'Antipolo City',        '09173002214', 'Sciatica', 0),
('Enzo Salazar',     'Male',   '2001-06-06', '09173002205', 'enzo.s.demo@gmail.com',        'Taytay, Rizal',        '09173002215', 'Wrist fracture recovery', 0),
('Nina Castillo',    'Female', '1989-10-14', '09173002206', 'nina.c.demo@gmail.com',        'Quezon City',          '09173002216', 'Lower back + wrist pain', 0);

-- Grab patient ids into variables (lookup by unique phone) --------------
SET @p1  := (SELECT id FROM patients WHERE phone='09173001101');
SET @p2  := (SELECT id FROM patients WHERE phone='09173001102');
SET @p3  := (SELECT id FROM patients WHERE phone='09173001103');
SET @p4  := (SELECT id FROM patients WHERE phone='09173001104');
SET @p5  := (SELECT id FROM patients WHERE phone='09173001105');
SET @p6  := (SELECT id FROM patients WHERE phone='09173001106');
SET @p7  := (SELECT id FROM patients WHERE phone='09173002201');
SET @p8  := (SELECT id FROM patients WHERE phone='09173002202');
SET @p9  := (SELECT id FROM patients WHERE phone='09173002203');
SET @p10 := (SELECT id FROM patients WHERE phone='09173002204');
SET @p11 := (SELECT id FROM patients WHERE phone='09173002205');
SET @p12 := (SELECT id FROM patients WHERE phone='09173002206');

SET @staff := (SELECT id FROM users WHERE username='staff');
SET @fely  := (SELECT id FROM users WHERE username='fely');

-- 2) APPOINTMENTS (bookings) - staff-scoped via staff_user_id -----------
-- staff's clients (staff_user_id = @staff)
INSERT INTO appointments (patient_id, staff_user_id, appointment_date, status, notes, is_archived) VALUES
(@p1, @staff, '2026-10-03 09:00', 'Completed',   'Lower back rehab - session done', 0),
(@p2, @staff, '2026-10-05 10:00', 'Completed',   'Knee rehab follow-up', 0),
(@p3, @staff, '2026-10-12 09:00', 'In Progress', 'Shoulder therapy ongoing', 0),
(@p4, @staff, '2026-10-15 13:00', 'Confirmed',   'Posture correction program', 0),
(@p5, @staff, '2026-10-16 10:00', 'Scheduled',   'Sports injury assessment', 0),
(@p6, @staff, '2026-10-07 14:00', 'Cancelled',   'Client requested cancel', 0),
(@p6, @staff, '2026-10-18 09:00', 'Pending',     'Rebooked after cancel', 0);

-- fely's clients (staff_user_id = @fely)
INSERT INTO appointments (patient_id, staff_user_id, appointment_date, status, notes, is_archived) VALUES
(@p7,  @fely, '2026-10-02 09:00', 'Completed',   'Ankle sprain rehab done', 0),
(@p8,  @fely, '2026-10-06 11:00', 'Completed',   'Neck pain therapy done', 0),
(@p9,  @fely, '2026-10-12 14:00', 'In Progress', 'ACL recovery ongoing', 0),
(@p10, @fely, '2026-10-15 10:00', 'Confirmed',   'Sciatica treatment plan', 0),
(@p11, @fely, '2026-10-17 13:00', 'Scheduled',   'Initial assessment', 0),
(@p12, @fely, '2026-10-04 15:00', 'Completed',   'Wrist therapy done', 0),
(@p12, @fely, '2026-10-19 09:00', 'Pending',     'Follow-up session', 0);

-- Grab appointment ids (patient + datetime is unique in this seed) ------
SET @a1  := (SELECT id FROM appointments WHERE patient_id=@p1  AND appointment_date='2026-10-03 09:00' LIMIT 1);
SET @a2  := (SELECT id FROM appointments WHERE patient_id=@p2  AND appointment_date='2026-10-05 10:00' LIMIT 1);
SET @a3  := (SELECT id FROM appointments WHERE patient_id=@p3  AND appointment_date='2026-10-12 09:00' LIMIT 1);
SET @a4  := (SELECT id FROM appointments WHERE patient_id=@p4  AND appointment_date='2026-10-15 13:00' LIMIT 1);
SET @a5  := (SELECT id FROM appointments WHERE patient_id=@p5  AND appointment_date='2026-10-16 10:00' LIMIT 1);
SET @a6  := (SELECT id FROM appointments WHERE patient_id=@p6  AND appointment_date='2026-10-07 14:00' LIMIT 1);
SET @a7  := (SELECT id FROM appointments WHERE patient_id=@p6  AND appointment_date='2026-10-18 09:00' LIMIT 1);
SET @a8  := (SELECT id FROM appointments WHERE patient_id=@p7  AND appointment_date='2026-10-02 09:00' LIMIT 1);
SET @a9  := (SELECT id FROM appointments WHERE patient_id=@p8  AND appointment_date='2026-10-06 11:00' LIMIT 1);
SET @a10 := (SELECT id FROM appointments WHERE patient_id=@p9  AND appointment_date='2026-10-12 14:00' LIMIT 1);
SET @a11 := (SELECT id FROM appointments WHERE patient_id=@p10 AND appointment_date='2026-10-15 10:00' LIMIT 1);
SET @a12 := (SELECT id FROM appointments WHERE patient_id=@p11 AND appointment_date='2026-10-17 13:00' LIMIT 1);
SET @a13 := (SELECT id FROM appointments WHERE patient_id=@p12 AND appointment_date='2026-10-04 15:00' LIMIT 1);
SET @a14 := (SELECT id FROM appointments WHERE patient_id=@p12 AND appointment_date='2026-10-19 09:00' LIMIT 1);

-- 3) TREATMENTS - visibility follows its booking (a.staff_user_id) ------
-- Rule: Completed booking -> Recovered treatment (payable in UI).
--       In Progress      -> Ongoing.  Future       -> Pending.
INSERT INTO treatments (patient_id, appointment_id, treatment_type, description, session_count, session_date, progress, cost, is_archived) VALUES
(@p1,  @a1,  'Physiotherapy Session', 'General physiotherapy assessment and treatment', 1, '2026-10-03 09:00', 'Recovered', 800.00, 0),
(@p2,  @a2,  'Sports Rehabilitation', 'Injury recovery program for athletes',           1, '2026-10-05 10:00', 'Recovered', 1200.00, 0),
(@p3,  @a3,  'Massage Therapy',       'Therapeutic deep-tissue massage',                1, '2026-10-12 09:00', 'Ongoing',   600.00, 0),
(@p4,  @a4,  'Physiotherapy Session', 'General physiotherapy assessment and treatment', 1, '2026-10-15 13:00', 'Pending',   800.00, 0),
(@p4,  @a4,  'Electrotherapy',        'Electrical stimulation treatment (add-on)',      1, '2026-10-15 13:00', 'Pending',   750.00, 0),
(@p5,  @a5,  'Sports Rehabilitation', 'Injury recovery program for athletes',           1, '2026-10-16 10:00', 'Pending',   1200.00, 0),
(@p6,  @a7,  'Hydrotherapy',          'Water-based rehabilitation session',             1, '2026-10-18 09:00', 'Pending',   1000.00, 0),
(@p7,  @a8,  'Electrotherapy',        'Electrical stimulation treatment',               1, '2026-10-02 09:00', 'Recovered', 750.00, 0),
(@p8,  @a9,  'Massage Therapy',       'Therapeutic deep-tissue massage',                1, '2026-10-06 11:00', 'Recovered', 600.00, 0),
(@p8,  @a9,  'Physiotherapy Session', 'Follow-up assessment (same booking, 2nd service)', 1, '2026-10-06 11:00', 'Improved', 800.00, 0),
(@p9,  @a10, 'Sports Rehabilitation', 'Injury recovery program for athletes',           1, '2026-10-12 14:00', 'Ongoing',   1200.00, 0),
(@p10, @a11, 'Hydrotherapy',          'Water-based rehabilitation session',             1, '2026-10-15 10:00', 'Pending',   1000.00, 0),
(@p10, @a11, 'Massage Therapy',       'Therapeutic deep-tissue massage (add-on)',       1, '2026-10-15 10:00', 'Pending',   600.00, 0),
(@p11, @a12, 'Occupational Therapy',  'Daily-living movement retraining',               1, '2026-10-17 13:00', 'Pending',   900.00, 0),
(@p12, @a13, 'Physiotherapy Session', 'General physiotherapy assessment and treatment', 1, '2026-10-04 15:00', 'Recovered', 800.00, 0),
(@p12, @a14, 'Massage Therapy',       'Therapeutic deep-tissue massage',                1, '2026-10-19 09:00', 'Pending',   600.00, 0);

-- Grab treatment ids for payments (type + appointment is unique here) ---
SET @t1  := (SELECT id FROM treatments WHERE appointment_id=@a1 AND treatment_type='Physiotherapy Session' LIMIT 1);
SET @t2  := (SELECT id FROM treatments WHERE appointment_id=@a2 AND treatment_type='Sports Rehabilitation' LIMIT 1);
SET @t7  := (SELECT id FROM treatments WHERE appointment_id=@a8 AND treatment_type='Electrotherapy' LIMIT 1);
SET @t8  := (SELECT id FROM treatments WHERE appointment_id=@a9 AND treatment_type='Massage Therapy' LIMIT 1);
SET @t13 := (SELECT id FROM treatments WHERE appointment_id=@a13 AND treatment_type='Physiotherapy Session' LIMIT 1);

-- 4) PAYMENTS - staff-scoped via payments.staff_user_id -----------------
-- NOTE: app rule = linked treatment must be Recovered to save via UI.
-- Ongoing advance/partial payments are stored with treatment_id=NULL
-- (walk-in/advance, bypasses the therapy-completed gate, same as UI).
-- staff's payments
INSERT INTO payments (patient_id, treatment_id, staff_user_id, amount, payment_date, method, status, is_archived) VALUES
(@p1, @t1, @staff,  800.00, '2026-10-03', 'Cash',          'Paid',    0),
(@p2, @t2, @staff, 1200.00, '2026-10-05', 'Card',          'Paid',    0),
(@p3, NULL, @staff,  300.00, '2026-10-12', 'Cash',         'Partial', 0),
-- fely's payments
(@p7,  @t7,  @fely,  750.00, '2026-10-02', 'Cash',          'Paid',    0),
(@p8,  @t8,  @fely,  600.00, '2026-10-06', 'E-Wallet',      'Paid',    0),
(@p9,  NULL, @fely,  600.00, '2026-10-12', 'Bank Transfer', 'Partial', 0),
(@p12, @t13, @fely,  800.00, '2026-10-04', 'Insurance',     'Paid',    0);

-- Verify ---------------------------------------------------------------
SELECT 'patients' AS t, COUNT(*) AS c FROM patients WHERE phone LIKE '0917300%'
UNION ALL SELECT 'appointments_staff', COUNT(*) FROM appointments WHERE staff_user_id=@staff
UNION ALL SELECT 'appointments_fely',  COUNT(*) FROM appointments WHERE staff_user_id=@fely
UNION ALL SELECT 'treatments_staff_bookings', COUNT(*) FROM treatments tr JOIN appointments a ON tr.appointment_id=a.id WHERE a.staff_user_id=@staff
UNION ALL SELECT 'treatments_fely_bookings',  COUNT(*) FROM treatments tr JOIN appointments a ON tr.appointment_id=a.id WHERE a.staff_user_id=@fely
UNION ALL SELECT 'payments_staff', COUNT(*) FROM payments WHERE staff_user_id=@staff
UNION ALL SELECT 'payments_fely',  COUNT(*) FROM payments WHERE staff_user_id=@fely;
