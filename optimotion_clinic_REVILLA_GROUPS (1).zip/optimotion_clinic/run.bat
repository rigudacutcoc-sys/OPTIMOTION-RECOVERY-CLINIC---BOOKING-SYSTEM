@echo off
REM 
REM  
REM  
REM 

echo [1/3] Checking MySQL connector...
if not exist "lib\mysql-connector-j.jar" (
    echo   Connector not found. Downloading mysql-connector-j 8.0.33 ...
    powershell -Command "Invoke-WebRequest -Uri 'https://repo1.maven.org/maven2/com/mysql/mysql-connector-j/8.0.33/mysql-connector-j-8.0.33.jar' -OutFile 'lib\mysql-connector-j.jar'"
    if errorlevel 1 (
        echo   ERROR: Download failed. Manually place mysql-connector-j.jar into lib\
        echo   Get it from: https://dev.mysql.com/downloads/connector/j/
        pause
        exit /b 1
    )
)

echo [2/3] Compiling...
if not exist bin mkdir bin
if exist src\resources (
    if not exist bin\resources mkdir bin\resources
    xcopy /Y /E src\resources bin\resources >nul
)
where javac >nul 2>nul
if errorlevel 1 (
    echo   ERROR: javac not found. Install a JDK 8+ and add it to PATH.
    echo   Check with: javac -version
    pause
    exit /b 1
)
dir /s /b src\*.java > sources.txt
javac -encoding UTF-8 -cp "lib\*" -d bin @sources.txt
if errorlevel 1 (
    echo   COMPILATION FAILED - see errors above.
    del sources.txt
    pause
    exit /b 1
)
del sources.txt
echo   Compilation OK.

echo [3/3] Starting Optimotion Clinic...
echo   Default logins: admin / admin123  ^(administrator^)  or  staff / staff123  ^(staff^)
echo   If login says "Cannot connect to MySQL": start MySQL in XAMPP and import database\optimotion_db.sql
where java >nul 2>nul
if errorlevel 1 (
    echo   ERROR: java not found. Install a JRE 8+ and add it to PATH.
    pause
    exit /b 1
)
java -cp "bin;lib\*" com.optimotion.Main
if errorlevel 1 (
    echo.
    echo   Application exited with an error - see messages above.
    pause
)
